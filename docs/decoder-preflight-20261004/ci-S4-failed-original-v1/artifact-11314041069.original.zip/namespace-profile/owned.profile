abi <abi/4.0>,
profile vast-ci-userns-3a0331cd3dbe490bb493919d37434d57 /opt/hostedtoolcache/Python/3.12.3/x64/bin/python3.12 flags=(unconfined) {
  userns,
}
