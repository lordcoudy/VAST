abi <abi/4.0>,
profile vast-ci-userns-822b3ebc7ac94dc2b66bf476a6fac98b /opt/hostedtoolcache/Python/3.12.3/x64/bin/python3.12 flags=(unconfined) {
  userns,
}
