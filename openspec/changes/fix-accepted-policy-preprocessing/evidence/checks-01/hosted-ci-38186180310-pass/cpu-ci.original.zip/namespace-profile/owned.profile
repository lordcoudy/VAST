abi <abi/4.0>,
profile vast-ci-userns-7a695afd1c594570920cbbc93887a728 /opt/hostedtoolcache/Python/3.12.3/x64/bin/python3.12 flags=(unconfined) {
  userns,
}
