abi <abi/4.0>,
profile vast-ci-userns-ec8809b9f9f54dadb844c13a9bf064a8 /opt/hostedtoolcache/Python/3.12.3/x64/bin/python3.12 flags=(unconfined) {
  userns,
}
