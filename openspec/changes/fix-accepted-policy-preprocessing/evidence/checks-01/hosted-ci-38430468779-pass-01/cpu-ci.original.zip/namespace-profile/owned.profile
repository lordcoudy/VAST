abi <abi/4.0>,
profile vast-ci-userns-ff67385002a741048e87d64e583bb734 /opt/hostedtoolcache/Python/3.12.3/x64/bin/python3.12 flags=(unconfined) {
  userns,
}
