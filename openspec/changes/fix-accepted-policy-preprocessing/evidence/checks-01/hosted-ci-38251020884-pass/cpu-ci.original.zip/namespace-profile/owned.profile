abi <abi/4.0>,
profile vast-ci-userns-81f8b87863484a5ca6f40e1132e2c3de /opt/hostedtoolcache/Python/3.12.3/x64/bin/python3.12 flags=(unconfined) {
  userns,
}
