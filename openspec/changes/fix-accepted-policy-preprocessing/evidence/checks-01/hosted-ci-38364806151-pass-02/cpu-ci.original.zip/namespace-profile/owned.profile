abi <abi/4.0>,
profile vast-ci-userns-95cc5384ea7544869214469e02c0022d /opt/hostedtoolcache/Python/3.12.3/x64/bin/python3.12 flags=(unconfined) {
  userns,
}
