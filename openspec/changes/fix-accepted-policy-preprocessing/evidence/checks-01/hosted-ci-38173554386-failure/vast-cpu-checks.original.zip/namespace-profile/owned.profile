abi <abi/4.0>,
profile vast-ci-userns-b46eb00b7eb74a62b4dfdfea368f9435 /opt/hostedtoolcache/Python/3.12.3/x64/bin/python3.12 flags=(unconfined) {
  userns,
}
