abi <abi/4.0>,
profile vast-ci-userns-6a47b61b3df2400daaa35ff837f44f27 /opt/hostedtoolcache/Python/3.12.3/x64/bin/python3.12 flags=(unconfined) {
  userns,
}
