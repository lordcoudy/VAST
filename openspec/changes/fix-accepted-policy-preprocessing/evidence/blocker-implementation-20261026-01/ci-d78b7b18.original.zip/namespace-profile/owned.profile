abi <abi/4.0>,
profile vast-ci-userns-50e8865497fd4a2fa5139875819b5e67 /opt/hostedtoolcache/Python/3.12.3/x64/bin/python3.12 flags=(unconfined) {
  userns,
}
