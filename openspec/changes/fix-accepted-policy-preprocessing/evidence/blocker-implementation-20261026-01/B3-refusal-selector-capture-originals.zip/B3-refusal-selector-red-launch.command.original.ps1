
$ErrorActionPreference='Stop'
$taskBase='openspec/changes/fix-accepted-policy-preprocessing/evidence/blocker-implementation-20261026-01'
$taskPhase='refusalselector-red-01'
foreach($taskFreshName in @(('prep-'+$taskPhase),('temporary-'+$taskPhase),('prep-'+$taskPhase+'-admission.original.json'),'refusalselector-red-test-source.original.py','refusalselector-red-positive-driver-source.original.py','refusalselector-red-negative-driver-source.original.py','refusalselector-red-runner-source.original.py','refusalselector-red-reader-source.original.py','refusalselector-red-gate-source.original.py','refusalselector-red-literal-read-test-source.original.py','refusalselector-red-negative-args-source.original.py')){if(Test-Path -LiteralPath (Join-Path $taskBase $taskFreshName)){throw 'literal read namespace consumed'}}
$taskLinux=@'
{"chunk_id":"e73da6","wall_time_seconds":1.1800519999999999,"exit_code":0,"original_token_count":142,"output":"{\"allocation_units\":{\"c\":4096,\"e\":4096,\"temporary\":4096},\"boot_id\":\"df4955d9-4762-42b4-a55b-0106ba3786f8\",\"free_bytes\":{\"c\":240926449664,\"e\":257012314112,\"temporary\":880666374144},\"root_device\":\"/dev/sdf\",\"root_mounts\":[[\"/dev/sdf\",\"/\",\"ext4\",\"rw,relatime,discard,errors=remount-ro,data=ordered\",\"0\",\"0\"]],\"root_uuid\":\"c3d3247e-154c-43c0-a9fe-2b91d6db7666\",\"temporary_same_device_as_root\":true,\"vm_memory_bytes\":{\"MemTotal\":25196363776,\"SwapTotal\":6442450944},\"wslconfig_sha256\":\"6efea9e209212784c22240a6019c17cee3bd31011840250c76c3bb31e2c7eea1\",\"wslconfig_size\":21}\n"}
'@ | ConvertFrom-Json
$taskHead=& git -c gc.auto=0 -c maintenance.auto=false rev-parse HEAD
if($LASTEXITCODE -ne 0 -or $taskHead -ne 'dc62b6bc0657a172aa82c760b51a22884bd21472'){throw 'reviewed product head differs'}
& git -c gc.auto=0 -c maintenance.auto=false diff --quiet HEAD -- tests/fixtures/accepted_policy_fixture_compiler_admission_v1.py tests/fixtures/accepted_policy_fixture_compiler_v1.py tests/fixtures/accepted_policy_original_custody_fixture_v1.py tests/fixtures/accepted_policy_physical_fixture_v1.py tests/fixtures/accepted_policy_controlled_compiler_v1.py tests/test_accepted_policy_fixture_preflight_v1.py tests/test_accepted_policy_fixture_compiler_admission_v1.py
if($LASTEXITCODE -ne 0){throw 'reviewed product bytes differ'}
$taskRunner=Join-Path $taskBase 'preparatory_checks.py'
if((Get-FileHash -LiteralPath $taskRunner -Algorithm SHA256).Hash -ne '24c7d2144a1e38cb96dc144446df88bf415353f6c677d5e5729f60ce1466bfc4'){throw 'reviewed runner differs'}

$taskQuantityTest='tests/test_accepted_policy_fixture_quantity_v1.py'
$taskQuantityTestSha='546af4ff73d86bbfccce707fc7d0ec58633eb0ac76430353c55054c27b2b998d'
$taskNative='tests/fixtures/accepted_policy_native_fixture_v2.py'
$taskNativeSha='ee829f4156f064e439f085bcc18fc96bec446a4ecba9df64b2f38836cdccb119'
$taskPhysical='tests/fixtures/accepted_policy_physical_fixture_v2.py'
$taskPhysicalSha='457df99000878f3b9741aff7aba3f9074759ae05d67a45b4c2874aa75c27b7e5'
if((Get-FileHash -LiteralPath $taskQuantityTest -Algorithm SHA256).Hash -ne $taskQuantityTestSha -or (Get-FileHash -LiteralPath $taskNative -Algorithm SHA256).Hash -ne $taskNativeSha -or (Get-FileHash -LiteralPath $taskPhysical -Algorithm SHA256).Hash -ne $taskPhysicalSha){throw 'reviewed quantity source bytes differ'}

$taskBindingTest='tests/test_accepted_policy_fixture_binding_bounds_v1.py'
$taskBindingTestSha='474875e54982db201557b67cb3424d4c32a399d0d5e6e6c1b64cb1d9714982b6'
if((Get-FileHash -LiteralPath $taskBindingTest -Algorithm SHA256).Hash -ne $taskBindingTestSha){throw 'reviewed binding test differs'}
$taskSidecarTest='tests/test_accepted_policy_fixture_sidecar_bounds_v1.py'
$taskSidecarTestSha='c02e21d7781fd72146f38d9db23b2f207a752aa4c682d5a3495a0d015f477f11'
if((Get-FileHash -LiteralPath $taskSidecarTest -Algorithm SHA256).Hash -ne $taskSidecarTestSha){throw 'reviewed sidecar test differs'}
$taskSidecarEdgesTest='tests/test_accepted_policy_fixture_sidecar_edges_v1.py'
$taskSidecarEdgesTestSha='53923d82fbb3edf399b4e80b29fd85caaa93c63522195546aa40953752dffacc'
if((Get-FileHash -LiteralPath $taskSidecarEdgesTest -Algorithm SHA256).Hash -ne $taskSidecarEdgesTestSha){throw 'reviewed sidecar edge test differs'}
$taskReaderTest='tests/test_accepted_policy_fixture_reader_bounds_v1.py'
$taskReaderTestSha='57db27d19e263c3dc2233a54a8e639b2b6be246e427d78c5a9640ed4e44aa25d'
$taskConsumer='tests/fixtures/accepted_policy_consumer_fixture_v2.py'
$taskConsumerSha='0597a2b55b7429d8bb04c0ffa87fc304a1ac232b6822810d8933e27c10683fd7'
$taskAssertions='tests/fixtures/accepted_policy_consumer_assertions_v1.py'
$taskAssertionsSha='7d9a5dae76383ac1c38502b714b21b36f2126e83b00e41e2e06d22a461f924a2'
$taskJournal='tests/fixtures/accepted_policy_guardian_journal_fixture_v1.py'
$taskJournalSha='5cffe02d773ac6eeb247015a1d83dc3d7848ce64c3cb119dc581864dc6f9dc4a'
if((Get-FileHash -LiteralPath $taskReaderTest -Algorithm SHA256).Hash -ne $taskReaderTestSha -or (Get-FileHash -LiteralPath $taskConsumer -Algorithm SHA256).Hash -ne $taskConsumerSha -or (Get-FileHash -LiteralPath $taskAssertions -Algorithm SHA256).Hash -ne $taskAssertionsSha -or (Get-FileHash -LiteralPath $taskJournal -Algorithm SHA256).Hash -ne $taskJournalSha){throw 'reviewed reader adapter source differs'}
$taskWriteFactsTest='tests/test_accepted_policy_fixture_sidecar_write_facts_v1.py'
$taskWriteFactsTestSha='a4b2eb3fde66073e93ec9990702612ec68b961a0c66441641489daa1160e3a74'
if((Get-FileHash -LiteralPath $taskWriteFactsTest -Algorithm SHA256).Hash -ne $taskWriteFactsTestSha){throw 'reviewed write-facts test differs'}
$taskHeaderTest='tests/test_accepted_policy_fixture_journal_header_v1.py'
$taskHeaderTestSha='ee262eae31a73e8adb2eb25b669d2443dea9454580c2ace05888c6acb591a1f6'
if((Get-FileHash -LiteralPath $taskHeaderTest -Algorithm SHA256).Hash -ne $taskHeaderTestSha){throw 'reviewed header test differs'}
$taskArtifactTest='tests/test_accepted_policy_fixture_artifact_reads_v1.py'
$taskArtifactTestSha='2fbe138736df76ed9c750f4db5a437a88b6bb72e0f06189f59d770e4cd6351f7'
if((Get-FileHash -LiteralPath $taskArtifactTest -Algorithm SHA256).Hash -ne $taskArtifactTestSha){throw 'reviewed artifact read test differs'}
$taskEnginePinTest='tests/test_accepted_policy_fixture_engine_pin_v2.py'
$taskEnginePinTestSha='ab69034bcb760f377827973c849121a4e2a9361037c09f97e918ff3fb1273037'
if((Get-FileHash -LiteralPath $taskEnginePinTest -Algorithm SHA256).Hash -ne $taskEnginePinTestSha){throw 'reviewed engine pin test differs'}
$taskFinalizerTest='tests/test_accepted_policy_fixture_finalizer_bounds_v2.py'
$taskFinalizerTestSha='78fa73de664ca4232a623264a961baf6b0dd39cc6092c6f1eb297031604f58c9'
if((Get-FileHash -LiteralPath $taskFinalizerTest -Algorithm SHA256).Hash -ne $taskFinalizerTestSha){throw 'reviewed finalizer test differs'}
$taskConsumerClockTest='tests/test_accepted_policy_fixture_consumer_deadline_v2.py'
$taskConsumerClockTestSha='a2f917b68c8e565737e4564f95787ead38669bcf54847b4cb2ac226c0200bff2'
$taskReaderOwner='tests/fixtures/accepted_policy_standalone_reader_fixture_v2.py'
$taskReaderOwnerSha='7fc7e536f4366fcc575240d1b81232bc8b9c3851bd13868c5d9981d40496507f'
if((Get-FileHash -LiteralPath $taskConsumerClockTest -Algorithm SHA256).Hash -ne $taskConsumerClockTestSha -or (Get-FileHash -LiteralPath $taskReaderOwner -Algorithm SHA256).Hash -ne $taskReaderOwnerSha){throw 'reviewed consumer clock sources differ'}
$taskExecutionTest='tests/test_accepted_policy_fixture_execution_arguments_v2.py'
$taskExecutionTestSha='be8cbef2535dbc84dfddc9ff90230eeca279a48bcc1970ed4f0d7b0fd1d04ec0'
$taskLiteralDriver='openspec/changes/fix-accepted-policy-preprocessing/evidence/consumer-01/build_production_fixture_v2.py'
$taskLiteralDriverSha='e600c8ed292b25a4c1bbcd0fc00bed84e3e4e7e810e344ed67d07386266b3fb3'
$taskAdmissionGate='tests/fixtures/accepted_policy_fixture_compiler_admission_v1.py'
$taskAdmissionGateSha='dea1b0fefc99e160cada5e9937412ad3d4489cb30783bb169db26505c6bb6610'
if((Get-FileHash -LiteralPath $taskExecutionTest -Algorithm SHA256).Hash -ne $taskExecutionTestSha -or (Get-FileHash -LiteralPath $taskLiteralDriver -Algorithm SHA256).Hash -ne $taskLiteralDriverSha -or (Get-FileHash -LiteralPath $taskAdmissionGate -Algorithm SHA256).Hash -ne $taskAdmissionGateSha){throw 'reviewed literal execution sources differ'}
$taskNegativeTest='tests/test_accepted_policy_fixture_refusal_arguments_v1.py'
$taskNegativeTestSha='019fd0e4cef89b1fbe25474bad18ea49d1511eb9057f8a9fdc6f10d2406b2c6e'
$taskNegativeDriver='openspec/changes/fix-accepted-policy-preprocessing/evidence/consumer-01/build_per_cell_minimum_refusal_v1.py'
$taskNegativeDriverSha='bcd8de1bcd5d97b64d9a2a740464cdf359ccf38eb5a657517ee63cde978cdd52'
if((Get-FileHash -LiteralPath $taskNegativeTest -Algorithm SHA256).Hash -ne $taskNegativeTestSha -or (Get-FileHash -LiteralPath $taskNegativeDriver -Algorithm SHA256).Hash -ne $taskNegativeDriverSha){throw 'reviewed negative caller sources differ'}
$taskCleanupTest='tests/test_accepted_policy_fixture_preparation_cleanup_v2.py'
$taskCleanupTestSha='691f82c8668bda0b25a0d6f9a4ceeb820d7e757d4d1f623d4b415342ab1b699f'
if((Get-FileHash -LiteralPath $taskCleanupTest -Algorithm SHA256).Hash -ne $taskCleanupTestSha){throw 'reviewed socket-cleanup test differs'}
$taskReplyPreflightTest='tests/test_accepted_policy_fixture_reply_preflight_v2.py'
$taskReplyPreflightTestSha='367eb92c72f7a531c59a85f9e784502165d6538bfb606893aff8a57df876f4d2'
if((Get-FileHash -LiteralPath $taskReplyPreflightTest -Algorithm SHA256).Hash -ne $taskReplyPreflightTestSha){throw 'reviewed complete reply-map test differs'}
$taskProbeBindingTest='tests/test_accepted_policy_fixture_probe_binding_v2.py'
$taskProbeBindingTestSha='df0b70224ba06d11a3f7694bf1c5504afd2f7a50990e8d7a7a9d2b1ea2251a9c'
if((Get-FileHash -LiteralPath $taskProbeBindingTest -Algorithm SHA256).Hash -ne $taskProbeBindingTestSha){throw 'reviewed fixed probe roster source differs'}
$taskLiteralReadTest='tests/test_accepted_policy_fixture_refusal_selector_v1.py'
$taskLiteralReadTestSha='1e663a5751257995042a3ea8441d2ef59995ebfaea2c560b3bf1f7ddab21a6c1'
if((Get-FileHash -LiteralPath $taskLiteralReadTest -Algorithm SHA256).Hash -ne $taskLiteralReadTestSha){throw 'reviewed literal read test differs'}
$taskConfig='C:\Users\s-a-balashov\.wslconfig'
if((Get-Item -LiteralPath $taskConfig).Length -ne 21 -or (Get-FileHash -LiteralPath $taskConfig -Algorithm SHA256).Hash -ne '6efea9e209212784c22240a6019c17cee3bd31011840250c76c3bb31e2c7eea1'){throw 'VM configuration differs'}
$taskDistros=@(Get-ChildItem 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Lxss'|Get-ItemProperty|Where-Object DistributionName -eq 'Ubuntu')
$taskVhdBase='C:\Users\s-a-balashov\AppData\Local\wsl\{733a6524-960b-47be-ac8d-deaf948be3c7}'
if($taskDistros.Count -ne 1 -or $taskDistros[0].DefaultUid -ne 1000 -or $taskDistros[0].BasePath.TrimEnd('\') -ine $taskVhdBase){throw 'Ubuntu registry identity differs'}
$taskVhd=Get-Item -LiteralPath (Join-Path $taskVhdBase 'ext4.vhdx')
$taskVolumes=@(Get-Volume -DriveLetter C,E|Select-Object DriveLetter,SizeRemaining,Size,AllocationUnitSize)
$taskC=@($taskVolumes|Where-Object DriveLetter -eq 'C');$taskE=@($taskVolumes|Where-Object DriveLetter -eq 'E')
if($taskC.Count -ne 1 -or $taskE.Count -ne 1 -or $taskC[0].SizeRemaining -lt 128849018880 -or $taskE[0].SizeRemaining -lt 70866960384 -or @($taskVolumes|Where-Object { $_.AllocationUnitSize -le 0 -or $_.AllocationUnitSize -gt 4096 }).Count){throw 'Windows physical floors differ'}
$taskPages=@(Get-CimInstance Win32_PageFileUsage|Select-Object Name,AllocatedBaseSize,CurrentUsage,PeakUsage)
$taskPageSettings=@(Get-CimInstance Win32_PageFileSetting|Select-Object Name,InitialSize,MaximumSize)
if($taskPages.Count -ne 1 -or $taskPages[0].Name -ine 'E:\pagefile.sys' -or $taskPages[0].AllocatedBaseSize -gt 65536 -or $taskPageSettings.Count -ne 1 -or $taskPageSettings[0].Name -ine 'E:\pagefile.sys' -or $taskPageSettings[0].MaximumSize -ne 65536){throw 'pagefile geometry differs'}
$taskUsnC=@(& fsutil usn queryjournal C: 2>&1);$taskUsnCExit=$LASTEXITCODE
$taskUsnE=@(& fsutil usn queryjournal E: 2>&1);$taskUsnEExit=$LASTEXITCODE
if($taskUsnCExit -ne 0 -or ($taskUsnC -join "`n") -notmatch 'Maximum Size\s+: 0x0000000002000000' -or ($taskUsnC -join "`n") -notmatch 'Allocation Delta\s+: 0x0000000000800000' -or $taskUsnEExit -ne 1 -or ($taskUsnE -join "`n") -notmatch 'Error 1179'){throw 'USN geometry differs'}
$taskPriorLiteralReadTest='tests/test_accepted_policy_fixture_literal_reads_v2.py'
$taskPriorLiteralReadTestSha='872cbced003e57b3e61fbe04a9cfebe87e453b1e1b8208d4a4d630c62f60428b'
if((Get-FileHash -LiteralPath $taskPriorLiteralReadTest -Algorithm SHA256).Hash -ne $taskPriorLiteralReadTestSha){throw 'prior literal read test differs'}
$taskRecord=[ordered]@{schema_version=1;phase=$taskPhase;observed_utc=[DateTime]::UtcNow.ToString('o');product_commit=$taskHead;quantity_test_sha256=$taskQuantityTestSha;binding_test_sha256=$taskBindingTestSha;sidecar_test_sha256=$taskSidecarTestSha;sidecar_edges_test_sha256=$taskSidecarEdgesTestSha;reader_test_sha256=$taskReaderTestSha;write_facts_test_sha256=$taskWriteFactsTestSha;header_test_sha256=$taskHeaderTestSha;artifact_test_sha256=$taskArtifactTestSha;engine_pin_test_sha256=$taskEnginePinTestSha;finalizer_test_sha256=$taskFinalizerTestSha;consumer_clock_test_sha256=$taskConsumerClockTestSha;execution_arguments_test_sha256=$taskExecutionTestSha;literal_driver_sha256=$taskLiteralDriverSha;negative_caller_sha256=$taskNegativeDriverSha;negative_test_sha256=$taskNegativeTestSha;socket_cleanup_test_sha256=$taskCleanupTestSha;reply_preflight_test_sha256=$taskReplyPreflightTestSha;refusal_selector_test_sha256=$taskLiteralReadTestSha;literal_read_test_sha256=$taskPriorLiteralReadTestSha;admission_gate_sha256=$taskAdmissionGateSha;reader_owner_sha256=$taskReaderOwnerSha;consumer_sha256=$taskConsumerSha;assertions_sha256=$taskAssertionsSha;journal_sha256=$taskJournalSha;native_sha256=$taskNativeSha;physical_sha256=$taskPhysicalSha;direct_file_allowance_bytes=1996488704;reviewed_method_count=7;reviewed_call_count=16;assigned_pair_bytes=29884416;pair_allowance_bytes=33554432;probe_binding_test_sha256=$taskProbeBindingTestSha;runner_sha256='24c7d2144a1e38cb96dc144446df88bf415353f6c677d5e5729f60ce1466bfc4';independent_recipe_verdict='conditional CLEAR, /root/provider_route_review';agent_execution_admission='released after fresh checks for this one controlled phase only';c_additional_bytes=85899345920;e_additional_bytes=69793218560;whole_chain_admitted=$false;volumes=$taskVolumes;pagefiles=$taskPages;pagefile_settings=$taskPageSettings;usn_c=@{exit_code=$taskUsnCExit;lines=$taskUsnC};usn_e=@{exit_code=$taskUsnEExit;lines=$taskUsnE};vhd=@{path=$taskVhd.FullName;length=$taskVhd.Length;last_write_utc=$taskVhd.LastWriteTimeUtc.ToString('o')};linux_tool_return=$taskLinux}
$taskRaw=[Text.Encoding]::UTF8.GetBytes(($taskRecord|ConvertTo-Json -Depth 9 -Compress)+"`n")
if($taskRaw.Length -gt 16384){throw 'admission record bound'}
$taskAdmission=Join-Path (Get-Location) (Join-Path $taskBase ('prep-'+$taskPhase+'-admission.original.json'))
$taskStream=[IO.File]::Open($taskAdmission,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
try{$taskStream.Write($taskRaw,0,$taskRaw.Length);$taskStream.Flush($true)}finally{$taskStream.Dispose()}
$taskSourceCopies=@(@($taskLiteralReadTest,'refusalselector-red-test-source.original.py'),@($taskLiteralDriver,'refusalselector-red-positive-driver-source.original.py'),@($taskNegativeDriver,'refusalselector-red-negative-driver-source.original.py'),@($taskRunner,'refusalselector-red-runner-source.original.py'),@($taskReaderOwner,'refusalselector-red-reader-source.original.py'),@($taskAdmissionGate,'refusalselector-red-gate-source.original.py'),@($taskPriorLiteralReadTest,'refusalselector-red-literal-read-test-source.original.py'),@($taskNegativeTest,'refusalselector-red-negative-args-source.original.py'))
$taskCopyBytes=0
foreach($taskCopy in $taskSourceCopies){
 $taskCopyLength=(Get-Item -LiteralPath $taskCopy[0]).Length
 if($taskCopyLength -gt 65536){throw 'pre-run individual source copy bound'}
 $taskCopyBytes+=$taskCopyLength
}
if($taskCopyBytes -gt 131072){throw 'pre-run aggregate source copy bound'}
foreach($taskCopy in $taskSourceCopies){
 $taskInfo=Get-Item -LiteralPath $taskCopy[0]
 $taskCopyRaw=[IO.File]::ReadAllBytes($taskInfo.FullName)
 $taskCopyStream=[IO.File]::Open((Join-Path $taskBase $taskCopy[1]),'CreateNew','Write','Read')
 try{$taskCopyStream.Write($taskCopyRaw,0,$taskCopyRaw.Length);$taskCopyStream.Flush($true)}finally{$taskCopyStream.Dispose()}
}
Write-Output ("Admission persisted for "+$taskPhase+"; bytes="+$taskRaw.Length)
& wsl.exe --distribution Ubuntu --user s-a-balashov --cd /mnt/c/Users/s-a-balashov/.codex/worktrees/fix-accepted-policy-preprocessing/VAST --exec /mnt/c/Users/s-a-balashov/.codex/worktrees/fix-accepted-policy-preprocessing/VAST/.venv/bin/python -B /mnt/c/Users/s-a-balashov/.codex/worktrees/fix-accepted-policy-preprocessing/VAST/openspec/changes/fix-accepted-policy-preprocessing/evidence/blocker-implementation-20261026-01/preparatory_checks.py $taskPhase
exit $LASTEXITCODE
