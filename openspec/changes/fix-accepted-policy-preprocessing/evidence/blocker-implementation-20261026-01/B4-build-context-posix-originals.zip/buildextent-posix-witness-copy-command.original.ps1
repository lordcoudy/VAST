$ErrorActionPreference='Stop'
$taskBase=Join-Path (Get-Location) 'openspec/changes/fix-accepted-policy-preprocessing/evidence/blocker-implementation-20261026-01'
$taskFacts=@'
{"copy_maximum_bytes":4,"members":[{"bytes":4,"mode":420,"relative":"buildextent-8k5oftu7/source","sha256":"88d4266fd4e6338d13b845fcf289579d209c897823b9217da3e161936f031589"},{"bytes":4,"mode":292,"relative":"buildextent-8k5oftu7/destination","sha256":"88d4266fd4e6338d13b845fcf289579d209c897823b9217da3e161936f031589"},{"bytes":4,"mode":420,"relative":"buildextent-bs2_bar5/source","sha256":"88d4266fd4e6338d13b845fcf289579d209c897823b9217da3e161936f031589"},{"bytes":4,"mode":292,"relative":"buildextent-bs2_bar5/destination","sha256":"88d4266fd4e6338d13b845fcf289579d209c897823b9217da3e161936f031589"},{"bytes":0,"mode":420,"relative":"buildextent-fxx1bxwz/source","sha256":"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"},{"bytes":0,"mode":292,"relative":"buildextent-fxx1bxwz/destination","sha256":"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"},{"bytes":4,"mode":420,"relative":"buildextent-gj9dyg6b/source","sha256":"88d4266fd4e6338d13b845fcf289579d209c897823b9217da3e161936f031589"},{"bytes":3,"mode":292,"relative":"buildextent-gj9dyg6b/destination","sha256":"ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"},{"bytes":4,"mode":420,"relative":"buildextent-lyooxto0/source","sha256":"88d4266fd4e6338d13b845fcf289579d209c897823b9217da3e161936f031589"},{"bytes":2,"mode":292,"relative":"buildextent-lyooxto0/destination","sha256":"fb8e20fc2e4c3f248c60c39bd652f3c1347298bb977b8b4d5903b85055620603"},{"bytes":0,"mode":420,"relative":"buildextent-ms548nbk/source","sha256":"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"},{"bytes":0,"mode":292,"relative":"buildextent-ms548nbk/destination","sha256":"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"},{"bytes":4,"mode":420,"relative":"buildextent-ulu2bwaa/source","sha256":"88d4266fd4e6338d13b845fcf289579d209c897823b9217da3e161936f031589"},{"bytes":0,"mode":292,"relative":"buildextent-ulu2bwaa/destination","sha256":"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"}],"retained_roots":7,"root":"/var/tmp/vast-pr9-b2-prep-buildextent-posix-green-01"}
'@|ConvertFrom-Json
$taskSourceRoot='\\wsl.localhost\Ubuntu\var\tmp\vast-pr9-b2-prep-buildextent-posix-green-01'
$taskDestinationRoot=Join-Path $taskBase 'witnesses-buildextent-posix-green-01'
if($taskFacts.members.Count -ne 14 -or $taskFacts.retained_roots -ne 7 -or (Test-Path -LiteralPath $taskDestinationRoot)){throw 'witness copy namespace/count differs'}
[void](New-Item -Path $taskDestinationRoot -ItemType Directory)
$taskParents=@{}
$taskHasher=[Security.Cryptography.SHA256]::Create()
try{
 foreach($taskMember in $taskFacts.members){
  if($taskMember.relative -cnotmatch '^buildextent-[a-z0-9_]{8}/(source|destination)$' -or $taskMember.bytes -lt 0 -or $taskMember.bytes -gt 4 -or $taskMember.sha256 -cnotmatch '^[0-9a-f]{64}$'){throw 'witness shape differs'}
  $taskRelative=$taskMember.relative.Replace('/','\')
  $taskSource=Join-Path $taskSourceRoot $taskRelative
  $taskBefore=Get-Item -LiteralPath $taskSource
  if($taskBefore.Length -ne $taskMember.bytes -or ($taskBefore.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'original witness size/alias differs'}
  $taskBuffer=[byte[]]::new(5)
  $taskCount=0
  $taskInput=[IO.File]::Open($taskSource,'Open','Read','Read')
  try{
   while($taskCount -lt 5){
    $taskRead=$taskInput.Read($taskBuffer,$taskCount,5-$taskCount)
    if($taskRead -eq 0){break}
    $taskCount+=$taskRead
   }
  }finally{$taskInput.Dispose()}
  if($taskCount -ne $taskMember.bytes -or $taskCount -gt 4){throw 'witness grew before copy'}
  $taskRaw=[byte[]]::new($taskCount)
  [Array]::Copy($taskBuffer,$taskRaw,$taskCount)
  $taskSha=[BitConverter]::ToString($taskHasher.ComputeHash($taskRaw)).Replace('-','').ToLowerInvariant()
  if($taskSha -ne $taskMember.sha256 -or (Get-Item -LiteralPath $taskSource).Length -ne $taskMember.bytes){throw 'original witness hash/extent differs'}
  $taskDestination=Join-Path $taskDestinationRoot $taskRelative
  $taskParent=Split-Path -LiteralPath $taskDestination -Parent
  if(-not $taskParents.ContainsKey($taskParent)){
   if(Test-Path -LiteralPath $taskParent){throw 'foreign witness destination parent'}
   [void](New-Item -Path $taskParent -ItemType Directory)
   $taskParents[$taskParent]=$true
  }
  $taskOutput=[IO.File]::Open($taskDestination,'CreateNew','Write','Read')
  try{$taskOutput.Write($taskRaw,0,$taskRaw.Length);$taskOutput.Flush($true)}finally{$taskOutput.Dispose()}
  if((Get-Item -LiteralPath $taskDestination).Length -ne $taskMember.bytes -or (Get-FileHash -LiteralPath $taskDestination -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskMember.sha256){throw 'witness copy differs'}
 }
}finally{$taskHasher.Dispose()}
[ordered]@{copied_files=14;original_linux_roots_preserved=$true;per_file_bound=4;destination=$taskDestinationRoot}|ConvertTo-Json -Compress
