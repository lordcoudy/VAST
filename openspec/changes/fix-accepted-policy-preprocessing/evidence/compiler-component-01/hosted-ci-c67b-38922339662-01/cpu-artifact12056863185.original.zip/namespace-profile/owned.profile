abi <abi/4.0>,
profile vast-ci-userns-cf1f063c671b40e9aa2938b5f6ad0b2e /opt/hostedtoolcache/Python/3.12.3/x64/bin/python3.12 flags=(unconfined) {
  userns,
}
