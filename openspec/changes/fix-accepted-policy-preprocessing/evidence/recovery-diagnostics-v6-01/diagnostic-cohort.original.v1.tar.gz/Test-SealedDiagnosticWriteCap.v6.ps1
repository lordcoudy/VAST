# Fixture-only point-of-use check of the same bounded writer used by both outer layers.
param([Parameter(Mandatory=$true)][string]$Manifest)
$ErrorActionPreference='Stop'
try {
    if($args.Count){throw 'Fixture cap arguments refused'}
    . (Join-Path $PSScriptRoot 'Run-ColdDockerRecovery.v6.ps1')
    $fixture=Read-ColdDiagnosticFixture $Manifest
    $before=Get-ColdDiagnosticBytes $fixture.case_root
    try {
        Write-ColdDiagnosticBytes $fixture 'cap-target.bin' ([byte[]]::new(524288))
        throw 'Expected bounded writer refusal missing'
    } catch {
        if($_.Exception.Message -cne 'Fixture output cap'){throw}
        if((Get-ColdDiagnosticBytes $fixture.case_root) -ne $before -or (Test-Path -LiteralPath (Join-Path $fixture.case_root 'cap-target.bin'))){throw 'Cap refusal wrote output'}
        Write-Output '{"fixture":true,"recovery_acceptance":false,"point_of_use_cap_refused_before_write":true}'
        exit 0
    }
} catch {Write-Output (ConvertTo-Json @{fixture=$true;recovery_acceptance=$false;type=$_.Exception.GetType().FullName} -Compress);exit 1}
