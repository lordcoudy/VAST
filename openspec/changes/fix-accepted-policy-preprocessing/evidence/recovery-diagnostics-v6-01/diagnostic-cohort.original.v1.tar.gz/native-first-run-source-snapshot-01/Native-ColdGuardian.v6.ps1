# D7 diagnostics-only derivative of pinned Native-ColdGuardian.v1.ps1.
# No entrypoint, live namespace authority or change to the native lease record.
# Diagnostic causes stay in memory; no diagnostic I/O is added to publication.
function Invoke-ColdNativeEffect([string]$Name,[string]$Phase,[object[]]$Values=@()) {
    if ($null -ne $script:NativeDiagnosticEffects) {
        if (!$script:NativeDiagnosticFixture -or !$script:NativeDiagnosticEffects.ContainsKey($Name)) { throw 'Native fixture effect crossover refused' }
        return & $script:NativeDiagnosticEffects[$Name] $Phase @Values
    }
    if ($script:NativeDiagnosticFixture) { throw 'Native fixture has no sealed effect provider' }
    switch -CaseSensitive ($Name) {
        tick { return [Diagnostics.Stopwatch]::GetTimestamp() }
        freeC { return [IO.DriveInfo]::new('C:\').AvailableFreeSpace }
        freeE { return [IO.DriveInfo]::new('E:\').AvailableFreeSpace }
        exists { return (Test-Path -LiteralPath $Values[0]) }
        utc { return [DateTimeOffset]::UtcNow.ToString('o') }
        write { [IO.File]::WriteAllText($Values[0],$Values[1],$utf8); return }
        move { [IO.File]::Move($Values[0],$Values[1],$true); return }
        append { [IO.File]::AppendAllText($Values[0],$Values[1],$utf8); return }
        sleep { Start-Sleep -Milliseconds $Values[0]; return }
        default { throw 'Unknown native effect refused' }
    }
}
function Add-ColdNativeCause([Exception]$Exception,[string]$Operation,[string]$Phase,[object]$StartTick,[object]$LastTick) {
    if ($null -eq $script:diagnosticCauses) { $script:diagnosticCauses=[Collections.Generic.List[object]]::new() }
    $types=[Collections.Generic.List[string]]::new()
    $hresults=[Collections.Generic.List[int]]::new()
    $inner=$Exception
    while ($null -ne $inner -and $types.Count -lt 8) {
        $type=$inner.GetType().FullName
        if ($type.Length -gt 256 -or $type -cnotmatch '^[A-Za-z0-9_.+`]+$') { $type='unavailable-exception-type' }
        $types.Add($type)
        $hresults.Add([int]$inner.HResult)
        $inner=$inner.InnerException
    }
    # Only fixed helper-owned reasons survive. Never retain arbitrary exception
    # messages, paths, command lines, process content or credentials.
    $reason=switch -CaseSensitive ($Exception.Message) {
        'Heartbeat floor or stopped state not admitted' { 'heartbeat-floor-or-stopped'; break }
        'Heartbeat temporary name collision' { 'heartbeat-temporary-collision'; break }
        'Heartbeat guardian stopped' { 'heartbeat-guardian-stopped'; break }
        'Heartbeat publication budget expired' { 'heartbeat-publication-budget'; break }
        'Heartbeat publication floor failed' { 'heartbeat-publication-floor'; break }
        'Heartbeat record exceeds bound' { 'heartbeat-record-bound'; break }
        'Heartbeat publication budget expired after I/O' { 'heartbeat-post-write-budget'; break }
        'Heartbeat publication returned late' { 'heartbeat-post-move-budget'; break }
        'Native fixture effect crossover refused' { 'fixture-effect-crossover-refused'; break }
        'Native fixture has no sealed effect provider' { 'fixture-provider-unavailable'; break }
        default { 'native-external-exception' }
    }
    $nativeCodes=@(foreach ($result in $hresults) {
        $unsigned=[BitConverter]::ToUInt32([BitConverter]::GetBytes($result),0)
        if (($unsigned -band 0xffff0000L) -eq 0x80070000L) { [int]($unsigned -band 65535) }
    })
    $cause=[ordered]@{
        operation=$Operation;phase=$Phase;reason_code=$reason;exception_types=$types.ToArray();
        hresult=[int]$Exception.HResult;hresult_chain=$hresults.ToArray();native_codes=$nativeCodes;
        exception_chain_truncated=($null -ne $inner);synthetic_provider=[bool]$script:NativeDiagnosticFixture;
        start_tick=$StartTick;last_observed_tick=$LastTick;clock_frequency=[Diagnostics.Stopwatch]::Frequency;
        elapsed_seconds=$(if ($null -ne $StartTick -and $null -ne $LastTick) { ($LastTick-$StartTick)/[double][Diagnostics.Stopwatch]::Frequency } else { $null });
        unavailable_timing_explicit=($null -eq $StartTick -or $null -eq $LastTick);
        internal_flush_close_observation='unavailable-inside-WriteAllText';exception_contents_retained=$false
    }
    if ($utf8.GetByteCount((ConvertTo-Json $cause -Depth 8 -Compress)) -gt 16384 -or $utf8.GetByteCount($reason) -gt 1024) {
        $cause=[ordered]@{operation=$Operation;phase=$Phase;reason_code='diagnostic-cause-bound';hresult=[int]$Exception.HResult;exception_types=@($types[0]);capture_failure=$true;synthetic_provider=[bool]$script:NativeDiagnosticFixture;exception_contents_retained=$false}
    }
    # Reserve a bounded final marker instead of growing a repeated-error list.
    if ($script:diagnosticCauses.Count -lt 31) { $script:diagnosticCauses.Add($cause) }
    elseif ($script:diagnosticCauses.Count -eq 31) { $script:diagnosticCauses.Add(@{operation=$Operation;phase=$Phase;reason_code='diagnostic-cause-count-bound';capture_failure=$true;synthetic_provider=[bool]$script:NativeDiagnosticFixture}) }
}
function Stop-NativeGuardian([string]$Reason) {
    $script:stopped = $true
    try {
        Invoke-ColdNativeEffect 'write' 'stop-write' @((Join-Path $control 'operator-stop'),$Reason)
        $script:stopMarkerWritten = $true
    } catch {
        Add-ColdNativeCause $_.Exception 'native-sticky-stop' 'stop-write' $null $null
        $guardianErrors.Add(@{stage='write-stop';type=$_.Exception.GetType().FullName})
    }
}
function Publish-NativeHeartbeat([long]$CFree,[long]$EFree) {
    $phase='admission'
    $moveStarted=$null
    $lastTick=$null
    try {
        if ($script:stopped -or $CFree -lt 40GB -or $EFree -lt 12GB) { throw 'Heartbeat floor or stopped state not admitted' }
        $sequence = $script:heartbeatSequence + 1
        $temporary = Join-Path $control ("heartbeat-" + $sequence + ".tmp")
        $phase='temporary-check'
        if (Invoke-ColdNativeEffect 'exists' $phase @($temporary)) { throw 'Heartbeat temporary name collision' }
        $phase='start-clock'
        $moveStarted = Invoke-ColdNativeEffect 'tick' $phase
        while ($true) {
            $phase='pre-check'
            if ($script:stopped) { throw 'Heartbeat guardian stopped' }
            $lastTick=Invoke-ColdNativeEffect 'tick' $phase
            if (($lastTick - $moveStarted) / [double][Diagnostics.Stopwatch]::Frequency -ge 1) { throw 'Heartbeat publication budget expired' }
            $phase='sample-c'
            $cNow = Invoke-ColdNativeEffect 'freeC' $phase
            $phase='sample-e'
            $eNow = Invoke-ColdNativeEffect 'freeE' $phase
            if ($null -eq $script:minimumC) { $script:minimumC = $cNow }
            if ($null -eq $script:minimumE) { $script:minimumE = $eNow }
            $script:minimumC = [Math]::Min($script:minimumC,$cNow)
            $script:minimumE = [Math]::Min($script:minimumE,$eNow)
            $phase='floor-check'
            if ($cNow -lt 40GB -or $eNow -lt 12GB) {
                Stop-NativeGuardian 'Native floor failed during bounded heartbeat publication.'
                throw 'Heartbeat publication floor failed'
            }
            $phase='encode'
            $record = [ordered]@{kind='native_cold_heartbeat_v1';session=$sessionId;seq=$sequence;c_free=$cNow;e_free=$eNow;utc=(Invoke-ColdNativeEffect 'utc' $phase)}
            $payload = (ConvertTo-Json $record -Compress) + [Environment]::NewLine
            if ($utf8.GetByteCount($payload) -gt 4096) { throw 'Heartbeat record exceeds bound' }
            $phase='write'
            Invoke-ColdNativeEffect 'write' $phase @($temporary,$payload)
            $phase='post-write'
            $lastTick=Invoke-ColdNativeEffect 'tick' $phase
            if ($script:stopped -or ($lastTick - $moveStarted) / [double][Diagnostics.Stopwatch]::Frequency -ge 1) { throw 'Heartbeat publication budget expired after I/O' }
            try {
                $phase='move'
                Invoke-ColdNativeEffect 'move' $phase @($temporary,(Join-Path $control 'guardian-heartbeat.json'))
                $phase='post-move'
                $lastTick=Invoke-ColdNativeEffect 'tick' $phase
                if ($script:stopped -or ($lastTick - $moveStarted) / [double][Diagnostics.Stopwatch]::Frequency -ge 1) {
                    Stop-NativeGuardian 'Heartbeat Move returned after the publication budget.'
                    throw 'Heartbeat publication returned late'
                }
                break
            } catch {
                $inner = $_.Exception.InnerException
                if ($null -eq $inner -or ($inner -isnot [IO.IOException] -and $inner -isnot [UnauthorizedAccessException])) { throw }
                $hresult = [BitConverter]::ToUInt32([BitConverter]::GetBytes([int]$inner.HResult),0)
                if (($hresult -band 0xffff0000L) -ne 0x80070000L) { throw }
                $code = $hresult -band 65535
                $lastTick=Invoke-ColdNativeEffect 'tick' $phase
                $elapsed = ($lastTick - $moveStarted) / [double][Diagnostics.Stopwatch]::Frequency
                if ($code -notin @(5,32,33) -or $elapsed -ge 1 -or $script:stopped) { throw }
                $script:publicationRetries += 1
                $phase='retry-record'
                $retry = @{seq=$sequence;native_code=$code;elapsed_seconds=$elapsed;c_free=$cNow;e_free=$eNow;utc=(Invoke-ColdNativeEffect 'utc' $phase)}
                Invoke-ColdNativeEffect 'append' $phase @((Join-Path $control 'guardian-publication-retries.jsonl'),((ConvertTo-Json $retry -Compress) + [Environment]::NewLine))
                $phase='retry-wait'
                Invoke-ColdNativeEffect 'sleep' $phase @(10)
            }
        }
        $script:heartbeatSequence = $sequence
        $phase='sample-record'
        Invoke-ColdNativeEffect 'append' $phase @((Join-Path $control 'guardian-samples.jsonl'),$payload)
    } catch {
        Add-ColdNativeCause $_.Exception 'native-heartbeat-publication' $phase $moveStarted $lastTick
        throw
    }
}
