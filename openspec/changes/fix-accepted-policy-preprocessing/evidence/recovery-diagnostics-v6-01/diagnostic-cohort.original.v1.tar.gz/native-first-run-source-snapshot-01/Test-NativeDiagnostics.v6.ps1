param(
    [Parameter(Mandatory=$true)][ValidateSet('RedAdmission','GreenNative')][string]$Suite,
    [Parameter(Mandatory=$true)][string]$Source,
    [Parameter(Mandatory=$true)][string]$SourceSha256,
    [Parameter(Mandatory=$true)][string]$OutputRoot
)
$ErrorActionPreference = 'Stop'
$utf8 = [Text.UTF8Encoding]::new($false)
if ((Get-FileHash -LiteralPath $Source -Algorithm SHA256).Hash.ToLowerInvariant() -cne $SourceSha256) { throw 'Pinned native fixture source drift' }
if ($Suite -ceq 'RedAdmission' -and $SourceSha256 -cne 'e2cbb87a20667aac6039993c70395c600dc861992b85f91260daee9f30a2314a') { throw 'RED must use original native helper' }
if (Test-Path -LiteralPath $OutputRoot) { throw 'Fixture output namespace occupied' }
[void][IO.Directory]::CreateDirectory($OutputRoot)
. $Source
function Assert-Fixture([bool]$Condition,[string]$Reason) { if (!$Condition) { throw $Reason } }
function Write-FixtureRecord([string]$Path,[object]$Record) {
    $bytes=$utf8.GetBytes((ConvertTo-Json $Record -Depth 16))
    if ($bytes.Length -gt 1MB) { throw 'Fixture case exceeds 1MiB' }
    $stream=[IO.File]::Open($Path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
    try { $stream.Write($bytes) } finally { $stream.Dispose() }
}
$cases = if ($Suite -ceq 'RedAdmission') { @('admission-floor') } else {
    @('admission-floor','sample-failure','write-failure','flush-labelled-failure','move-failure','post-write-budget','post-move-budget','operator-stop','graceful','sanitized-cause')
}
$rows=[Collections.Generic.List[object]]::new()
$failed=$false
foreach ($case in $cases) {
    $control=Join-Path $OutputRoot $case
    [void][IO.Directory]::CreateDirectory($control)
    $sessionId='diagnostics-fixture-v6-'+$case
    $script:heartbeatSequence=[long]0
    $script:publicationRetries=[long]0
    $script:stopped=$false
    $script:stopMarkerWritten=$false
    $script:minimumC=$null
    $script:minimumE=$null
    $script:diagnosticCauses=[Collections.Generic.List[object]]::new()
    $guardianErrors=[Collections.Generic.List[object]]::new()
    $script:NativeDiagnosticFixture=$true
    $script:NativeDiagnosticFault=$case
    $script:NativeDiagnosticEffects=@{
        tick={ param($phase)
            if (($script:NativeDiagnosticFault -ceq 'post-write-budget' -and $phase -ceq 'post-write') -or
                ($script:NativeDiagnosticFault -ceq 'post-move-budget' -and $phase -ceq 'post-move')) { return [long](2*[Diagnostics.Stopwatch]::Frequency) }
            return [long]0
        }
        freeC={ param($phase)
            if ($script:NativeDiagnosticFault -ceq 'sample-failure') { throw [InvalidOperationException]::new('fixture sample failure') }
            return [long]45GB
        }
        freeE={ param($phase) return [long]20GB }
        exists={ param($phase,$path) return $false }
        utc={ param($phase) return '1970-01-01T00:00:00.0000000Z' }
        write={ param($phase,$path,$payload)
            if ($script:NativeDiagnosticFault -cin @('write-failure','flush-labelled-failure')) { throw [IO.IOException]::new('fixture controlled write/flush failure') }
            if ($script:NativeDiagnosticFault -ceq 'sanitized-cause') { throw [IO.IOException]::new(('secret-token-fixture-only='+'x'*4096)) }
        }
        move={ param($phase,$from,$to)
            if ($script:NativeDiagnosticFault -ceq 'move-failure') { throw [InvalidOperationException]::new('fixture move failure') }
        }
        append={ param($phase,$path,$payload) }
        sleep={ param($phase,$milliseconds) }
    }
    $caught=$null
    $assertion=$null
    try {
        if ($case -ceq 'operator-stop') { Stop-NativeGuardian 'fixture operator stop' }
        $cFree=if ($case -ceq 'admission-floor') { [long]39GB } else { [long]45GB }
        try { Publish-NativeHeartbeat $cFree ([long]20GB) } catch { $caught=$_.Exception }
        if ($case -ceq 'graceful') {
            Assert-Fixture ($null -eq $caught -and $script:heartbeatSequence -eq 1 -and !$script:stopped) 'Synthetic graceful publication did not retain its outcome'
            Assert-Fixture ($script:diagnosticCauses.Count -eq 0) 'Graceful synthetic publication fabricated a cause'
        } else {
            Assert-Fixture ($null -ne $caught) 'Controlled native failure was accepted'
            Assert-Fixture ($script:diagnosticCauses.Count -gt 0) 'Initiating native failure phase/cause was lost'
            $cause=$script:diagnosticCauses[0]
            Assert-Fixture ($cause.operation -ceq 'native-heartbeat-publication' -and $cause.synthetic_provider -eq $true) 'Native cause lacks bounded fixture identity'
            $expected=@{
                'admission-floor'='admission'; 'sample-failure'='sample-c'; 'write-failure'='write';
                'flush-labelled-failure'='write'; 'move-failure'='move'; 'post-write-budget'='post-write';
                'post-move-budget'='post-move'; 'operator-stop'='admission'; 'sanitized-cause'='write'
            }[$case]
            Assert-Fixture ($cause.phase -ceq $expected) 'Native failure phase drifted'
            Assert-Fixture ($cause.internal_flush_close_observation -ceq 'unavailable-inside-WriteAllText') 'Unobserved internal flush/close was fabricated'
            Assert-Fixture ($null -ne $cause.hresult -and $cause.exception_types.Count -gt 0) 'Native exception identity/HRESULT lost'
            $serialized=ConvertTo-Json $cause -Depth 10 -Compress
            Assert-Fixture ($utf8.GetByteCount($serialized) -le 16384 -and $utf8.GetByteCount($cause.reason_code) -le 1024) 'Native typed cause/reason exceeded bound'
            Assert-Fixture (!$serialized.Contains('secret-token-fixture-only') -and !$serialized.Contains('xxxx')) 'Exception contents leaked into native diagnostics'
            if ($case -ceq 'post-move-budget') { Assert-Fixture ($script:stopped -and $script:stopMarkerWritten) 'Late publication cleared sticky stop' }
            if ($case -ceq 'operator-stop') { Assert-Fixture ($script:stopped -and $script:stopMarkerWritten) 'Operator stop was cleared' }
        }
    } catch { $assertion=$_.Exception.Message; $failed=$true }
    $record=[ordered]@{
        kind='cold_native_diagnostics_fixture_v6';case_id=$case;fixture=$true;recovery_acceptance=$false;
        source_sha256=$SourceSha256;clock_provider='finite-synthetic-ticks';effect_provider='finite-fixture-effects';
        observed_exception_type=$(if ($caught) { $caught.GetType().FullName } else { $null });
        diagnostic_causes=@($script:diagnosticCauses.ToArray());guardian_errors=@($guardianErrors.ToArray());
        heartbeat_advances=$script:heartbeatSequence;guardian_stopped=$script:stopped;stop_marker_written=$script:stopMarkerWritten;
        assertion_passed=($null -eq $assertion);assertion_failure=$assertion
    }
    Write-FixtureRecord (Join-Path $control 'result.original.v1.json') $record
    $rows.Add(@{case_id=$case;assertion_passed=($null -eq $assertion)})
}
$script:NativeDiagnosticEffects=$null
$script:NativeDiagnosticFixture=$false
Write-FixtureRecord (Join-Path $OutputRoot 'suite.original.v1.json') @{kind='cold_native_diagnostics_suite_v6';fixture=$true;recovery_acceptance=$false;source_sha256=$SourceSha256;cases=$rows.ToArray();successful=(!$failed)}
Write-Output (ConvertTo-Json @{suite=$Suite;cases=$rows.Count;successful=(!$failed);fixture=$true;recovery_acceptance=$false} -Compress)
if ($failed) { exit 1 }
exit 0
