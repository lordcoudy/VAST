# D7 fixture-only derivative of recorder v3 (de2d4bf4...). Original return codes stay independent.
param([string]$DiagnosticFixture)
$ErrorActionPreference='Stop'
$utf8=[Text.UTF8Encoding]::new($false)
try {
    if ([string]::IsNullOrEmpty($DiagnosticFixture) -or $args.Count) { throw 'D7 fixture-only recorder dispatch refused' }
    $sealedManifestPath=$DiagnosticFixture
    . (Join-Path $PSScriptRoot 'Run-ColdDockerRecovery.v6.ps1')
    $fixture=Read-ColdDiagnosticFixture $sealedManifestPath
    $frame=New-ColdDiagnosticFrame 'recorder'
    Set-ColdDiagnosticIdentity $fixture $frame
    [void](Invoke-ColdDiagnosticCapture $fixture $frame ([Environment]::ProcessPath) @('-NoLogo','-NoProfile','-NonInteractive','-File',(Join-Path $PSScriptRoot 'Run-ColdDockerRecovery.v6.ps1'),'-DiagnosticFixture',$sealedManifestPath) $null)
    $result=@(Complete-ColdDiagnosticLayer $fixture $frame 'launcher.result.v6.json')
    foreach($value in $result){if($value -is [string]){Write-Output $value}}
    if($result[-1]){exit 0}else{exit 1}
} catch { Write-Output (ConvertTo-Json @{fixture=$true;recovery_acceptance=$false;entrypoint_failure_type=$_.Exception.GetType().FullName} -Compress);exit 1 }
