"""ONE cold03 recovery test (proposal 3a255914, amendments 8a1e58e6 and 8d2b9d4d).

`admission` mode runs in the distro's host PID namespace (actors, apt quiet window); the default mode
runs only inside fresh mount/net/PID namespaces with the provision03 authenticated runtime03 and the
host-library allowlist. Exact Size/RootFS/tags/digests equality; no tolerance, no image deletion.
"""
import hashlib
import importlib.util
import stat
import sys
import ctypes
import json
import os
import posixpath
import re
from email.utils import parsedate_to_datetime
from pathlib import Path
import shutil
import signal
import subprocess
import time

ROOT = Path('/mnt/e/VAST-cold03-a3990e2870c940149785831b845aea91')
HELPERS = ROOT / 'helpers-cold03'
LAUNCH = ROOT / 'cold-launch03'
CONTROL = ROOT / 'cold03'
DISK = CONTROL / 'cold-store.ext4'
MOUNT = Path('/run/vhc-a3990e28c')
OLD_ROOT = Path('/mnt/e/STUDY/VAST/tmp/host-cache-cleanup-20261012/s3-host-archive-3518d90e1d1d48edb2c740e536df6435')
ARCHIVE = OLD_ROOT / 'upload03/docker-all-227.downloaded.tar'
METADATA = OLD_ROOT / 'inventory.downloaded.jsonl'
BACKUP_RESULT = OLD_ROOT / 'finalize04/result.v1.json'
EXPECTED_METADATA = 'd8c5c7ab248d2a574eea502e2ad8729358bd77938fed655788f4acde91772a0e'
EXPECTED_ARCHIVE_SHA256 = '9571a6587b0ca1e74d53c578d5120bd74aa7646efe98e913d5fd3516ce65e230'
NAMESPACE = 'vast-cold-a3990e28c'
LIMIT = 100 * 1024 ** 3
SESSION = 'a3990e2870c940149785831b845aea91-cold03'
PROPOSAL_SHA256 = '3a255914382e5eede40dab94d4e5cb70b88b114e5fe4bbe2694faf20abd2444d'
AMENDMENT_SHA256 = '8a1e58e6da3cb63a25af07a632199f508f2e8e6ff8cc8f332d718c6820ea5ce3'
RETRY_AMENDMENT_SHA256 = 'b70f3601eb52d7706179fef7a607371c289d4b5ed2ddb0f1778c43c7c8820965'
LIBRARY_AMENDMENT_SHA256 = '8d2b9d4dd1ca4b6cda5ce5a0a4807582af34bf46e1f9f02449d69054416f420e'
KEY_FINGERPRINT = '9DC858229FC7DD38854AE2D88D81803C0EBFCD88'
UBUNTU_PRIMARY = 'F6ECB3762474EDA9D21B7022871920D1991BC93C'
RUNTIME_SESSION = 'a3990e2870c940149785831b845aea91-runtime03'
PROVISION_SESSION = 'a3990e2870c940149785831b845aea91-provision03'
RUNTIME_DIRECTORY = ROOT / 'runtime03'
RUNTIME_ROOT = RUNTIME_DIRECTORY / 'rootfs'
RUNTIME_MANIFEST = RUNTIME_DIRECTORY / 'runtime_manifest.v1.json'
PROVISION_DIRECTORY = ROOT / 'provision03'
RUNTIME_RECEIPT = PROVISION_DIRECTORY / 'result.v1.json'
PROVISIONER_SHA256 = 'fde339a8a8e9ea14d2676e11b3cc761fe184768fceb8b7788e3e8ed8731ecd80'
RUNTIME_BINARIES = {'dockerd': 'usr/bin/dockerd', 'docker': 'usr/bin/docker', 'containerd': 'usr/bin/containerd',
                    'ctr': 'usr/bin/ctr', 'runc': 'usr/bin/runc', 'containerd-shim-runc-v2': 'usr/bin/containerd-shim-runc-v2',
                    'docker-proxy': 'usr/bin/docker-proxy', 'docker-init': 'usr/libexec/docker/docker-init'}
VERSION_FLAGS = {'dockerd': '--version', 'docker': '--version', 'containerd': '--version', 'ctr': '--version',
                 'runc': '--version', 'containerd-shim-runc-v2': '-v', 'docker-proxy': '-v', 'docker-init': '--version'}
LOADER = '/lib64/ld-linux-x86-64.so.2'
ELF_SHAPE = {'dockerd': (LOADER, ['libc.so.6', 'libsystemd.so.0']), 'runc': (LOADER, ['libc.so.6', 'libseccomp.so.2']),
             'docker': (LOADER, ['libc.so.6']), 'containerd': (LOADER, ['libc.so.6']), 'ctr': (LOADER, ['libc.so.6']),
             'docker-proxy': (LOADER, ['libc.so.6']), 'containerd-shim-runc-v2': (None, []), 'docker-init': (None, [])}
REQUIRED_PACKAGE_VERSIONS = {'docker-ce': '5:29.8.1-1~ubuntu.24.04~noble',
                             'docker-ce-cli': '5:29.8.1-1~ubuntu.24.04~noble',
                             'containerd.io': '2.3.5-1~ubuntu.24.04~noble'}
EXPECTED_VERSIONS = {'docker_version': '29.8.1', 'docker_commit': '464cd50',
                     'containerd_version': '2.3.5', 'containerd_commit': '1294c24a7da8e5a793ed378161673abe94118892',
                     'runc_version': '1.5.1', 'runc_commit': '8f2685a4'}
LIBDIR = 'usr/lib/x86_64-linux-gnu/'
HOST_DIRS = ('usr', 'usr/lib', 'usr/lib/x86_64-linux-gnu', 'usr/lib64')
ACTOR_PATTERN = re.compile(r'provision_cold_runtime|cold_restore_docker|run_isolated_cold_restore|'
                           r'publication_qualification|full-qualification-runbook')
APT_ACTORS = {'apt', 'apt-get', 'dpkg', 'unattended-upgrade', 'packagekitd'}
APT_SCRIPTS = {'unattended-upgrade', 'apt.systemd.daily'}
APT_TIMERS = ('apt-daily.timer', 'apt-daily-upgrade.timer')
APT_SERVICES = ('apt-daily.service', 'apt-daily-upgrade.service')
TIMER_MARGIN_SECONDS = 3600
GUEST_SECONDS = 3 * 3600
PHASE_WINDOW_SECONDS = GUEST_SECONDS + 600
RUNTIME_PROOF = None
HOST_LIBRARY_BASELINE = None
DEADLINE = time.monotonic() + GUEST_SECONDS
ENV = {'PATH': str(RUNTIME_ROOT / 'usr/bin'), 'HOME': str(MOUNT / 'home'),
       'TMPDIR': str(MOUNT / 'tmp'), 'LANG': 'C', 'LC_ALL': 'C'}
DAEMONS = []
LOOP = None
MOUNTED = False
MOUNT_CREATED = False
SEQUENCE = 0
CREATED = False
STOPPED = False
LAST_HEARTBEAT_SNAPSHOT = None
LAST_HEARTBEAT_READ = None
LEASE = None


def fail(reason):
    raise RuntimeError(reason)


def unique_json_fields(pairs):
    value = {}
    for name, item in pairs:
        if name in value:
            raise ValueError('duplicate_json_field')
        value[name] = item
    return value


# ---------------------------------------------------------------- pure validators (unit tested)

def concurrent_actors(own_pid, proc=Path('/proc')):
    ancestors, current = set(), own_pid
    while current > 1 and current not in ancestors:
        ancestors.add(current)
        try:
            current = int((proc / str(current) / 'stat').read_text().rsplit(')', 1)[1].split()[1])
        except (OSError, ValueError, IndexError):
            break
    actors = []
    for entry in proc.iterdir():
        if not entry.name.isdigit() or int(entry.name) in ancestors:
            continue
        try:
            raw = (entry / 'cmdline').read_bytes()
        except OSError:
            continue
        argv = [part.decode('utf-8', 'replace') for part in raw.split(b'\0') if part]
        command = ' '.join(argv)
        basenames = [posixpath.basename(part) for part in argv[:2]]
        apt = bool(basenames) and (basenames[0] in APT_ACTORS or (len(basenames) > 1 and basenames[1] in APT_SCRIPTS))
        if ACTOR_PATTERN.search(command) or apt:
            actors.append({'pid': int(entry.name), 'kind': 'package_manager' if apt else 'qualification_or_cold',
                           'command_sha256': hashlib.sha256(command.encode()).hexdigest()})
    return actors


def validate_apt_quiet(timers_json, active_text, now_us, window_seconds):
    states = active_text.split('\n')
    if states and states[-1] == '':
        states.pop()
    if len(states) != len(APT_SERVICES) or any(state not in {'inactive', 'failed'} for state in states):
        fail('apt_service_active_or_unknown')
    timers = {row.get('unit'): row for row in json.loads(timers_json)}
    record = {}
    for unit in APT_TIMERS:
        scheduled = timers.get(unit, {}).get('next')
        if type(scheduled) is not int or scheduled <= 0:
            fail('apt_timer_next_elapse_unknown')
        if scheduled - now_us < (window_seconds + TIMER_MARGIN_SECONDS) * 1_000_000:
            fail('apt_timer_within_phase_window_margin')
        record[unit] = scheduled
    return {'services': dict(zip(APT_SERVICES, states)), 'timer_next_elapse_us': record, 'now_us': now_us,
            'window_seconds': window_seconds, 'margin_seconds': TIMER_MARGIN_SECONDS}


def validate_versions(outputs):
    for name in ('docker', 'dockerd'):
        match = re.fullmatch(r'Docker version 29\.8\.1, build ([0-9a-f]+)\n?', outputs.get(name, ''))
        if match is None or (name == 'dockerd' and match[1] != '464cd50'):
            fail('docker_version_or_engine_commit_mismatch')
    if re.fullmatch(r'containerd containerd v2\.3\.5 1294c24a7da8e5a793ed378161673abe94118892\n?', outputs.get('containerd', '')) is None:
        fail('containerd_version_or_commit_mismatch')
    if re.fullmatch(r'ctr containerd v2\.3\.5\n?', outputs.get('ctr', '')) is None:
        fail('ctr_package_or_version_mismatch')
    runc = outputs.get('runc', '')
    if re.search(r'^runc version 1\.5\.1$', runc, re.M) is None or re.search(r'^commit: (?:v1\.5\.1-0-g)?8f2685a4(?:[0-9a-f]*)$', runc, re.M) is None:
        fail('runc_version_or_commit_mismatch')
    if re.fullmatch(r'docker-proxy \(commit 464cd50\) version 29\.8\.1\n?', outputs.get('docker-proxy', '')) is None:
        fail('proxy_version_or_commit_mismatch')
    shim = outputs.get('containerd-shim-runc-v2', '')
    if re.search(r'^\s*Version:\s+v2\.3\.5$', shim, re.M) is None or \
            re.search(r'^\s*Revision:\s+1294c24a7da8e5a793ed378161673abe94118892$', shim, re.M) is None:
        fail('shim_version_or_commit_mismatch')
    if re.fullmatch(r'tini version 0\.19\.0(?: - git\.[0-9a-f]+)?\n?', outputs.get('docker-init', '')) is None:
        fail('docker_init_version_mismatch')


def projection_differences(expected_images, actual_images):
    by_id = {image['Id']: image for image in actual_images}
    if len(by_id) != len(actual_images):
        fail('cold_duplicate_restored_root')
    differences = []
    for expected in expected_images:
        restored = by_id.get(expected['Id'], {})
        for field in ['Id', 'RootFS', 'Size', 'RepoTags', 'RepoDigests']:
            a, b = expected.get(field), restored.get(field)
            if field in {'RepoTags', 'RepoDigests'}:
                a, b = sorted(a or []), sorted(b or [])
            if a != b:
                differences.append({'id': expected['Id'], 'field': field, 'expected': a, 'actual': b})
    return differences


def parse_maps(text):
    rows = []
    for line in text.splitlines():
        parts = line.split(None, 5)
        if len(parts) < 5:
            fail('maps_line_malformed')
        major, minor = parts[3].split(':')
        rows.append({'perms': parts[1], 'dev': (int(major, 16), int(minor, 16)), 'inode': int(parts[4]),
                     'path': parts[5] if len(parts) == 6 else ''})
    return rows


def validate_maps(rows, executable_identities, readable_identities, store_dev):
    """Executable file mappings: pinned (dev, inode) only. Other file mappings: pinned or the owned ext4 store."""
    pseudo = {'', '[heap]', '[stack]', '[vdso]', '[vvar]', '[vsyscall]'}
    violations = []
    for row in rows:
        if row['path'].endswith(' (deleted)'):
            violations.append({'reason': 'deleted_mapping', **row})
        elif row['inode'] == 0:
            if row['path'] not in pseudo and not row['path'].startswith('[anon'):
                violations.append({'reason': 'unexpected_pseudo_mapping', **row})
        elif 'x' in row['perms']:
            if (row['dev'], row['inode']) not in executable_identities:
                violations.append({'reason': 'executable_mapping_not_allowlisted', **row})
        elif (row['dev'], row['inode']) not in readable_identities and row['dev'] != store_dev:
            violations.append({'reason': 'file_mapping_outside_store_or_allowlist', **row})
    return violations


def validate_manifest(manifest, receipt, expected_sha, manifest_path):
    """Reviewed identity of the provision03 receipt/manifest (content checks; files are re-verified separately)."""
    if (receipt.get('schema_version') != 1 or receipt.get('status') != 'authenticated_runtime_provisioned'
            or receipt.get('session') != PROVISION_SESSION or receipt.get('manifest_path') != str(manifest_path)
            or receipt.get('manifest_sha256') != expected_sha or receipt.get('provisioner_sha256') != PROVISIONER_SHA256
            or receipt.get('amendment_sha256') != AMENDMENT_SHA256
            or receipt.get('library_amendment_sha256') != LIBRARY_AMENDMENT_SHA256
            or receipt.get('retry_amendment_sha256') != RETRY_AMENDMENT_SHA256):
        fail('runtime_original_provision_receipt_invalid')
    if (manifest.get('schema_version') != 1 or manifest.get('status') != 'authenticated_runtime'
            or manifest.get('session') != RUNTIME_SESSION or manifest.get('proposal_sha256') != PROPOSAL_SHA256
            or manifest.get('amendment_sha256') != AMENDMENT_SHA256
            or manifest.get('library_amendment_sha256') != LIBRARY_AMENDMENT_SHA256
            or manifest.get('retry_amendment_sha256') != RETRY_AMENDMENT_SHA256
            or manifest.get('runtime_root') != str(RUNTIME_ROOT) or manifest.get('provisioner_sha256') != PROVISIONER_SHA256
            or manifest.get('expected_versions') != EXPECTED_VERSIONS):
        fail('runtime_reviewed_identity_mismatch')
    auth = manifest.get('authenticated_repository', {})
    headers = auth.get('release_headers', {})
    if (auth.get('key_primary_fingerprint') != KEY_FINGERPRINT or headers.get('Origin') != 'Docker'
            or headers.get('Label') != 'Docker CE' or headers.get('Suite') != 'noble'
            or ('Codename' in headers) != auth.get('codename_present')
            or ('Codename' in headers and headers['Codename'] != 'noble')
            or 'amd64' not in headers.get('Architectures', '').split() or 'stable' not in headers.get('Components', '').split()):
        fail('runtime_repository_identity_mismatch')
    packages = manifest.get('packages', [])
    if len(packages) != 3 or {package.get('name') for package in packages} != set(REQUIRED_PACKAGE_VERSIONS) or \
            any(package.get('version') != REQUIRED_PACKAGE_VERSIONS[package['name']] for package in packages):
        fail('runtime_required_package_set_mismatch')
    commands = receipt.get('original_commands', [])
    labels = [command.get('label') for command in commands]
    required = {'key-import', 'certificate-check', 'keyring-export', 'release-signature', 'ubuntu-key-import',
                'ubuntu-certificate-check', 'ubuntu-keyring-export'}
    if (not commands or manifest.get('original_commands') != commands or len(set(labels)) != len(labels)
            or not required.issubset(labels)
            or any(type(command.get('original_returncode')) is not int or command['original_returncode'] != 0
                   or command.get('interrupted_error') is not None or command.get('sigterm_sent') is not False
                   or command.get('forced_kill') is not False for command in commands)):
        fail('runtime_original_authentication_commands_not_complete')
    executables = manifest.get('executables', {})
    if set(executables) != set(RUNTIME_BINARIES):
        fail('runtime_missing_or_unreviewed_executable')
    outputs = {}
    for name, record in executables.items():
        path = RUNTIME_ROOT / RUNTIME_BINARIES[name]
        interp, needed = ELF_SHAPE[name]
        if (record.get('path') != str(path) or record.get('version_argv') != [str(path), VERSION_FLAGS[name]]
                or record.get('elf_dependency_validation') != {'interp': interp, 'needed': needed, 'rpath_or_runpath': False}
                or record.get('executed_from_verified_descriptor') is not True):
            fail('runtime_executable_identity_mismatch')
        outputs[name] = record.get('version_output', '')
    validate_versions(outputs)
    host = manifest.get('host_libraries', {})
    if host.get('library_amendment_sha256') != LIBRARY_AMENDMENT_SHA256 or host.get('anchor_fingerprint') != UBUNTU_PRIMARY or \
            not host.get('installed_snapshot', {}).get('files') or manifest.get('runtime_environment_after') != manifest.get('runtime_environment_before'):
        fail('runtime_host_library_authentication_missing')
    return manifest


# ---------------------------------------------------------------- runtime helpers

def write_json(name, value):
    with (CONTROL / name).open('x') as file:
        json.dump(value, file, sort_keys=True, indent=2)
        file.write('\n')


def read_native_heartbeat():
    global LAST_HEARTBEAT_READ
    heartbeat = LAUNCH / 'guardian-heartbeat.json'
    LAST_HEARTBEAT_READ = {'phase': 'open', 'monotonic_now': time.monotonic()}
    try:
        descriptor = os.open(heartbeat, os.O_RDONLY | os.O_NOFOLLOW)
        with os.fdopen(descriptor, 'rb') as file:
            identity = os.fstat(file.fileno())
            if not stat.S_ISREG(identity.st_mode) or identity.st_nlink not in {0, 1}:
                raise ValueError('heartbeat_not_regular_or_has_multiple_links')
            payload = file.read(4097)
        LAST_HEARTBEAT_READ = {'phase': 'decode', 'monotonic_now': time.monotonic(), 'bytes': len(payload),
                               'payload_sha256': hashlib.sha256(payload).hexdigest()}
        if not payload or len(payload) > 4096:
            raise ValueError('heartbeat_payload_outside_bound')
        value = json.loads(payload.decode('utf-8'), object_pairs_hook=unique_json_fields)
        LAST_HEARTBEAT_READ['phase'] = 'complete'
        return value
    except (OSError, ValueError) as error:
        LAST_HEARTBEAT_READ['error_type'] = type(error).__name__
        LAST_HEARTBEAT_READ['errno'] = getattr(error, 'errno', None)
        raise


def load_lease():
    global LEASE
    lease_path = Path(__file__).with_name('native_heartbeat_lease_v1.py')
    if hashlib.sha256(lease_path.read_bytes()).hexdigest() != '8aae687de0b919f90c8a12f34bc7798920bc0c41250049aef3595225a4bd7fb4':
        fail('heartbeat_lease_recipe_drift')
    specification = importlib.util.spec_from_file_location('native_cold_heartbeat_lease', lease_path)
    module = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = module
    specification.loader.exec_module(module)
    LEASE = module.HeartbeatLease(SESSION, read_native_heartbeat)


def check_runtime_state():
    global STOPPED
    if time.monotonic() > DEADLINE:
        fail('cold_test_deadline')
    if (CONTROL / 'operator-stop').exists() or (LAUNCH / 'operator-stop').exists():
        STOPPED = True
    if STOPPED:
        fail('cold_operator_stop_latched')


def alarm_guard():
    if time.monotonic() > DEADLINE or STOPPED:
        fail('cold_deadline_or_latched_stop')
    if LEASE is not None:
        LEASE.check_expiry()


def guard():
    global LAST_HEARTBEAT_SNAPSHOT
    check_runtime_state()
    armed = LEASE.observe()
    if shutil.disk_usage(ROOT).free < 12 * 1024 ** 3:
        fail('E_floor_not_met')
    if MOUNTED and shutil.disk_usage(MOUNT).free < 5 * 1024 ** 3:
        fail('cold_filesystem_reserve_not_met')
    LEASE.check_expiry()
    LAST_HEARTBEAT_SNAPSHOT = LEASE.snapshot()
    return armed


def arm_native_heartbeat():
    while not guard():
        time.sleep(0.25)
    write_json('heartbeat-armed.v1.json', LAST_HEARTBEAT_SNAPSHOT)


def no_redirected_path(path, root):
    if not path.is_absolute() or not root.is_absolute():
        fail('runtime_path_not_absolute')
    try:
        relative = path.relative_to(root)
    except ValueError as error:
        raise RuntimeError('runtime_path_outside_private_root') from error
    if any(part in {'.', '..'} for part in relative.parts):
        fail('runtime_path_traversal')
    for ancestor in [path, *path.parents]:
        if ancestor.is_symlink():
            fail('runtime_redirected_ancestor')
    if path.resolve() != path:
        fail('runtime_path_resolution_changed')


def digest_descriptor(descriptor):
    before = os.fstat(descriptor)
    digest, offset = hashlib.sha256(), 0
    while payload := os.pread(descriptor, 8 * 1024 ** 2, offset):
        guard()
        digest.update(payload)
        offset += len(payload)
    after = os.fstat(descriptor)
    identity = [before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns]
    if identity != [after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns] or offset != before.st_size:
        fail('file_changed_while_hashing')
    return {'sha256': digest.hexdigest(), 'size': before.st_size, 'identity': identity}


def held_file(path):
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    if not stat.S_ISREG(os.fstat(descriptor).st_mode):
        os.close(descriptor)
        fail('held_input_not_regular')
    return descriptor


def read_held(path, limit):
    descriptor = held_file(path)
    try:
        record = digest_descriptor(descriptor)
        if record['size'] > limit:
            fail('held_input_outside_bound')
        payload = os.pread(descriptor, limit + 1, 0)
        if digest_descriptor(descriptor) != record or hashlib.sha256(payload).hexdigest() != record['sha256']:
            fail('held_input_changed_while_reading')
    finally:
        os.close(descriptor)
    return payload, record


def verify_runtime_file(path, record):
    descriptor = held_file(path)
    try:
        identity = os.fstat(descriptor)
        if identity.st_nlink != 1 or identity.st_size != record['size']:
            fail('runtime_file_identity_changed')
        if digest_descriptor(descriptor)['sha256'] != record['sha256']:
            fail('runtime_file_hash_changed')
    finally:
        os.close(descriptor)
    return (identity.st_dev, identity.st_ino)


def host_snapshot():
    """Same structure as the provisioner's host_library_snapshot, for exact equality with the authenticated state."""
    baseline = RUNTIME_PROOF['host_libraries']['installed_snapshot']
    snapshot = {'directories': {}, 'merged_links': {}, 'links': {}, 'files': {}}
    for relative in HOST_DIRS:
        identity = (Path('/') / relative).lstat()
        if not stat.S_ISDIR(identity.st_mode) or identity.st_uid != 0 or identity.st_mode & 0o022:
            fail('host_library_directory_not_root_owned_unwritable')
        snapshot['directories'][relative] = [identity.st_dev, identity.st_ino, stat.S_IMODE(identity.st_mode)]
    for group in ('merged_links', 'links'):
        for relative, target in baseline[group].items():
            identity = (Path('/') / relative).lstat()
            if not stat.S_ISLNK(identity.st_mode) or identity.st_uid != 0 or os.readlink(Path('/') / relative) != target:
                fail('host_library_link_not_pinned')
            snapshot[group][relative] = target
    for relative in baseline['files']:
        descriptor = os.open(Path('/') / relative, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
        try:
            identity = os.fstat(descriptor)
            if not stat.S_ISREG(identity.st_mode) or identity.st_uid != 0 or identity.st_mode & 0o022:
                fail('host_library_not_root_owned_regular_unwritable')
            snapshot['files'][relative] = digest_descriptor(descriptor)
        finally:
            os.close(descriptor)
    return snapshot


def phase_environment():
    if os.path.lexists('/etc/ld.so.preload'):
        fail('ld_so_preload_present')
    descriptor = held_file('/etc/ld.so.cache')
    try:
        cache = digest_descriptor(descriptor)
    finally:
        os.close(descriptor)
    snapshot = host_snapshot()
    baseline = RUNTIME_PROOF['host_libraries']['installed_snapshot']
    comparable = lambda value: {group: ({path: [row['sha256'], row['size']] for path, row in value[group].items()}
                                        if group == 'files' else value[group]) for group in value}
    if comparable(snapshot) != comparable(baseline):
        fail('host_libraries_differ_from_authenticated_state')
    return {'ld_so_preload_absent': True, 'ld_so_cache': cache, 'host_libraries': snapshot}


def validate_runtime(expected_sha):
    if not re.fullmatch('[0-9a-f]{64}', expected_sha or ''):
        fail('runtime_manifest_identity_not_pinned')
    no_redirected_path(RUNTIME_MANIFEST, RUNTIME_DIRECTORY)
    no_redirected_path(RUNTIME_RECEIPT, PROVISION_DIRECTORY)
    manifest_bytes, manifest_record = read_held(RUNTIME_MANIFEST, 64 * 1024 ** 2)
    receipt_bytes, _ = read_held(RUNTIME_RECEIPT, 64 * 1024 ** 2)
    if manifest_record['sha256'] != expected_sha:
        fail('runtime_manifest_identity_changed')
    manifest = validate_manifest(json.loads(manifest_bytes, object_pairs_hook=unique_json_fields),
                                 json.loads(receipt_bytes, object_pairs_hook=unique_json_fields), expected_sha, RUNTIME_MANIFEST)
    no_redirected_path(RUNTIME_ROOT, RUNTIME_ROOT)
    records, symlinks, identities = {}, {}, {}
    for record in manifest.get('files', []):
        relative = Path(record.get('relative_path', ''))
        if not relative.parts or relative.is_absolute() or '..' in relative.parts or str(relative) in records:
            fail('runtime_file_inventory_invalid')
        path = RUNTIME_ROOT / relative
        no_redirected_path(path, RUNTIME_ROOT)
        identities[str(relative)] = verify_runtime_file(path, record)
        records[str(relative)] = record
    for record in manifest.get('symlinks', []):
        relative = Path(record.get('relative_path', ''))
        if not relative.parts or relative.is_absolute() or '..' in relative.parts or str(relative) in symlinks:
            fail('runtime_symlink_inventory_invalid')
        path = RUNTIME_ROOT / relative
        no_redirected_path(path.parent, RUNTIME_ROOT)
        if not path.is_symlink() or os.readlink(path) != record.get('target'):
            fail('runtime_symlink_identity_changed')
        resolved = path.resolve(strict=True)
        no_redirected_path(resolved, RUNTIME_ROOT)
        if str(resolved.relative_to(RUNTIME_ROOT)) != record.get('resolved_relative_path'):
            fail('runtime_symlink_resolution_changed')
        symlinks[str(relative)] = record
    actual_paths = set()
    for path in RUNTIME_ROOT.rglob('*'):
        guard()
        mode = path.lstat().st_mode
        if stat.S_ISDIR(mode):
            continue
        if not stat.S_ISREG(mode) and not stat.S_ISLNK(mode):
            fail('runtime_unreviewed_special_file')
        actual_paths.add(str(path.relative_to(RUNTIME_ROOT)))
    if actual_paths != set(records) | set(symlinks):
        fail('runtime_unverified_extracted_file')
    for name, relative in RUNTIME_BINARIES.items():
        record = manifest['executables'][name]
        if record.get('sha256') != records.get(relative, {}).get('sha256') or record.get('size') != records[relative]['size']:
            fail('runtime_executable_identity_mismatch')
    manifest['_runtime_identities'] = identities
    return manifest


def runtime_binary(name):
    if RUNTIME_PROOF is None or name not in RUNTIME_PROOF['executables']:
        fail('runtime_not_authenticated_before_execution')
    record = RUNTIME_PROOF['executables'][name]
    path = Path(record['path'])
    no_redirected_path(path, RUNTIME_ROOT)
    verify_runtime_file(path, record)
    return str(path)


def finish_process(process):
    frame = _frame("owned-child")
    actions = _finish_reporting_process(process,frame)
    actions["secondary_causes"] = frame["secondary"]
    return actions


def pause_finalization_signals():
    return _pause_reporting_signals(_frame("finalization"))


def resume_finalization_signals(state):
    return _resume_reporting_signals(state,_frame("finalization"))


def run(args,label,timeout=1800,check=True,guarded=True,stdin=subprocess.DEVNULL):
    return _reporting_run(args,label,timeout,check,guarded,stdin)


def daemon(args,label):
    if _DIAGNOSTIC_EFFECTS is not None:
        raise ValueError('fixture_daemon_crossover')
    if args[0]!=runtime_binary(Path(args[0]).name):
        fail('cold_unreviewed_daemon_path')
    output=(CONTROL/(label+'.stdout')).open('xb')
    error=(CONTROL/(label+'.stderr')).open('xb')
    process=subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=output,stderr=error,env=ENV)
    DAEMONS.append((process,output,error,label))
    frame=_frame(label)
    frame['requires_successful_exit']=False
    entry=_register_child(process,frame)
    entry['streams']=((output,'stdout'),(error,'stderr'))
    if entry['metadata_error'] is not None:
        raise entry['metadata_error']
    write_json(label+'.started.json',{'argv':args,'namespace_pid':process.pid})
    return process


def wait_socket(path, process):
    for _ in range(120):
        guard()
        if process.poll() is not None:
            fail('cold_daemon_stopped_before_ready')
        if path.exists() and path.is_socket():
            return
        time.sleep(0.5)
    fail('cold_daemon_socket_timeout')


def sample_daemon_maps(phase):
    """Maps gate over every owned daemon by (dev, inode) identity in this namespace."""
    executable = set(RUNTIME_PROOF['_runtime_identities'].values())
    for relative in RUNTIME_PROOF['host_libraries']['installed_snapshot']['files']:
        identity = os.stat(Path('/') / relative)
        executable.add((identity.st_dev, identity.st_ino))
    store = os.stat(MOUNT).st_dev
    record = {}
    for process, _, _, label in DAEMONS:
        if process.poll() is not None:
            fail('cold_daemon_exited_before_maps_sample')
        maps_text = Path('/proc/%d/maps' % process.pid).read_text()
        rows = parse_maps(maps_text)
        rows = [dict(row, dev=(os.makedev(*row['dev']),)[0]) for row in rows]
        violations = validate_maps(rows, executable, executable, store)
        record[label] = {'rows': len(rows), 'violations': violations,
                         'maps_sha256': hashlib.sha256(maps_text.encode()).hexdigest()}
        if violations:
            write_json('maps-' + phase + '.v1.json', record)
            fail('cold_daemon_mapping_not_allowlisted_' + label)
    write_json('maps-' + phase + '.v1.json', record)


# ---------------------------------------------------------------- modes

def admission():
    """Host PID namespace, before unshare: concurrent actors and apt quiet window (read-only)."""
    actors = concurrent_actors(os.getpid())
    if actors:
        fail('concurrent_mutating_actor_present')
    environment = {'PATH': '/usr/bin:/bin', 'LANG': 'C', 'LC_ALL': 'C'}
    active = subprocess.run(['/usr/bin/systemctl', 'is-active', *APT_SERVICES], stdin=subprocess.DEVNULL,
                            capture_output=True, env=environment, timeout=30)
    timers = subprocess.run(['/usr/bin/systemctl', 'list-timers', '--all', '--output=json', *APT_TIMERS],
                            stdin=subprocess.DEVNULL, capture_output=True, env=environment, timeout=30)
    if timers.returncode != 0 or active.returncode not in {0, 3}:
        fail('apt_admission_query_failed')
    record = validate_apt_quiet(timers.stdout.decode(), active.stdout.decode(), time.time_ns() // 1000, PHASE_WINDOW_SECONDS)
    print(json.dumps({'concurrent_actors': actors, 'apt_admission': record}, sort_keys=True))


def main():
    global CREATED, LOOP, MOUNTED, MOUNT_CREATED, RUNTIME_PROOF
    if os.getuid() != 0 or os.getpid() != 1:
        fail('requires_owned_root_PID_namespace')
    for name in ('mnt', 'net', 'pid'):
        parent = os.environ.get('VAST_COLD_PARENT_' + name.upper())
        if not parent or parent == os.readlink('/proc/self/ns/' + name):
            fail('missing_or_unisolated_' + name + '_namespace')
    admitted = json.loads(os.environ.get('VAST_COLD_ADMISSION', ''), object_pairs_hook=unique_json_fields)
    if admitted.get('concurrent_actors') != [] or set(admitted.get('apt_admission', {})) != \
            {'services', 'timer_next_elapse_us', 'now_us', 'window_seconds', 'margin_seconds'}:
        fail('cold_host_admission_missing')
    no_redirected_path(ROOT, ROOT)
    if Path(__file__).resolve(strict=True) != HELPERS / 'cold_restore_docker_archive_v5.py':
        fail('cold_helper_not_protected_copy')
    if not CONTROL.is_dir() or CONTROL.is_symlink() or any(CONTROL.iterdir()) or MOUNT.exists() or MOUNT.is_symlink():
        fail('cold_attempt_not_fresh_or_mount_exists')
    if shutil.disk_usage(ROOT).free < LIMIT + 12 * 1024 ** 3:
        fail('cold_E_budget_not_met')
    CREATED = True
    load_lease()
    arm_native_heartbeat()
    write_json('host-admission.v1.json', admitted)
    backup = json.loads(read_held(BACKUP_RESULT, 1024 ** 2)[0], object_pairs_hook=unique_json_fields)
    if backup.get('status') != 'archive_backup_full_readback_and_blob_graph_verified' or \
            backup.get('archive_sha256') != EXPECTED_ARCHIVE_SHA256:
        fail('S3_backup_not_complete')
    RUNTIME_PROOF = validate_runtime(os.environ.get('VAST_COLD_RUNTIME_MANIFEST_SHA256'))
    environment_before = phase_environment()
    write_json('authenticated-runtime-review.v1.json', {'manifest_sha256': os.environ['VAST_COLD_RUNTIME_MANIFEST_SHA256'],
        'proposal_sha256': PROPOSAL_SHA256, 'amendment_sha256': AMENDMENT_SHA256,
        'library_amendment_sha256': LIBRARY_AMENDMENT_SHA256, 'runtime_root': str(RUNTIME_ROOT),
        'host_library_environment_before': environment_before, 'runtime_dependency_fallback_allowed': False})
    # Held archive descriptor: hashed and later fed to the loader by the same open identity.
    archive = held_file(ARCHIVE)
    try:
        archive_record = digest_descriptor(archive)
        if archive_record['sha256'] != EXPECTED_ARCHIVE_SHA256 or archive_record['size'] != backup.get('archive_bytes'):
            fail('verified_archive_identity_changed')
        metadata, metadata_record = read_held(METADATA, 64 * 1024 ** 2)
        if metadata_record['sha256'] != EXPECTED_METADATA:
            fail('verified_inventory_identity_changed')
        images = [json.loads(line) for line in metadata.decode('utf-8').splitlines()]
        if len(images) != 227 or len({image['Id'] for image in images}) != 227:
            fail('cold_expected_image_cardinality')
        versions = {}
        for name in RUNTIME_BINARIES:
            proof = RUNTIME_PROOF['executables'][name]
            output = run([runtime_binary(name), proof['version_argv'][1]], 'version-' + name, timeout=30)
            versions[name] = output + (CONTROL / f'{SEQUENCE:04d}-version-{name}.stderr').read_text(errors='strict')
            if versions[name] != proof['version_output']:
                fail('authenticated_cold_runtime_version_drift')
        validate_versions(versions)
        write_json('start.v1.json', {'archive': archive_record, 'metadata': metadata_record, 'versions': versions,
            'disk_logical_limit_bytes': LIMIT, 'namespaces': {name: os.readlink('/proc/self/ns/' + name) for name in ('mnt', 'net', 'pid')}})
        run(['/usr/bin/truncate', '-s', str(LIMIT), str(DISK)], 'create-disk')
        run(['/usr/sbin/mkfs.ext4', '-F', '-m', '0', str(DISK)], 'format-owned-disk', timeout=300)
        LOOP = run(['/usr/sbin/losetup', '--find'], 'select-unused-loop', guarded=False).strip()
        if not LOOP.startswith('/dev/loop') or not LOOP[9:].isdigit() or LOOP in {'/dev/loop0', '/dev/loop1'}:
            fail('unreviewed_loop_device')
        run(['/usr/sbin/losetup', LOOP, str(DISK)], 'attach-exact-owned-loop', timeout=60, guarded=False)
        backing = run(['/usr/sbin/losetup', '--noheadings', '--raw', '--output', 'BACK-FILE', LOOP], 'loop-backing').strip()
        if Path(backing).resolve() != DISK.resolve():
            fail('loop_backing_mismatch')
        MOUNT.mkdir(mode=0o700)
        MOUNT_CREATED = True
        run(['/usr/bin/mount', '-t', 'ext4', '-o', 'nodev,nosuid', LOOP, str(MOUNT)], 'mount-owned-disk', timeout=60, guarded=False)
        MOUNTED = True
        os.chmod(MOUNT, 0o700)
        for name in ['tmp', 'home', 'client', 'cd-data', 'cd-state', 'opt', 'docker-data', 'docker-exec']:
            (MOUNT / name).mkdir(mode=0o700)
        for path in [MOUNT, *(MOUNT / name for name in ['tmp', 'home', 'client', 'cd-data', 'cd-state', 'opt', 'docker-data', 'docker-exec'])]:
            identity = path.lstat()
            if not stat.S_ISDIR(identity.st_mode) or identity.st_uid != 0 or stat.S_IMODE(identity.st_mode) != 0o700:
                fail('cold_ext4_owner_or_mode_not_private')
        cd_config = CONTROL / 'containerd.private.toml'
        with cd_config.open('x') as file:
            file.write('version = 4\nimports = []\n'
                f'root = "{MOUNT}/cd-data"\nstate = "{MOUNT}/cd-state"\ntemp = "{MOUNT}/tmp"\n'
                'disabled_plugins = ["io.containerd.grpc.v1.cri", "io.containerd.cri.v1.images", '
                '"io.containerd.cri.v1.runtime", "io.containerd.nri.v1.nri", "io.containerd.server.v1.grpc-tcp", '
                '"io.containerd.server.v1.debug", "io.containerd.server.v1.metrics"]\n'
                f'[plugins."io.containerd.server.v1.grpc"]\naddress = "{MOUNT}/c.sock"\n'
                f'[plugins."io.containerd.server.v1.ttrpc"]\naddress = "{MOUNT}/c.sock.ttrpc"\n'
                f'[plugins."io.containerd.internal.v1.opt"]\npath = "{MOUNT}/opt"\n')
        docker_config = {'data-root': str(MOUNT / 'docker-data'), 'exec-root': str(MOUNT / 'docker-exec'),
            'pidfile': str(MOUNT / 'd.pid'), 'hosts': ['unix://' + str(MOUNT / 'd.sock')],
            'containerd': str(MOUNT / 'c.sock'), 'containerd-namespace': NAMESPACE,
            'containerd-plugins-namespace': NAMESPACE + '-plugins',
            'features': {'containerd-snapshotter': True}, 'storage-driver': 'overlayfs',
            'bridge': 'none', 'iptables': False, 'ip6tables': False, 'ip-forward': False, 'ip-masq': False,
            'userland-proxy': False, 'debug': True}
        write_json('dockerd.private.json', docker_config)
        run([runtime_binary('dockerd'), '--validate', '--config-file', str(CONTROL / 'dockerd.private.json')], 'validate-dockerd')
        cd = daemon([runtime_binary('containerd'), '--config', str(cd_config)], 'containerd')
        wait_socket(MOUNT / 'c.sock', cd)
        engine = daemon([runtime_binary('dockerd'), '--config-file', str(CONTROL / 'dockerd.private.json'),
                         '--nri-opts', 'enable=false'], 'dockerd')
        wait_socket(MOUNT / 'd.sock', engine)
        sample_daemon_maps('ready')
        docker = [runtime_binary('docker'), '--config', str(MOUNT / 'client'), '--host', 'unix://' + str(MOUNT / 'd.sock')]
        ctr = [runtime_binary('ctr'), '--address', str(MOUNT / 'c.sock'), '--namespace', NAMESPACE]
        if run(docker + ['image', 'ls', '--all', '--quiet'], 'empty-docker').strip():
            fail('cold_Docker_not_empty')
        if run(ctr + ['content', 'ls', '--quiet'], 'empty-content').strip():
            fail('cold_content_not_empty')
        if len(run(ctr + ['snapshots', '--snapshotter', 'overlayfs', 'ls'], 'empty-snapshots').splitlines()) > 1:
            fail('cold_snapshots_not_empty')
        write_json('empty-store.v1.json', {'fresh_disk': True, 'docker_images': 0, 'containerd_content': 0})
        print(json.dumps({'phase': 'cold_load_into_empty_store', 'images': 227}), flush=True)
        os.lseek(archive, 0, os.SEEK_SET)
        run(docker + ['image', 'load'], 'load-archive', timeout=5400, stdin=archive)
        if digest_descriptor(archive) != archive_record:
            fail('verified_archive_changed_during_load')
    finally:
        os.close(archive)
    tags = 0
    for image in images:
        refs = run(ctr + ['images', 'list', '--quiet', 'target.digest==' + image['Id']], 'list-root-refs').splitlines()
        if not refs:
            fail('cold_root_reference_missing')
        ready = run(ctr + ['images', 'check', '--quiet', '--snapshotter', 'overlayfs',
                          'target.digest==' + image['Id']], 'check-root-unpacked').splitlines()
        if set(refs) != set(ready):
            fail('cold_root_content_or_unpack_not_ready')
        for tag in image.get('RepoTags') or []:
            if '@sha256:' in tag:
                name = 'docker.io/' + tag if tag.startswith('intel/') else tag
                run(ctr + ['images', 'tag', '--local', refs[0], name], 'restore-digest-name')
            else:
                run(docker + ['image', 'tag', image['Id'], tag], 'restore-tag')
            tags += 1
    template = '{"Id":{{json .Id}},"RepoTags":{{json .RepoTags}},"RepoDigests":{{json .RepoDigests}},"RootFS":{{json .RootFS}},"Size":{{json .Size}}}'
    actual = [json.loads(line) for line in run(docker + ['image', 'inspect', '--format', template,
               *[image['Id'] for image in images]], 'restored-inspect').splitlines()]
    differences = projection_differences(images, actual)
    write_json('projection-differences.v1.json', differences)
    if differences or len({image['Id'] for image in actual}) != 227:
        fail('cold_restored_projection_mismatch')
    sample_daemon_maps('projected')
    environment_after = phase_environment()
    if environment_after['ld_so_cache'] != environment_before['ld_so_cache'] or \
            environment_after['host_libraries'] != environment_before['host_libraries']:
        fail('host_runtime_environment_changed_during_cold_phase')
    guard()
    write_json('projection-review.v1.json', {'cold_empty_store_restored': True, 'images': 227,
        'literal_RepoTags_restored': tags, 'all_native_platform_content_unpacked': True,
        'projection_fields': ['Id', 'RootFS', 'Size', 'RepoTags', 'RepoDigests'],
        'host_library_environment_after': environment_after,
        'existing_store_preservation_pending_native_audit': True, 'local_image_deletion_cleared': False})
    print(json.dumps({'phase': 'cold_projection_matched', 'images': 227, 'tags': tags}), flush=True)


def guarded_main():
    if _DIAGNOSTIC_EFFECTS is not None:
        raise ValueError('fixture_live_main_crossover')
    def cancel(signum,frame):
        raise RuntimeError('owned_supervisor_cancelled_'+str(signum))
    for termination_signal in (signal.SIGTERM,signal.SIGHUP,signal.SIGINT):
        signal.signal(termination_signal,cancel)
    if ctypes.CDLL(None,use_errno=True).prctl(1,signal.SIGTERM,0,0,0)!=0:
        raise SystemExit('Parent-death cancellation could not be established')
    signal.signal(signal.SIGALRM,lambda signum,frame:alarm_guard())
    signal.setitimer(signal.ITIMER_REAL,5,5)
    def cleanup():
        signal.setitimer(signal.ITIMER_REAL,0)
        for termination_signal in (signal.SIGTERM,signal.SIGHUP,signal.SIGINT):
            signal.signal(termination_signal,signal.SIG_IGN)
        _cleanup_reporting_live_resources(_DIAGNOSTIC_FRAME)
    report=_reporting_operation(main,cleanup)
    raise SystemExit(0 if report['diagnostic_complete'] else 1)


# D7 reporting additions. Existing live main/pure gates are retained, never dispatched here.
_DIAGNOSTIC_EFFECTS = None
_OWNED_CHILDREN = []
_COMMAND_REPORTS = []
_DIAGNOSTIC_FRAME = None
_SYSTEM_TIME = time
_COHORT = Path(__file__).resolve().parent
_FIXTURE_CASES = frozenset({'primary_forced','primary_unknown','signal_send','command_receipt',
    'guest_receipt','timer_disable','timer_restore','mask_restore','stream_close',
    'cleanup','graceful','outer_zero_unknown','native_budget','operator_stop',
    'launcher_raw_write','recorder_raw_write','launcher_receipt','recorder_receipt','identity_clock'})
_HELPER_NAMES = ('cold_restore_docker_archive_v6.py','Run-RecordedColdOperation.v6.ps1',
                 'Run-ColdDockerRecovery.v6.ps1','Native-ColdGuardian.v6.ps1')
_CASE_LIMIT = 1024 * 1024
_COHORT_LIMIT = 16 * 1024 * 1024


def _extract_cause(error, operation, phase, category='secondary', child=None):
    known = {'fixture_initiating_failure','cold_operator_stop_latched','cold_unproved_child_closure',
             'fixture_result_write_failed','fixture_cleanup_failed','fixture_close_failed',
             'fixture_signal_mask_failed','fixture_timer_failed','fixture_budget_failed'}
    # Do not call arbitrary exception __str__: diagnostic capture cannot mask it.
    reason = error.args[0] if error.args and type(error.args[0]) is str else ''
    reason = reason if reason in known else 'external_operation_failed'
    types = []
    current = error
    seen = set()
    for _ in range(8):
        if current is None or id(current) in seen:
            break
        seen.add(id(current))
        types.append(type(current).__name__[:192])
        current = current.__cause__
    value = {'operation':operation,'phase':phase,'category':category,'reason_code':reason,
             'exception_types':types,'errno':getattr(error,'errno',None),
             'child':child,'synthetic_provider':_DIAGNOSTIC_EFFECTS is not None,
             'exception_contents_retained':False}
    if type(value['errno']) is not int:
        value['errno'] = None
    payload = json.dumps(value,sort_keys=True,allow_nan=False).encode('utf-8')
    if len(reason.encode('utf-8')) > 1024 or len(payload) > 16 * 1024:
        raise RuntimeError('fixture_budget_failed')
    return value


def _cause(error,operation,phase,category='secondary',child=None):
    try:
        return _extract_cause(error,operation,phase,category,child)
    except BaseException as capture_error:
        # An unavailable diagnostic is secondary; the original exception is still raised.
        return {'operation':operation,'phase':phase,'category':category,
                'reason_code':'diagnostic_capture_unavailable','exception_types':[type(error).__name__[:192]],
                'capture_failure_type':type(capture_error).__name__[:192],
                'capture_failure':True,'child':child,'synthetic_provider':_DIAGNOSTIC_EFFECTS is not None,
                'exception_contents_retained':False}


def _frame(operation):
    value = {'operation':operation,'primary':None,'secondary':[],'capture_unavailable':False,
            'original_returncode':None,'closure':'not_started','forced_kill':False,
            'result_attempted':False,'result_available':False,'result_failure':None,
            'signal_restoration':{},'stream_closure':{},'child':None}
    if _DIAGNOSTIC_EFFECTS is not None:
        fixture = _DIAGNOSTIC_EFFECTS.value
        value.update({'kind':'cold_diagnostics_fixture_report_v6','layer':'guest',
            'case':fixture['case'],'nonce':fixture['nonce'],'planning_commit':fixture['planning_commit'],
            'helper_sha256':fixture['helper_sha256']})
    return value


def _secondary(frame, error, phase, operation=None):
    value = _cause(error,operation or frame['operation'],phase,child=frame['child'])
    frame['secondary'].append(value)
    if value.get('capture_failure'):
        frame['capture_unavailable']=True
    if len(json.dumps(frame,sort_keys=True,allow_nan=False).encode('utf-8')) > _CASE_LIMIT // 2:
        frame['capture_unavailable'] = True
    return value


def _clock():
    return time.monotonic() if _DIAGNOSTIC_EFFECTS is None else _DIAGNOSTIC_EFFECTS.clock()


def _write_reporting_json(name, value):
    payload = (json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode('utf-8')
    if _DIAGNOSTIC_EFFECTS is None:
        with (CONTROL/name).open('xb') as output:
            output.write(payload)
    else:
        _DIAGNOSTIC_EFFECTS.write(name,payload)


def _attempt_result(frame, name):
    frame['result_attempted'] = True
    # The inner record cannot prove its own completed write; the enclosing frame can.
    frame['result_available'] = None
    try:
        _write_reporting_json(name,frame)
        frame['result_available'] = True
    except BaseException as error:
        frame['result_available'] = False
        frame['result_failure'] = _secondary(frame,error,'result_write')


def _observe_returncode(process, frame):
    try:
        code = process.returncode
        if code is not None and type(code) is not int:
            raise ValueError('invalid_returncode')
        frame['original_returncode'] = code
    except BaseException as error:
        _secondary(frame,error,'returncode_observation')
        frame['original_returncode'] = None


def _register_child(process, frame):
    # Retain ownership before observing a fallible identity/clock effect.
    frame['child'] = {'kind':'identity_unavailable','pid':None,'start_observed_monotonic':None}
    entry = {'process':process,'frame':frame,'termination_attempted':False,'metadata_error':None}
    _OWNED_CHILDREN.append(entry)
    try:
        observed = _clock() if _DIAGNOSTIC_EFFECTS is None else _DIAGNOSTIC_EFFECTS.identity_clock()
        identity = {'kind':'actual_process','pid':process.pid,'observer_pid':os.getpid(),
                    'start_observed_monotonic':observed}
        if getattr(process,'synthetic',False):
            identity = {'kind':'synthetic_process','id':process.fixture_id,'pid':None,
                        'start_observed_monotonic':observed}
        frame['child'] = identity
    except BaseException as error:
        entry['metadata_error'] = error
        _secondary(frame,error,'child_identity_observation')
    return entry


def _finish_reporting_process(process, frame):
    actions = {'sigterm_sent':False,'sigterm_attempted':False,'kill_attempted':False,
               'forced_kill':False,'waits':[],'original_returncode':None,'closure':'unknown'}
    try:
        alive = process.poll() is None
    except BaseException as error:
        _secondary(frame,error,'poll_before_termination')
        alive = True
    if alive:
        actions['sigterm_attempted'] = True
        try:
            process.send_signal(signal.SIGTERM)
            actions['sigterm_sent'] = True
        except BaseException as error:
            _secondary(frame,error,'sigterm_send')
        first_closed = False
        try:
            process.wait(timeout=30)
            actions['waits'].append({'signal':'SIGTERM','timeout_seconds':30,'outcome':'returned'})
            first_closed = True
        except BaseException as error:
            actions['waits'].append({'signal':'SIGTERM','timeout_seconds':30,'outcome':type(error).__name__})
            _secondary(frame,error,'sigterm_wait')
        if not first_closed:
            actions['kill_attempted'] = True
            actions['forced_kill'] = True
            try:
                process.kill()
            except BaseException as error:
                _secondary(frame,error,'sigkill_send')
            try:
                process.wait(timeout=30)
                actions['waits'].append({'signal':'SIGKILL','timeout_seconds':30,'outcome':'returned'})
            except BaseException as error:
                actions['waits'].append({'signal':'SIGKILL','timeout_seconds':30,'outcome':type(error).__name__})
                _secondary(frame,error,'sigkill_wait')
    _observe_returncode(process,frame)
    actions['original_returncode'] = frame['original_returncode']
    actions['closure'] = 'closed' if frame['original_returncode'] is not None else 'unknown'
    frame['closure'] = actions['closure']
    frame['forced_kill'] = actions['forced_kill']
    return actions


def _pause_reporting_signals(frame):
    state = {'mask_known':False,'timer_known':False,'mask':None,'timer':None}
    for phase,key in (('mask_block','mask'),('timer_disable','timer')):
        try:
            if _DIAGNOSTIC_EFFECTS is None:
                value = (signal.pthread_sigmask(signal.SIG_BLOCK,{signal.SIGTERM,signal.SIGHUP,signal.SIGINT,signal.SIGALRM})
                         if key == 'mask' else signal.setitimer(signal.ITIMER_REAL,0))
            else:
                value = _DIAGNOSTIC_EFFECTS.signal_state(phase)
            state[key] = value
            state[key+'_known'] = True
            frame['signal_restoration'][phase] = 'observed'
        except BaseException as error:
            _secondary(frame,error,phase)
            frame['signal_restoration'][phase] = 'failed'
    return state


def _resume_reporting_signals(state, frame):
    for phase,key in (('timer_restore','timer'),('mask_restore','mask')):
        if not state[key+'_known']:
            frame['signal_restoration'][phase] = 'unavailable'
            continue
        try:
            if _DIAGNOSTIC_EFFECTS is None:
                if key == 'timer':
                    signal.setitimer(signal.ITIMER_REAL,*state[key])
                else:
                    signal.pthread_sigmask(signal.SIG_SETMASK,state[key])
            else:
                _DIAGNOSTIC_EFFECTS.signal_state(phase)
            frame['signal_restoration'][phase] = 'returned'
        except BaseException as error:
            _secondary(frame,error,phase)
            frame['signal_restoration'][phase] = 'failed'


def _close_reporting_stream(stream, channel, frame):
    if stream is None:
        frame['stream_closure'][channel] = 'not_opened'
        return
    try:
        if _DIAGNOSTIC_EFFECTS is None:
            stream.close()
        else:
            _DIAGNOSTIC_EFFECTS.close(stream,channel)
        frame['stream_closure'][channel] = 'returned'
    except BaseException as error:
        _secondary(frame,error,channel+'_close')
        frame['stream_closure'][channel] = 'failed'


def _reporting_run(args,label,timeout=1800,check=True,guarded=True,stdin=subprocess.DEVNULL):
    global SEQUENCE
    SEQUENCE += 1
    prefix = f'{SEQUENCE:04d}-{label}'
    frame = _frame(label)
    frame['timeout_seconds'] = timeout
    frame['requires_successful_exit'] = check
    frame['argv'] = args
    process = output = error_stream = entry = None
    caught = None
    try:
        output = (CONTROL/(prefix+'.stdout')).open('xb')
        error_stream = (CONTROL/(prefix+'.stderr')).open('xb')
        if _DIAGNOSTIC_EFFECTS is None:
            if args[0] in {str(RUNTIME_ROOT/relative) for relative in RUNTIME_BINARIES.values()}:
                runtime_binary(Path(args[0]).name)
            elif args[0] not in {'/usr/bin/truncate','/usr/sbin/mkfs.ext4','/usr/sbin/losetup','/usr/bin/mount','/usr/bin/findmnt','/usr/bin/umount'}:
                fail('cold_unreviewed_command')
            process = subprocess.Popen(args,stdin=stdin,stdout=output,stderr=error_stream,env=ENV)
        else:
            process = _DIAGNOSTIC_EFFECTS.start(args,output,error_stream)
        entry = _register_child(process,frame)
        if entry['metadata_error'] is not None:
            raise entry['metadata_error']
        started = _clock()
        while process.poll() is None:
            if guarded:
                guard()
            if _clock()-started > timeout:
                fail('owned_cold_command_timeout')
            time.sleep(0.25) if _DIAGNOSTIC_EFFECTS is None else _DIAGNOSTIC_EFFECTS.sleep()
    except BaseException as failure:
        caught = failure
        frame['primary'] = _cause(failure,label,'command_execution','primary',frame['child'])
        frame['capture_unavailable']=bool(frame['primary'].get('capture_failure'))
    finally:
        state = _pause_reporting_signals(frame)
        if process is not None:
            # Cleanup cannot depend on successful identity observation/registration.
            if entry is None:
                entry = {'process':process,'frame':frame,'termination_attempted':False,'metadata_error':None}
                _OWNED_CHILDREN.append(entry)
            entry['termination_attempted'] = True
            frame['termination'] = _finish_reporting_process(process,frame)
        _resume_reporting_signals(state,frame)
        _close_reporting_stream(output,'stdout',frame)
        _close_reporting_stream(error_stream,'stderr',frame)
        _attempt_result(frame,prefix+'.result.json')
        _COMMAND_REPORTS.append(frame)
    if caught is not None:
        raise caught
    if frame['secondary'] or frame['forced_kill'] or frame['closure'] != 'closed' or not frame['result_available']:
        raise RuntimeError('cold_unproved_child_closure')
    if check and frame['original_returncode'] != 0:
        fail('cold_command_failed_'+label)
    return (CONTROL/(prefix+'.stdout')).read_text(errors='strict')


def _reporting_operation(operation, cleanup):
    global _DIAGNOSTIC_FRAME
    frame = _frame('guest')
    _DIAGNOSTIC_FRAME = frame
    success = False
    try:
        operation()
        success = True
    except BaseException as error:
        frame['primary'] = _cause(error,'guest','operation','primary')
        frame['capture_unavailable']=bool(frame['primary'].get('capture_failure'))
    finally:
        # Preserve stock daemon teardown order (dockerd before containerd).
        for entry in reversed(_OWNED_CHILDREN):
            if not entry['termination_attempted']:
                entry['termination_attempted'] = True
                entry['frame']['termination'] = _finish_reporting_process(entry['process'],entry['frame'])
                for stream,channel in entry.get('streams',()):
                    _close_reporting_stream(stream,channel,entry['frame'])
                _attempt_result(entry['frame'],entry['frame']['operation']+'.closed.json')
        try:
            cleanup()
        except BaseException as error:
            _secondary(frame,error,'cleanup')
        frame['children'] = [entry['frame'] for entry in _OWNED_CHILDREN]
        frame['command_reports'] = list(_COMMAND_REPORTS)
        frame['all_children_proved_closed'] = all(x['frame']['closure']=='closed' and not x['frame']['forced_kill'] and (not x['frame'].get('requires_successful_exit',True) or x['frame']['original_returncode']==0) for x in _OWNED_CHILDREN)
        frame['diagnostic_complete'] = bool(success and not frame['secondary'] and not frame['capture_unavailable'] and frame['all_children_proved_closed'] and all(not x['frame']['secondary'] and not x['frame']['capture_unavailable'] and x['frame']['result_available'] for x in _OWNED_CHILDREN))
        frame['fixture'] = _DIAGNOSTIC_EFFECTS is not None
        frame['recovery_acceptance'] = False if frame['fixture'] else frame['diagnostic_complete']
        _attempt_result(frame,'guest.result.v6.json')
        if not frame['result_available']:
            frame['diagnostic_complete'] = False
        # Exact bounded emergency data remains available to an enclosing capture.
        payload = json.dumps(frame,sort_keys=True,allow_nan=False)
        if len(payload.encode()) > _CASE_LIMIT//2:
            raise RuntimeError('fixture_budget_failed')
        print(payload,flush=True)
    return frame


def _validate_fixture(path,child=False):
    path = Path(path)
    if not path.is_absolute():
        raise ValueError('fixture_path_not_absolute')
    path = path.resolve(strict=True)
    if path.parent.parent != _COHORT or path.name != 'fixture.json':
        raise ValueError('fixture_root_foreign')
    for item in (path,path.parent):
        info = item.lstat()
        if item.is_symlink() or getattr(info,'st_file_attributes',0)&1024:
            raise ValueError('fixture_path_redirected')
    if path.stat().st_nlink != 1 or path.stat().st_size > 16*1024:
        raise ValueError('fixture_manifest_unsafe')
    raw = path.read_bytes()
    seal = path.with_suffix('.sha256').read_text(encoding='ascii')
    if seal != hashlib.sha256(raw).hexdigest():
        raise ValueError('fixture_seal_mismatch')
    value = json.loads(raw,object_pairs_hook=unique_json_fields)
    required = {'kind','fixture','recovery_acceptance','case','nonce','case_root','helper_sha256','planning_commit','case_limit','cohort_limit'}
    if type(value) is not dict or set(value)!=required or value['kind']!='cold_diagnostics_fixture_v6' or value['fixture'] is not True or value['recovery_acceptance'] is not False:
        raise ValueError('fixture_kind_or_scope')
    if value['case'] not in _FIXTURE_CASES or not re.fullmatch(r'[a-f0-9]{32}',value['nonce']) or Path(value['case_root']) != path.parent:
        raise ValueError('fixture_case_or_nonce')
    if path.parent.name!='case-'+value['case']+'-'+value['nonce']:
        raise ValueError('fixture_namespace_foreign')
    for name in ('guest.result.v6.json','0001-fixture-command.stdout','0001-fixture-command.stderr','0001-fixture-command.result.json'):
        if child and name.endswith(('.stdout','.stderr')):
            continue
        if (path.parent/name).exists():
            raise ValueError('fixture_no_replay')
    if value['planning_commit']!='4666e9e21741eda1f2f5b72d5a2de4bba6a7cd1a' or value['case_limit']!=_CASE_LIMIT or value['cohort_limit']!=_COHORT_LIMIT:
        raise ValueError('fixture_planning_or_caps')
    if set(value['helper_sha256']) != set(_HELPER_NAMES):
        raise ValueError('fixture_helper_membership')
    for name in _HELPER_NAMES:
        helper = _COHORT/name
        info = helper.lstat()
        if helper.is_symlink() or info.st_nlink != 1 or hashlib.sha256(helper.read_bytes()).hexdigest()!=value['helper_sha256'][name]:
            raise ValueError('fixture_helper_drift')
    return value


class _SyntheticProcess:
    synthetic = True
    def __init__(self,case,nonce):
        self.case,self.fixture_id,self.returncode,self.wait_calls = case,nonce,None,[]
        self.first_poll = True
    def poll(self):
        if self.first_poll:
            self.first_poll = False
            if self.case not in {'native_budget','operator_stop'}:
                raise RuntimeError('fixture_initiating_failure')
        return self.returncode
    def send_signal(self,number):
        if self.case=='signal_send':
            raise OSError(5,'synthetic signal failure')
    def kill(self):
        return None
    def wait(self,timeout):
        self.wait_calls.append(timeout)
        if self.case in {'primary_unknown','outer_zero_unknown'} or (self.case=='primary_forced' and len(self.wait_calls)==1):
            raise subprocess.TimeoutExpired('synthetic-process',timeout)
        self.returncode = -9 if len(self.wait_calls)>1 else -15
        return self.returncode


class _FixtureEffects:
    def __init__(self,value,path):
        self.value,self.path,self.case = value,path,value['case']
        self.now = 0.0
        self.heartbeat_sequence = 0
    def clock(self):
        self.now += 0.01
        return self.now
    def identity_clock(self):
        if self.case=='identity_clock':
            raise RuntimeError('fixture_identity_clock_failed')
        return self.clock()
    def start(self,args,output,error):
        if args != ['fixture-command']:
            raise ValueError('fixture_command_crossover')
        if self.case in {'graceful','launcher_raw_write','recorder_raw_write','launcher_receipt','recorder_receipt'}:
            return subprocess.Popen([sys.executable,'-I','-B',str(Path(__file__).resolve()),'--fixture-child',str(self.path)],
                stdin=subprocess.DEVNULL,stdout=output,stderr=error)
        return _SyntheticProcess(self.case,self.value['nonce'])
    def free_bytes(self,path):
        return 12*1024**3+1 if path==ROOT else 5*1024**3+1
    def heartbeat(self):
        self.heartbeat_sequence += 1
        return {'kind':'native_cold_heartbeat_v1','session':SESSION,'seq':self.heartbeat_sequence,
                'c_free':40*1024**3+1,'e_free':12*1024**3+1,'utc':'fixture'}
    def sleep(self):
        _SYSTEM_TIME.sleep(0.005)
    def signal_state(self,phase):
        if (self.case=='timer_disable' and phase=='timer_disable') or (self.case=='timer_restore' and phase=='timer_restore') or (self.case=='mask_restore' and phase=='mask_restore'):
            raise RuntimeError('fixture_timer_failed' if phase.startswith('timer') else 'fixture_signal_mask_failed')
        return [] if phase.startswith('mask') else (0.0,0.0)
    def write(self,name,payload):
        if (self.case=='command_receipt' and name.endswith('.result.json')) or (self.case=='guest_receipt' and name=='guest.result.v6.json'):
            raise OSError(5,'synthetic receipt failure')
        # Reserve an emergency report and validate actual membership/bytes before each create.
        case_bytes = sum(x.stat().st_size for x in CONTROL.iterdir() if x.is_file())
        cohort_bytes = sum(x.stat().st_size for x in _COHORT.rglob('*') if x.is_file())
        if case_bytes+len(payload) > _CASE_LIMIT-16384 or cohort_bytes+len(payload) > _COHORT_LIMIT-16384:
            raise RuntimeError('fixture_budget_failed')
        with (CONTROL/name).open('xb') as target:
            target.write(payload)
    def close(self,stream,channel):
        stream.close()
        if self.case=='stream_close':
            raise OSError(5,'synthetic stream close failure')
    def cleanup(self):
        if self.case=='cleanup':
            raise RuntimeError('fixture_cleanup_failed')


def _fixture_entry(path,child=False):
    global CONTROL,LAUNCH,ROOT,_DIAGNOSTIC_EFFECTS,SEQUENCE,LEASE,time,shutil,DEADLINE,SESSION
    value = _validate_fixture(path,child)
    if child:
        if value['case'] not in {'graceful','launcher_raw_write','recorder_raw_write','launcher_receipt','recorder_receipt'}:
            raise ValueError('fixture_child_scope')
        print('tiny-owned-fixture-child',flush=True)
        return 0
    ROOT = CONTROL = LAUNCH = Path(value['case_root'])
    _DIAGNOSTIC_EFFECTS = _FixtureEffects(value,Path(path))
    # Bind only external clock/floor/read effects; stock guard/lease decisions execute.
    class ClockEffects:
        monotonic = staticmethod(_DIAGNOSTIC_EFFECTS.clock)
        sleep = staticmethod(lambda seconds:_DIAGNOSTIC_EFFECTS.sleep())
    class FloorEffects:
        @staticmethod
        def disk_usage(path):
            from types import SimpleNamespace
            return SimpleNamespace(free=_DIAGNOSTIC_EFFECTS.free_bytes(path))
    time,shutil = ClockEffects,FloorEffects
    DEADLINE = time.monotonic()+GUEST_SECONDS
    SESSION = 'fixture-'+value['nonce']
    lease_path = Path('E:/STUDY/VAST/tmp/host-cache-cleanup-20261012/native_heartbeat_lease_v1.py')
    lease_raw = lease_path.read_bytes()
    if hashlib.sha256(lease_raw).hexdigest()!='8aae687de0b919f90c8a12f34bc7798920bc0c41250049aef3595225a4bd7fb4':
        raise ValueError('fixture_unchanged_lease_drift')
    spec = importlib.util.spec_from_file_location('fixture_unchanged_lease',lease_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    LEASE = module.HeartbeatLease(SESSION,_DIAGNOSTIC_EFFECTS.heartbeat,clock=_DIAGNOSTIC_EFFECTS.clock,timeout=30)
    SEQUENCE = 0
    report = _reporting_operation(lambda:run(['fixture-command'],'fixture-command',timeout=300),_DIAGNOSTIC_EFFECTS.cleanup)
    report['case'] = value['case']
    report['nonce'] = value['nonce']
    if value['case']=='outer_zero_unknown':
        return 0  # Deliberately preserve outer0; parent must still reject unproved inner closure.
    return 0 if report['diagnostic_complete'] else 1


def _cleanup_reporting_live_resources(frame):
    global LOOP,MOUNTED
    if CREATED and DISK.exists():
        try:
            owned = run(['/usr/sbin/losetup','--noheadings','--raw','--output','NAME','--associated',str(DISK)],'reconcile-owned-loop',guarded=False).splitlines()
            if len(owned)>1:
                fail('multiple_owned_loop_devices')
            LOOP = owned[0].strip() if owned else None
            if LOOP in {'/dev/loop0','/dev/loop1'}:
                fail('protected_loop_device')
            mounted = run(['/usr/bin/findmnt','--mountpoint',str(MOUNT),'--noheadings','--raw','--output','SOURCE,FSTYPE'],'reconcile-owned-mount',guarded=False,check=False).strip()
            if mounted:
                if mounted.split()!=[LOOP,'ext4'] or not MOUNT_CREATED:
                    fail('mount_owner_mismatch')
                MOUNTED=True
            else:
                MOUNTED=False
        except Exception as caught:
            _secondary(frame,caught,'resource-reconciliation')
            LOOP=None
            MOUNTED=False
    if MOUNTED:
        try:
            run(['/usr/bin/umount',str(MOUNT)],'unmount-owned-disk',check=True,guarded=False)
            MOUNTED=False
        except Exception as caught:
            _secondary(frame,caught,'unmount')
    if LOOP is not None and not MOUNTED:
        try:
            if LOOP in {'/dev/loop0','/dev/loop1'}:
                fail('protected_cleanup_loop_device')
            backing=run(['/usr/sbin/losetup','--noheadings','--raw','--output','BACK-FILE',LOOP],'cleanup-loop-backing',guarded=False).strip()
            if Path(backing).resolve()!=DISK.resolve():
                fail('cleanup_loop_owner_mismatch')
            run(['/usr/sbin/losetup','--detach',LOOP],'detach-owned-loop',guarded=False)
        except Exception as caught:
            _secondary(frame,caught,'detach')
    if MOUNT_CREATED and MOUNT.exists() and not MOUNTED:
        try:
            MOUNT.rmdir()
        except Exception as caught:
            _secondary(frame,caught,'mount-directory')


if __name__ == '__main__':
    try:
        if len(sys.argv)==3 and sys.argv[1] in {'--diagnostics-fixture','--fixture-child'}:
            raise SystemExit(_fixture_entry(sys.argv[2],sys.argv[1]=='--fixture-child'))
        raise SystemExit('D7 fixture-only entrypoint; no live/admission/default dispatch')
    except Exception as failure:
        print(json.dumps({'fixture':True,'recovery_acceptance':False,'entrypoint_failure_type':type(failure).__name__}),flush=True)
        raise SystemExit(1)
