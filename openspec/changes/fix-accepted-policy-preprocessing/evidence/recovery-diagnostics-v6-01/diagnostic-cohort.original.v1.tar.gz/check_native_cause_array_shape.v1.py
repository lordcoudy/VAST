"""Read-only regression for the native fixture JSON boundary; no recovery authority."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

parser = argparse.ArgumentParser()
parser.add_argument("--input-root", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
suite_bytes = (args.input_root / "suite.original.v1.json").read_bytes()
suite = json.loads(suite_bytes)
rows = []
for row in suite["cases"]:
    case_id = row["case_id"]
    if not isinstance(case_id, str) or any(ch not in "abcdefghijklmnopqrstuvwxyz0123456789-" for ch in case_id):
        raise ValueError("foreign fixture case identity")
    raw = (args.input_root / case_id / "result.original.v1.json").read_bytes()
    if len(raw) > 1024**2:
        raise ValueError("case input exceeds 1MiB")
    value = json.loads(raw)
    rows.append({"case_id": case_id, "sha256": hashlib.sha256(raw).hexdigest(),
                 "cause_array": isinstance(value["diagnostic_causes"], list),
                 "fixture": value["fixture"], "recovery_acceptance": value["recovery_acceptance"]})
success = all(row["cause_array"] and row["fixture"] and row["recovery_acceptance"] is False for row in rows)
payload = json.dumps({"kind": "native_cause_array_shape_regression.v1", "fixture": True,
    "recovery_acceptance": False, "checker_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "suite_sha256": hashlib.sha256(suite_bytes).hexdigest(), "source_sha256": suite["source_sha256"],
    "harness_sha256": suite["harness_sha256"], "successful": success, "cases": rows}, indent=2).encode()
if len(payload) > 1024**2:
    raise ValueError("shape report exceeds 1MiB")
with args.output.open("xb") as stream:
    stream.write(payload)
print(json.dumps({"successful": success, "cases": len(rows), "array_cases": sum(row["cause_array"] for row in rows),
                  "fixture": True, "recovery_acceptance": False}))
sys.exit(0 if success else 1)
