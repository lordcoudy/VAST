"""Author: audit_capacity. Original-v5 RED fixture only; recovery_acceptance=False.

The pinned original function bodies execute unchanged. Their external process,
clock, signal and I/O providers are inert controlled fixtures. The original module
is never imported, its globals/main are never executed, and no real child/command,
signal, timer, storage or network action is available to those bodies.
"""
import ast
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import signal
import subprocess
import sys
from types import SimpleNamespace
import unittest

SOURCE = Path("E:/VAST-cold03-a3990e2870c940149785831b845aea91/helpers-cold03/cold_restore_docker_archive_v5.py")
SOURCE_SHA256 = "6a63c732ae26f3dc24187779a1434021a932e00725fdc31edab05d051dd9993f"
COHORT = Path(__file__).resolve().parent
CONTROL = COHORT / "guest-v5-terminal-cause-red-01"
CASE_LIMIT = 1024 * 1024
COHORT_LIMIT = 16 * CASE_LIMIT
FUNCTIONS = ("finish_process", "pause_finalization_signals", "resume_finalization_signals", "run")
FIXTURE_ARGV = ["/usr/sbin/mkfs.ext4", "--synthetic-fixture-only"]
OBSERVATIONS = []


class FixtureInitiatingFailure(RuntimeError):
    """Synthetic external clock failure; no historical initiating cause is inferred."""


class FixtureBoundaryFailure(RuntimeError):
    pass


class ControlledClock:
    def __init__(self):
        self.calls = 0
        self.seconds = 0.0
        self.primary = FixtureInitiatingFailure("synthetic initiating clock sample failure")

    def monotonic(self):
        self.calls += 1
        if self.calls == 2:
            raise self.primary
        return self.seconds

    def sleep(self, seconds):
        self.seconds += seconds


class ControlledProcess:
    def __init__(self, clock):
        self.pid = 424242  # synthetic identifier, never an operating-system PID
        self.returncode = None
        self.clock = clock
        self.calls = []

    def poll(self):
        self.calls.append({"operation": "poll", "result": None})
        return None

    def send_signal(self, value):
        self.calls.append({"operation": "send_signal", "value": int(value)})

    def kill(self):
        self.calls.append({"operation": "kill", "synthetic": True})

    def wait(self, timeout):
        number = sum(v["operation"] == "wait" for v in self.calls) + 1
        phase = "synthetic_sigterm_wait" if number == 1 else "synthetic_sigkill_wait"
        self.calls.append({"operation": "wait", "phase": phase, "timeout": timeout})
        self.clock.seconds += timeout
        raise subprocess.TimeoutExpired(phase, timeout)


class ControlledSignals:
    SIGTERM, SIGHUP, SIGINT, SIGALRM = 15, 1, 2, 14
    SIG_BLOCK, SIG_SETMASK, ITIMER_REAL = 0, 2, 0

    def __init__(self):
        self.events = []
        self.mask = set()
        self.timer = (0.0, 0.0)

    def pthread_sigmask(self, operation, value):
        old = set(self.mask)
        self.events.append({"operation": "pthread_sigmask", "how": operation,
                            "values": sorted(value), "synthetic": True})
        self.mask = set(value) if operation == self.SIG_SETMASK else self.mask | set(value)
        return old

    def setitimer(self, timer, seconds, interval=0):
        old = self.timer
        self.events.append({"operation": "setitimer", "timer": timer,
                            "seconds": seconds, "interval": interval, "synthetic": True})
        self.timer = (seconds, interval)
        return old


class ControlledStream(io.BytesIO):
    def __init__(self, store, name):
        super().__init__()
        self.store, self.name = store, name

    def close(self):
        if not self.closed:
            self.store["closed_streams"].append(self.name)
            self.store["files"][self.name] = self.getvalue()
        super().close()


class ControlledPath:
    def __init__(self, store, name=""):
        self.store, self.name = store, name

    def __truediv__(self, name):
        return ControlledPath(self.store, self.name + str(name))

    def open(self, mode):
        if mode != "xb" or self.name in self.store["files"]:
            raise FixtureBoundaryFailure("fixture permits fresh in-memory binary streams only")
        self.store["files"][self.name] = b""
        return ControlledStream(self.store, self.name)

    def read_text(self, errors="strict"):
        return self.store["files"][self.name].decode(errors=errors)


def forbidden_external_action(*args, **kwargs):
    raise FixtureBoundaryFailure("unavailable production action in fixture-only globals")


def isolated_original_functions(clock, process, signals, store):
    source = SOURCE.read_bytes()
    if hashlib.sha256(source).hexdigest() != SOURCE_SHA256:
        raise FixtureBoundaryFailure("original v5 source hash changed")
    module = ast.parse(source.decode("utf-8"), filename=str(SOURCE))
    selected = [node for node in module.body
                if isinstance(node, ast.FunctionDef) and node.name in FUNCTIONS]
    if tuple(node.name for node in selected) != FUNCTIONS:
        raise FixtureBoundaryFailure("unexpected original function selection")
    function_hashes = {
        node.name: hashlib.sha256(ast.get_source_segment(source.decode("utf-8"), node).encode()).hexdigest()
        for node in selected
    }

    def controlled_popen(argv, **kwargs):
        if argv != FIXTURE_ARGV or kwargs.get("env") != {"SYNTHETIC_FIXTURE": "true"}:
            raise FixtureBoundaryFailure("command or provider crossover refused")
        store["popen_calls"] += 1
        return process

    def controlled_write_json(name, value):
        store["receipt_attempts"].append({"name": name, "value": value})

    external = SimpleNamespace(DEVNULL=subprocess.DEVNULL,
                               TimeoutExpired=subprocess.TimeoutExpired,
                               Popen=controlled_popen)
    globals_ = {
        "__builtins__": {"str": str, "set": set, "type": type, "BaseException": BaseException},
        "subprocess": external, "signal": signals, "time": clock,
        "CONTROL": ControlledPath(store), "RUNTIME_ROOT": PurePosixPath("/__synthetic_runtime__"),
        "RUNTIME_BINARIES": {}, "ENV": {"SYNTHETIC_FIXTURE": "true"},
        "SEQUENCE": 0, "Path": PurePosixPath, "runtime_binary": forbidden_external_action,
        "guard": forbidden_external_action, "fail": forbidden_external_action,
        "write_json": controlled_write_json,
    }
    exec(compile(ast.Module(body=selected, type_ignores=[]),
                 "pinned-original-v5-reporting-functions:" + SOURCE_SHA256, "exec"), globals_)
    return globals_, function_hashes


def observe_original_double_timeout(test_name):
    clock = ControlledClock()
    process = ControlledProcess(clock)
    signals = ControlledSignals()
    store = {"files": {}, "closed_streams": [], "receipt_attempts": [], "popen_calls": 0}
    original, function_hashes = isolated_original_functions(clock, process, signals, store)
    observed = None
    try:
        original["run"](list(FIXTURE_ARGV), "synthetic-double-timeout", timeout=300, guarded=False)
    except BaseException as failure:
        observed = failure
    waits = [v["timeout"] for v in process.calls if v["operation"] == "wait"]
    if waits != [30, 30] or store["popen_calls"] != 1:
        raise FixtureBoundaryFailure("fixture did not reach both unchanged original waits")
    if not isinstance(observed, subprocess.TimeoutExpired) or observed.cmd != "synthetic_sigkill_wait":
        raise FixtureBoundaryFailure("original second-wait defect was not reached")
    if len(store["closed_streams"]) != 2 or signals.mask or signals.timer != (0.0, 0.0):
        raise FixtureBoundaryFailure("controlled streams/signals did not finalize as expected")
    observation = {
        "test": test_name, "author": "audit_capacity", "fixture_label": "synthetic-original-v5-double-timeout",
        "source_path": str(SOURCE), "source_sha256": SOURCE_SHA256,
        "actual_function_source_hashes": function_hashes, "original_module_imported": False,
        "original_top_level_or_main_executed": False, "real_processes_commands_signals_or_storage": False,
        "recovery_acceptance": False, "clock_label": "synthetic", "synthetic_seconds": clock.seconds,
        "initiating_exception_type": type(clock.primary).__name__, "initiating_exception_reason": str(clock.primary),
        "observed_exception_type": type(observed).__name__, "observed_timeout_phase": observed.cmd,
        "observed_timeout_seconds": observed.timeout, "initiating_exception_survived": observed is clock.primary,
        "synthetic_child_identity": {"pid": process.pid, "pid_is_synthetic": True, "original_returncode": None},
        "process_calls": process.calls, "wait_timeout_arguments": waits,
        "result_write_attempt_count": len(store["receipt_attempts"]),
        "closed_in_memory_streams": store["closed_streams"], "signal_provider_events": signals.events,
        "receipt_availability": "unavailable; original write_json was never reached",
    }
    OBSERVATIONS.append(observation)
    return observed, clock.primary, store


class OriginalV5ReportingRedRegression(unittest.TestCase):
    def test_original_initiating_cause_survives_both_wait_timeouts(self):
        observed, initiating, _ = observe_original_double_timeout(self.id())
        self.assertIs(observed, initiating,
                      "RED: original initiating exception was replaced by second SIGKILL wait TimeoutExpired")

    def test_command_result_is_attempted_after_both_wait_timeouts(self):
        _, _, store = observe_original_double_timeout(self.id())
        self.assertEqual(len(store["receipt_attempts"]), 1,
                         "RED: second wait timeout escaped before the original command-result write")


def directory_bytes(root):
    total = 0
    for path in root.rglob("*"):
        if path.is_symlink():
            raise FixtureBoundaryFailure("redirected diagnostic subtree")
        if path.is_file():
            total += path.stat().st_size
    return total


def main():
    if sys.argv[1:] != ["--fixture-only"]:
        print("Refused: this entrypoint accepts only --fixture-only; no production route exists.", file=sys.stderr)
        return 2
    if CONTROL.exists():
        raise FixtureBoundaryFailure("fresh RED evidence namespace occupied")
    if directory_bytes(COHORT) > COHORT_LIMIT - CASE_LIMIT:
        raise FixtureBoundaryFailure("diagnostic cohort reserve exhausted")
    CONTROL.mkdir(mode=0o700)
    raw = io.StringIO()
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(OriginalV5ReportingRedRegression)
    result = unittest.TextTestRunner(stream=raw, verbosity=2).run(suite)
    logs = raw.getvalue().encode("utf-8")
    summary = {
        "kind": "original-v5-double-timeout-red-regression.v1", "author": "audit_capacity",
        "source_sha256": SOURCE_SHA256, "fixture_label": "synthetic-only", "recovery_acceptance": False,
        "tests_run": result.testsRun, "failures": len(result.failures), "errors": len(result.errors),
        "expected_red": result.testsRun == 2 and len(result.failures) == 2 and not result.errors,
        "production_main_or_commands_reachable": False, "case_limit_bytes": CASE_LIMIT,
        "cohort_limit_bytes": COHORT_LIMIT, "observations": OBSERVATIONS,
    }
    report = json.dumps(summary, indent=2).encode("utf-8") + b"\n"
    if len(logs) + len(report) > CASE_LIMIT:
        raise FixtureBoundaryFailure("RED case output cap exhausted")
    (CONTROL / "unittest.original.stderr").write_bytes(logs)
    (CONTROL / "result.original.v1.json").write_bytes(report)
    sys.stderr.write(logs.decode("utf-8"))
    print(json.dumps({k: summary[k] for k in ("kind", "tests_run", "failures", "errors",
                                            "expected_red", "recovery_acceptance")}))
    if directory_bytes(CONTROL) > CASE_LIMIT or directory_bytes(COHORT) > COHORT_LIMIT:
        raise FixtureBoundaryFailure("diagnostic evidence limits exceeded")
    if hashlib.sha256(SOURCE.read_bytes()).hexdigest() != SOURCE_SHA256:
        raise FixtureBoundaryFailure("original v5 source changed during fixture")
    return 1 if not result.wasSuccessful() else 0


if __name__ == "__main__":
    raise SystemExit(main())

