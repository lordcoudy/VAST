# D7 fixture-only derivative of recorder v3 (de2d4bf4...). Original return codes stay independent.
param([string]$DiagnosticFixture)
$ErrorActionPreference='Stop'
$utf8=[Text.UTF8Encoding]::new($false)
# D7 preserved host predicates: BEGIN
function Invoke-ColdPreservedRecorderPredicates {
# Recorder for the post-provision cold03 operations (amendments 8a1e58e6/8d2b9d4d): the exact cold02 scratch
# retirement and the ONE cold03 test. Each operation runs once from hash-pinned copies placed in its own new
# protected helper directory inside the root; its original return code and any recorder failure are preserved.
param([Parameter(Mandatory=$true)][ValidateSet('Retire','Cold')][string]$Operation)
    throw 'D7 grants fixture diagnostics only; preserved host route is unconditionally withheld'
# D7 exact original body: BEGIN
$ErrorActionPreference = 'Stop'
$base = 'E:\STUDY\VAST\tmp\host-cache-cleanup-20261012'
$module = [ordered]@{'ColdRootSecurity.v2.ps1'='69ca07ee87fa93f55f510f46335856acd8b52f58700e8dfdf5f0f0c17cf204a6'}
$operations = @{
    Retire=[ordered]@{helpers='helpers-retire03';control='recorded-retire03';recipe='Retire-OwnedColdScratch.v4.ps1';files=[ordered]@{
        'Retire-OwnedColdScratch.v4.ps1'='ae460d9b5b6e741ca73005ab8dac795bfc277a8b4fc2f8b62822fde5373744ed'}}
    Cold=[ordered]@{helpers='helpers-cold03';control='recorded-cold03';recipe='Run-ColdDockerRecovery.v5.ps1';files=[ordered]@{
        'Run-ColdDockerRecovery.v5.ps1'='54535e950c0782129172e1822058b2d4a64ff1cb7d55dab36510c1fc6b20cec0'
        'Native-ColdGuardian.v1.ps1'='e2cbb87a20667aac6039993c70395c600dc861992b85f91260daee9f30a2314a'
        'native_heartbeat_lease_v1.py'='8aae687de0b919f90c8a12f34bc7798920bc0c41250049aef3595225a4bd7fb4'
        'cold_restore_docker_archive_v5.py'='6a63c732ae26f3dc24187779a1434021a932e00725fdc31edab05d051dd9993f'
        'run_isolated_cold_restore_v5.sh'='7dcfe31bb79f01aec5276ca9d471de338597fd1b4d8225893a24b7927b6559b0'
        'Capture-DockerCleanupAudit.v3.ps1'='f46125edb0771fc30b5cdabc82a440b641e01e9fd0bb16185bdbeb5ff3d55018'}}
}
$selected = $operations[$Operation]
$pins = [ordered]@{}
foreach ($entry in $module.GetEnumerator()) { $pins[$entry.Key] = $entry.Value }
foreach ($entry in $selected.files.GetEnumerator()) { $pins[$entry.Key] = $entry.Value }
$utf8 = [Text.UTF8Encoding]::new($false)
$moduleSource = Join-Path $base 'ColdRootSecurity.v2.ps1'
$moduleStream = [IO.FileStream]::new($moduleSource, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
if ([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($moduleStream)).ToLowerInvariant() -cne $pins['ColdRootSecurity.v2.ps1']) { throw 'Security module source drift' }
. $moduleSource
if ([Security.Principal.WindowsIdentity]::GetCurrent().User.Value -cne $ColdOwnerSid) { throw 'Recorder identity is not the pinned Windows owner' }
$guards = [Collections.Generic.List[object]]::new()
$rootGuard = Open-ColdGuard $ColdRootPath $true
$guards.Add($rootGuard)
if (@(Test-ColdObjectSddl $rootGuard.record.sddl $true $true).Count) { throw 'Root descriptor not restrictive' }
$helpers = Join-Path $ColdRootPath $selected.helpers
$control = Join-Path $ColdRootPath $selected.control
if ([IO.Directory]::Exists($helpers) -or [IO.Directory]::Exists($control)) { throw 'Operation already recorded; no replay' }
for ($directory = [IO.DirectoryInfo]::new($base); $null -ne $directory.Parent; $directory = $directory.Parent) { $guards.Add((Open-ColdGuard $directory.FullName $true)) }
foreach ($name in $pins.Keys) {
    $probe = Open-ColdGuard (Join-Path $base $name) $false
    try { if ([VastCold.Native]::Sha256($probe.handle) -cne $pins[$name]) { throw "Helper source drift: $name" } } finally { $probe.handle.Dispose() }
}
$actors = @(Get-ColdConcurrentActors (Get-ColdAncestorProcessIds))
if ($actors.Count) { throw 'Concurrent mutating actor present' }
if ($Operation -ceq 'Cold') {
    # Pre-creation mirror of the cold guest's admission (apt quiet window for 3 h 10 min plus margin, distro actors)
    # and of the Desktop preservation precondition, so a predictable refusal cannot consume the single cold03 test.
    function Invoke-WslProbe([string[]]$Arguments) {
        $output = & 'C:\Windows\System32\wsl.exe' --distribution Ubuntu --user s-a-balashov --exec @Arguments
        [pscustomobject]@{rc=$LASTEXITCODE;lines=@($output | ForEach-Object { $_.TrimEnd("`r") } | Where-Object { $_.Length })}
    }
    $active = Invoke-WslProbe @('/usr/bin/systemctl','is-active','apt-daily.service','apt-daily-upgrade.service')
    if ($active.rc -notin @(0,3) -or $active.lines.Count -ne 2 -or @($active.lines | Where-Object { $_ -cnotin @('inactive','failed') }).Count) { throw 'Pre-probe: apt service active or unknown' }
    $timers = Invoke-WslProbe @('/usr/bin/systemctl','list-timers','--all','--output=json','apt-daily.timer','apt-daily-upgrade.timer')
    if ($timers.rc -ne 0) { throw 'Pre-probe: timer query failed' }
    $timerRows = @(($timers.lines -join '') | ConvertFrom-Json)
    $nowUs = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() * 1000L
    foreach ($unit in @('apt-daily.timer','apt-daily-upgrade.timer')) {
        $row = @($timerRows | Where-Object { $_.unit -ceq $unit })
        if ($row.Count -ne 1 -or [long]$row[0].next -le 0 -or ([long]$row[0].next - $nowUs) -lt (16200L * 1000000L)) { throw "Pre-probe: $unit elapses within the cold window plus margin" }
    }
    $processes = Invoke-WslProbe @('/usr/bin/ps','-ww','-eo','args=')
    if ($processes.rc -ne 0) { throw 'Pre-probe: distro process listing failed' }
    foreach ($line in $processes.lines) {
        $names = @(($line.Trim() -split '\s+') | Select-Object -First 2 | ForEach-Object { $_.Substring($_.LastIndexOf('/') + 1) })
        if ($names[0] -cin @('apt','apt-get','dpkg','unattended-upgrade','packagekitd') -or
            ($names.Count -gt 1 -and $names[1] -cin @('unattended-upgrade','apt.systemd.daily')) -or $line -match $ColdActorPattern) {
            throw 'Pre-probe: package manager or cold/qualification actor running in the distro'
        }
    }
    $info = & 'C:\Program Files\Docker\Docker\resources\bin\docker.exe' --context desktop-linux info --format '{{.ID}} {{.ServerVersion}}'
    if ($LASTEXITCODE -ne 0 -or ($info -join '').Trim() -cne 'aa8f3d33-e1dc-4ed2-ad06-488b46b332d0 29.8.1') { throw 'Pre-probe: Docker Desktop engine not running with the pinned identity' }
}
$stage = 'namespace'
$copies = [Collections.Generic.List[object]]::new()
$exitCode = 1
$failure = $null
$started = $null
try {
    foreach ($path in @($helpers, $control)) {
        [VastCold.Native]::CreateDirectoryExclusive($path)
        $guards.Add((Open-ColdGuard $path $true))
    }
    $stage = 'helper_copy'
    foreach ($name in $pins.Keys) {
        $copy = Copy-ColdHelper (Join-Path $base $name) $pins[$name] (Join-Path $helpers $name)
        $copies.Add($copy)
        $guards.Add($copy.source)
        $guards.Add($copy.copy)
    }
    $stage = 'operation'
    $p = [Diagnostics.Process]::new()
    $p.StartInfo.FileName = [Environment]::ProcessPath
    $p.StartInfo.UseShellExecute = $false
    $p.StartInfo.CreateNoWindow = $true
    $p.StartInfo.RedirectStandardOutput = $true
    $p.StartInfo.RedirectStandardError = $true
    $p.StartInfo.StandardOutputEncoding = $utf8
    $p.StartInfo.StandardErrorEncoding = $utf8
    foreach ($arg in @('-NoLogo','-NoProfile','-NonInteractive','-File',(Join-Path $helpers $selected.recipe))) { $p.StartInfo.ArgumentList.Add($arg) }
    if (!$p.Start()) { throw 'Protected operation not started' }
    $o = $p.StandardOutput.ReadToEndAsync()
    $e = $p.StandardError.ReadToEndAsync()
    $started = [Diagnostics.Stopwatch]::StartNew()
    $p.WaitForExit()
    $started.Stop()
    $exitCode = $p.ExitCode
    [IO.File]::WriteAllText((Join-Path $control 'original.stdout'),$o.GetAwaiter().GetResult(),$utf8)
    [IO.File]::WriteAllText((Join-Path $control 'original.stderr'),$e.GetAwaiter().GetResult(),$utf8)
    $stage = 'operation_closed'
} catch {
    $failure = [ordered]@{stage=$stage;type=$_.Exception.GetType().FullName;message=$_.Exception.Message}
}
$result = [ordered]@{operation=$Operation;amendment_sha256=$ColdAmendmentSha256;retry_amendment_sha256='b70f3601eb52d7706179fef7a607371c289d4b5ed2ddb0f1778c43c7c8820965';
    library_amendment_sha256='8d2b9d4dd1ca4b6cda5ce5a0a4807582af34bf46e1f9f02449d69054416f420e';recipe=(Join-Path $helpers $selected.recipe);
    helper_sha256=$pins;helper_copies=@($copies | ForEach-Object { [ordered]@{sha256=$_.sha256;source=$_.source.record;copy=$_.copy.record} });
    recorder_failure=$failure;stage=$stage;original_launcher_returncode=$(if ($null -eq $failure) { $exitCode } else { $null });
    elapsed_seconds=$(if ($started) { $started.Elapsed.TotalSeconds } else { $null });finished_utc=[DateTimeOffset]::UtcNow.ToString('o')}
$receipt = if ([IO.Directory]::Exists($control)) { Join-Path $control 'original.result.v1.json' } else { Join-Path $ColdRootPath ('recorder-failure-' + $Operation.ToLowerInvariant() + '.v1.json') }
[IO.File]::WriteAllText($receipt,(ConvertTo-Json $result -Depth 6),$utf8)
Write-Output (ConvertTo-Json $result -Compress -Depth 6)
foreach ($guard in $guards) { $guard.handle.Dispose() }
$moduleStream.Dispose()
if ($null -ne $failure) { exit 1 }
exit $exitCode
# D7 exact original body: END
}
# D7 preserved host predicates: END

try {
    if ([string]::IsNullOrEmpty($DiagnosticFixture) -or $args.Count) { throw 'D7 fixture-only recorder dispatch refused' }
    $sealedManifestPath=$DiagnosticFixture
    . (Join-Path $PSScriptRoot 'Run-ColdDockerRecovery.v6.ps1')
    $fixture=Read-ColdDiagnosticFixture $sealedManifestPath
    $frame=New-ColdDiagnosticFrame 'recorder'
    Set-ColdDiagnosticIdentity $fixture $frame
    [void](Invoke-ColdDiagnosticCapture $fixture $frame ([Environment]::ProcessPath) @('-NoLogo','-NoProfile','-NonInteractive','-File',(Join-Path $PSScriptRoot 'Run-ColdDockerRecovery.v6.ps1'),'-DiagnosticFixture',$sealedManifestPath) $null)
    $result=@(Complete-ColdDiagnosticLayer $fixture $frame 'launcher.result.v6.json')
    foreach($value in $result){if($value -is [string]){Write-Output $value}}
    if($result[-1]){exit 0}else{exit 1}
} catch { Write-Output (ConvertTo-Json @{fixture=$true;recovery_acceptance=$false;entrypoint_failure_type=$_.Exception.GetType().FullName} -Compress);exit 1 }
