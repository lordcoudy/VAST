# D7 diagnostics derivative of pinned launcher v5 (54535e95...). No live entrypoint.
param([string]$DiagnosticFixture)
$ErrorActionPreference='Stop'
$utf8=[Text.UTF8Encoding]::new($false)
$ColdDiagnosticBase=$PSScriptRoot

function Get-ColdFixtureHash([string]$Path) {
    $file=Get-Item -LiteralPath $Path
    if ($file.PSIsContainer -or ($file.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $file.Length -gt 1048576) { throw 'Fixture source unsafe' }
    return [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([IO.File]::ReadAllBytes($Path))).ToLowerInvariant()
}
function Read-ColdDiagnosticFixture([string]$Path) {
    if (![IO.Path]::IsPathFullyQualified($Path)) { throw 'Fixture path not absolute' }
    $item=Get-Item -LiteralPath $Path
    if ($item.PSIsContainer -or $item.Name -cne 'fixture.json' -or $item.Length -gt 16384 -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Fixture manifest unsafe' }
    if ($item.Directory.Parent.FullName -cne $ColdDiagnosticBase) { throw 'Fixture root foreign' }
    $raw=[IO.File]::ReadAllBytes($item.FullName)
    $sha=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($raw)).ToLowerInvariant()
    if ([IO.File]::ReadAllText([IO.Path]::ChangeExtension($Path,'sha256'),$utf8) -cne $sha) { throw 'Fixture seal mismatch' }
    $value=$utf8.GetString($raw) | ConvertFrom-Json -AsHashtable
    $document=[Text.Json.JsonDocument]::Parse($raw)
    try {
        foreach($obj in @($document.RootElement,$document.RootElement.GetProperty('helper_sha256'))) {
            $seen=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
            foreach($property in $obj.EnumerateObject()) { if(!$seen.Add($property.Name)){throw 'Duplicate fixture key'} }
        }
    } finally {$document.Dispose()}
    $keys=@('kind','fixture','recovery_acceptance','case','nonce','case_root','helper_sha256','planning_commit','case_limit','cohort_limit')
    if (@($value.Keys).Count -ne $keys.Count -or @($value.Keys | Where-Object {$_ -cnotin $keys}).Count) { throw 'Fixture membership drift' }
    if ($value.kind -cne 'cold_diagnostics_fixture_v6' -or $value.fixture -isnot [bool] -or !$value.fixture -or $value.recovery_acceptance -isnot [bool] -or $value.recovery_acceptance) { throw 'Fixture scope drift' }
    $cases=@('primary_forced','primary_unknown','signal_send','command_receipt','guest_receipt','timer_disable','timer_restore','mask_restore','stream_close','cleanup','graceful','outer_zero_unknown','native_budget','operator_stop','launcher_raw_write','recorder_raw_write','launcher_receipt','recorder_receipt')
    if ($value.case -cnotin $cases -or $value.nonce -cnotmatch '^[a-f0-9]{32}$' -or $value.case_root -cne $item.Directory.FullName -or $item.Directory.Name -cne ('case-'+$value.case+'-'+$value.nonce)) { throw 'Fixture identity drift' }
    if ($value.planning_commit -cne '4666e9e21741eda1f2f5b72d5a2de4bba6a7cd1a' -or $value.case_limit -ne 1048576 -or $value.cohort_limit -ne 16777216 -or $value.case_limit -is [bool] -or $value.cohort_limit -is [bool]) { throw 'Fixture gates drift' }
    $names=@('cold_restore_docker_archive_v6.py','Run-RecordedColdOperation.v6.ps1','Run-ColdDockerRecovery.v6.ps1','Native-ColdGuardian.v6.ps1')
    if (@($value.helper_sha256.Keys).Count -ne $names.Count -or @($value.helper_sha256.Keys | Where-Object {$_ -cnotin $names}).Count) { throw 'Fixture helper membership drift' }
    foreach($name in $names) { if ((Get-ColdFixtureHash (Join-Path $ColdDiagnosticBase $name)) -cne $value.helper_sha256[$name]) { throw 'Fixture helper drift' } }
    foreach($name in @('guest.result.v6.json','launcher.result.v6.json','recorder.result.v6.json','0001-fixture-command.stdout','0001-fixture-command.stderr','0001-fixture-command.result.json')) { if(Test-Path -LiteralPath (Join-Path $value.case_root $name)){throw 'Fixture output already exists; no replay'} }
    for($directory=$item.Directory;$null -ne $directory;$directory=$directory.Parent) { if ($directory.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Fixture ancestor redirected' } }
    return $value
}
function New-ColdDiagnosticFrame([string]$Layer) {
    return [ordered]@{layer=$Layer;fixture=$true;recovery_acceptance=$false;primary=$null;secondary=[Collections.Generic.List[object]]::new();capture_unavailable=$false;original_child_returncode=$null;child_pid=$null;closure='not_started';forced_kill=$false;child_report=$null;child_report_available=$false;result_attempted=$false;result_available=$null;diagnostic_complete=$false}
}
function Set-ColdDiagnosticIdentity($Fixture,$Frame) {
    $Frame.kind='cold_diagnostics_fixture_report_v6';$Frame.case=$Fixture.case;$Frame.nonce=$Fixture.nonce
    $Frame.planning_commit=$Fixture.planning_commit;$Frame.helper_sha256=$Fixture.helper_sha256
}
function Add-ColdDiagnosticCause($Frame,[Exception]$Original,[string]$Phase,[bool]$Primary=$false) {
    try {
        $row=[ordered]@{operation=$Frame.layer;phase=$Phase;reason_code='diagnostic-external-failure';type=$Original.GetType().FullName;hresult=[int]$Original.HResult;exception_contents_retained=$false;synthetic_provider=$true}
        if ($utf8.GetByteCount((ConvertTo-Json $row -Compress)) -gt 16384) { throw 'Diagnostic cause cap' }
        if ($null -eq $Frame.primary) { $Frame.primary=$row } else { $Frame.secondary.Add($row) }
    } catch { $Frame.capture_unavailable=$true; if ($null -eq $Frame.primary) { $Frame.primary=@{operation=$Frame.layer;phase=$Phase;reason_code='diagnostic-capture-unavailable';exception_contents_retained=$false} } }
}
function Get-ColdDiagnosticBytes([string]$Root) {
    $sum=0L
    foreach($file in [IO.Directory]::EnumerateFiles($Root,'*',[IO.SearchOption]::AllDirectories)) { $sum += [IO.FileInfo]::new($file).Length }
    return $sum
}
function Write-ColdDiagnosticBytes($Fixture,[string]$Name,[byte[]]$Bytes) {
    if ($Name -cnotmatch '^[a-z0-9_.-]+$') { throw 'Fixture output name refused' }
    if ((Get-ColdDiagnosticBytes $Fixture.case_root)+$Bytes.Length -gt 1032192 -or (Get-ColdDiagnosticBytes $ColdDiagnosticBase)+$Bytes.Length -gt 16760832) { throw 'Fixture output cap' }
    $stream=[IO.FileStream]::new((Join-Path $Fixture.case_root $Name),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
    try { $stream.Write($Bytes,0,$Bytes.Length) } finally { $stream.Dispose() }
}
function Invoke-ColdDiagnosticCapture($Fixture,$Frame,[string]$Executable,[string[]]$Arguments,[scriptblock]$Monitor) {
    $p=[Diagnostics.Process]::new()
    $p.StartInfo.FileName=$Executable
    $p.StartInfo.UseShellExecute=$false
    $p.StartInfo.CreateNoWindow=$true
    $p.StartInfo.RedirectStandardOutput=$true
    $p.StartInfo.RedirectStandardError=$true
    $p.StartInfo.StandardOutputEncoding=$utf8
    $p.StartInfo.StandardErrorEncoding=$utf8
    foreach($argument in $Arguments) { $p.StartInfo.ArgumentList.Add($argument) }
    $out=[Text.StringBuilder]::new();$err=[Text.StringBuilder]::new()
    $buffers=@([char[]]::new(4096),[char[]]::new(4096))
    $reads=@($null,$null);$ended=@($false,$false)
    $clock=[Diagnostics.Stopwatch]::StartNew()
    try {
        if (!$p.Start()) { throw 'Fixture child not started' }
        $Frame.child_pid=$p.Id
        $Frame.child_start_utc_ticks=$p.StartTime.ToUniversalTime().Ticks
        $Frame.observer_pid=$PID
        $Frame.closure='unknown'
        $readers=@($p.StandardOutput,$p.StandardError);$writers=@($out,$err)
        $reads[0]=$readers[0].ReadAsync($buffers[0],0,4096)
        $reads[1]=$readers[1].ReadAsync($buffers[1],0,4096)
        while (!$p.HasExited -or !$ended[0] -or !$ended[1]) {
            if ($clock.Elapsed.TotalSeconds -ge 60) { $Frame.forced_kill=$true;throw 'Fixture watchdog' }
            if ($null -ne $Monitor -and !$p.HasExited) { & $Monitor }
            for($i=0;$i -lt 2;$i++) {
                if (!$ended[$i] -and $reads[$i].IsCompleted) {
                    $n=$reads[$i].GetAwaiter().GetResult()
                    if (!$n) { $ended[$i]=$true;continue }
                    [void]$writers[$i].Append($buffers[$i],0,$n)
                    if ($utf8.GetByteCount($writers[$i].ToString()) -gt 131072) { throw 'Fixture channel cap' }
                    $reads[$i]=$readers[$i].ReadAsync($buffers[$i],0,4096)
                }
            }
            [void]$p.WaitForExit(5)
        }
        $Frame.original_child_returncode=$p.ExitCode
        $Frame.closure='closed'
    } catch {
        $original=$_
        Add-ColdDiagnosticCause $Frame $original.Exception 'capture' $true
        if ($Frame.child_pid -and !$p.HasExited) {
            $Frame.forced_kill=$true
            try { $p.Kill($true);[void]$p.WaitForExit(10000) } catch { Add-ColdDiagnosticCause $Frame $_.Exception 'owned-child-teardown' }
        }
        if ($Frame.child_pid -and $p.HasExited) { $Frame.original_child_returncode=$p.ExitCode;$Frame.closure='closed' }
    } finally {
        foreach($channel in @('stdout','stderr')) {
            try {
                if ($Fixture.case -ceq ($Frame.layer+'_raw_write')) { throw 'Controlled raw-write failure' }
                $text=if($channel -ceq 'stdout'){$out.ToString()}else{$err.ToString()}
                Write-ColdDiagnosticBytes $Fixture ($Frame.layer+'.original.'+$channel) ($utf8.GetBytes($text))
            } catch { Add-ColdDiagnosticCause $Frame $_.Exception ($channel+'-write') }
        }
        if ($Frame.child_pid) { foreach($stream in @($p.StandardOutput,$p.StandardError)) { try {$stream.Dispose()} catch {Add-ColdDiagnosticCause $Frame $_.Exception 'stream-close'} } }
        try {$p.Dispose()} catch {Add-ColdDiagnosticCause $Frame $_.Exception 'process-close'}
    }
    return $Frame
}
function Complete-ColdDiagnosticLayer($Fixture,$Frame,[string]$ChildResult) {
    try {
        $childPath=Join-Path $Fixture.case_root $ChildResult
        $childInfo=Get-Item -LiteralPath $childPath
        if ($childInfo.Length -gt 524288 -or ($childInfo.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Fixture child report unsafe' }
        $Frame.child_report=([IO.File]::ReadAllText($childPath,$utf8) | ConvertFrom-Json -AsHashtable)
        $child=$Frame.child_report
        $expectedLayer=if($Frame.layer -ceq 'launcher'){'guest'}else{'launcher'}
        if($child.kind -cne 'cold_diagnostics_fixture_report_v6' -or $child.layer -cne $expectedLayer -or $child.fixture -ne $true -or $child.recovery_acceptance -ne $false -or $child.case -cne $Fixture.case -or $child.nonce -cne $Fixture.nonce -or $child.planning_commit -cne $Fixture.planning_commit){throw 'Foreign child report'}
        foreach($name in $Fixture.helper_sha256.Keys){if($child.helper_sha256[$name] -cne $Fixture.helper_sha256[$name]){throw 'Foreign child source report'}}
        $Frame.child_report_available=$true
    } catch { Add-ColdDiagnosticCause $Frame $_.Exception 'child-result-read' }
    $nativeFail=$false
    if ($Frame.layer -ceq 'launcher') {
        $Frame.native_causes=@($script:diagnosticCauses.ToArray())
        $Frame.native_capture_failures=@($script:nativeDiagnosticCaptureFailures.ToArray())
        $Frame.native_capture_unavailable=[bool]$script:nativeDiagnosticCaptureUnavailable
        $Frame.native_pending_cause=$script:pendingNativeDiagnosticCause
        $Frame.native_stopped=[bool]$script:stopped
        $nativeFail=$Frame.native_causes.Count -or $Frame.native_capture_failures.Count -or $Frame.native_capture_unavailable -or $Frame.native_stopped
    }
    $Frame.diagnostic_complete=($Frame.original_child_returncode -ceq 0 -and $Frame.closure -ceq 'closed' -and !$Frame.forced_kill -and $null -eq $Frame.primary -and !$Frame.secondary.Count -and !$Frame.capture_unavailable -and $Frame.child_report_available -and $Frame.child_report.diagnostic_complete -and !$nativeFail)
    $Frame.result_attempted=$true
    try {
        if ($Fixture.case -ceq ($Frame.layer+'_receipt')) { throw 'Controlled layer receipt failure' }
        Write-ColdDiagnosticBytes $Fixture ($Frame.layer+'.result.v6.json') ($utf8.GetBytes((ConvertTo-Json $Frame -Depth 16 -Compress)))
        $Frame.result_available=$true
    } catch { $Frame.result_available=$false;$Frame.diagnostic_complete=$false;Add-ColdDiagnosticCause $Frame $_.Exception 'layer-result-write' }
    Write-Output (ConvertTo-Json $Frame -Depth 16 -Compress)
    return [bool]$Frame.diagnostic_complete
}
function Set-ColdNativeFixture($Fixture) {
    $script:NativeDiagnosticFixture=$true
    $script:heartbeatSequence=0L;$script:publicationRetries=0L;$script:stopped=$false;$script:stopMarkerWritten=$false
    $script:minimumC=$null;$script:minimumE=$null
    $script:diagnosticCauses=[Collections.Generic.List[object]]::new()
    $script:nativeDiagnosticCaptureFailures=[Collections.Generic.List[object]]::new()
    $script:nativeDiagnosticCaptureUnavailable=$false;$script:pendingNativeDiagnosticCause=$null
    $script:fixtureTick=0L
    $script:fixtureNativeCase=$Fixture.case
    $script:fixtureNativeRoot=$Fixture.case_root
    $script:NativeDiagnosticEffects=@{
        tick={param($phase) $script:fixtureTick += [long]([Diagnostics.Stopwatch]::Frequency/100);if($script:fixtureNativeCase -ceq 'native_budget' -and $phase -ceq 'post-write'){$script:fixtureTick += [Diagnostics.Stopwatch]::Frequency};return $script:fixtureTick}
        freeC={param($phase) return 40GB+1L};freeE={param($phase) return 12GB+1L}
        exists={param($phase,$path) return (Test-Path -LiteralPath $path)}
        utc={param($phase) return 'fixture-labelled-utc'}
        write={param($phase,$path,$payload) [IO.File]::WriteAllText($path,$payload,$utf8)}
        move={param($phase,$from,$to) [IO.File]::Move($from,$to,$true)}
        append={param($phase,$path,$payload) [IO.File]::AppendAllText($path,$payload,$utf8)}
        sleep={param($phase,$milliseconds) return}
    }
}
function Invoke-ColdDiagnosticLauncher([string]$ManifestPath) {
    $fixture=Read-ColdDiagnosticFixture $ManifestPath
    $frame=New-ColdDiagnosticFrame 'launcher'
    Set-ColdDiagnosticIdentity $fixture $frame
    $control=$fixture.case_root;$sessionId='fixture-'+$fixture.nonce
    $guardianErrors=[Collections.Generic.List[object]]::new()
    . (Join-Path $ColdDiagnosticBase 'Native-ColdGuardian.v6.ps1')
    Set-ColdNativeFixture $fixture
    $monitor={
        if (!$script:stopped) {
            try { Publish-NativeHeartbeat (40GB+1L) (12GB+1L) } catch { Add-ColdDiagnosticCause $frame $_.Exception 'sample-or-publish' $true;Stop-NativeGuardian 'Fixture native publication failed.' }
        }
        if ($fixture.case -ceq 'operator_stop' -and !$script:stopped) { Stop-NativeGuardian 'Fixture operator stop.' }
    }
    $python=(Get-Command python -CommandType Application | Select-Object -First 1).Source
    [void](Invoke-ColdDiagnosticCapture $fixture $frame $python @('-I','-B',(Join-Path $ColdDiagnosticBase 'cold_restore_docker_archive_v6.py'),'--diagnostics-fixture',$ManifestPath) $monitor)
    $closed=@(Complete-ColdDiagnosticLayer $fixture $frame 'guest.result.v6.json')
    foreach($value in $closed) { if($value -is [string]){Write-Output $value} }
    return [bool]$closed[-1]
}
if ($MyInvocation.InvocationName -cne '.') {
    try {
        if ([string]::IsNullOrEmpty($DiagnosticFixture) -or $args.Count) { throw 'D7 fixture-only launcher dispatch refused' }
        $complete=@(Invoke-ColdDiagnosticLauncher $DiagnosticFixture)
        foreach($value in $complete){if($value -is [string]){Write-Output $value}}
        if($complete[-1]){exit 0}else{exit 1}
    } catch { Write-Output (ConvertTo-Json @{fixture=$true;recovery_acceptance=$false;entrypoint_failure_type=$_.Exception.GetType().FullName} -Compress);exit 1 }
}
