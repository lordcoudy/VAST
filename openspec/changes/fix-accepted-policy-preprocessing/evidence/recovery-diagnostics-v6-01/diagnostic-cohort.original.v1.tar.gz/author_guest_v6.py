"""Authoring utility only: derive v6 from untouched pinned v5, never execute v5."""
import ast
import hashlib
from pathlib import Path

source=Path('E:/STUDY/VAST/tmp/host-cache-cleanup-20261012/cold_restore_docker_archive_v5.py')
out=Path(__file__).resolve().parent
raw=source.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='6a63c732ae26f3dc24187779a1434021a932e00725fdc31edab05d051dd9993f'
lines=raw.decode().splitlines(keepends=True)
replacement={
 'finish_process':'def finish_process(process):\n    frame = _frame("owned-child")\n    actions = _finish_reporting_process(process,frame)\n    actions["secondary_causes"] = frame["secondary"]\n    return actions\n',
 'pause_finalization_signals':'def pause_finalization_signals():\n    return _pause_reporting_signals(_frame("finalization"))\n',
 'resume_finalization_signals':'def resume_finalization_signals(state):\n    return _resume_reporting_signals(state,_frame("finalization"))\n',
 'run':'def run(args,label,timeout=1800,check=True,guarded=True,stdin=subprocess.DEVNULL):\n    return _reporting_run(args,label,timeout,check,guarded,stdin)\n',
 'daemon':'''def daemon(args,label):
    if _DIAGNOSTIC_EFFECTS is not None:
        raise ValueError('fixture_daemon_crossover')
    if args[0]!=runtime_binary(Path(args[0]).name):
        fail('cold_unreviewed_daemon_path')
    output=(CONTROL/(label+'.stdout')).open('xb')
    error=(CONTROL/(label+'.stderr')).open('xb')
    process=subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=output,stderr=error,env=ENV)
    DAEMONS.append((process,output,error,label))
    frame=_frame(label)
    frame['requires_successful_exit']=True
    entry=_register_child(process,frame)
    entry['streams']=((output,'stdout'),(error,'stderr'))
    if entry['metadata_error'] is not None:
        raise entry['metadata_error']
    write_json(label+'.started.json',{'argv':args,'namespace_pid':process.pid})
    return process
''',
 'guarded_main':'''def guarded_main():
    if _DIAGNOSTIC_EFFECTS is not None:
        raise ValueError('fixture_live_main_crossover')
    def cancel(signum,frame):
        raise RuntimeError('owned_supervisor_cancelled_'+str(signum))
    for termination_signal in (signal.SIGTERM,signal.SIGHUP,signal.SIGINT):
        signal.signal(termination_signal,cancel)
    if ctypes.CDLL(None,use_errno=True).prctl(1,signal.SIGTERM,0,0,0)!=0:
        raise SystemExit('Parent-death cancellation could not be established')
    signal.signal(signal.SIGALRM,lambda signum,frame:alarm_guard())
    signal.setitimer(signal.ITIMER_REAL,5,5)
    def cleanup():
        signal.setitimer(signal.ITIMER_REAL,0)
        for termination_signal in (signal.SIGTERM,signal.SIGHUP,signal.SIGINT):
            signal.signal(termination_signal,signal.SIG_IGN)
        _cleanup_reporting_live_resources(_DIAGNOSTIC_FRAME)
    report=_reporting_operation(main,cleanup)
    raise SystemExit(0 if report['diagnostic_complete'] else 1)
''',
}
for node in reversed(ast.parse(raw).body):
    if isinstance(node,ast.FunctionDef) and node.name in replacement:
        lines[node.lineno-1:node.end_lineno]=[replacement[node.name]]
text=''.join(lines)
marker="if __name__ == '__main__':"
assert text.count(marker)==1
text=text[:text.index(marker)]+(out/'guest_reporting_v6.fragment.py.txt').read_text()+'''\n\nif __name__ == '__main__':
    try:
        if len(sys.argv)==3 and sys.argv[1] in {'--diagnostics-fixture','--fixture-child'}:
            raise SystemExit(_fixture_entry(sys.argv[2],sys.argv[1]=='--fixture-child'))
        raise SystemExit('D7 fixture-only entrypoint; no live/admission/default dispatch')
    except Exception as failure:
        print(json.dumps({'fixture':True,'recovery_acceptance':False,'entrypoint_failure_type':type(failure).__name__}),flush=True)
        raise SystemExit(1)
'''
(out/'cold_restore_docker_archive_v6.py').write_text(text,encoding='utf-8',newline='\n')
assert source.read_bytes()==raw
print(hashlib.sha256((out/'cold_restore_docker_archive_v6.py').read_bytes()).hexdigest())
