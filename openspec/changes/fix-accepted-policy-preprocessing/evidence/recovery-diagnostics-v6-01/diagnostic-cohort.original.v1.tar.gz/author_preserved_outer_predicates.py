"""Retain unchanged original host predicates behind an unconditional D7 refusal."""
import hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
original=Path('E:/STUDY/VAST/tmp/host-cache-cleanup-20261012')
subjects=(('Run-RecordedColdOperation.v3.ps1','Run-RecordedColdOperation.v6.ps1','Recorder','de2d4bf496b59e9e2b5f0e7bbced0a057da752c8b072b1f4e4fc6165bc1195fc'),
 ('Run-ColdDockerRecovery.v5.ps1','Run-ColdDockerRecovery.v6.ps1','Launcher','54535e950c0782129172e1822058b2d4a64ff1cb7d55dab36510c1fc6b20cec0'))
for old,new,role,pin in subjects:
    data=(original/old).read_bytes()
    assert hashlib.sha256(data).hexdigest()==pin
    text=(root/new).read_text()
    marker='# D7 preserved host predicates: BEGIN'
    assert marker not in text
    # Do not expose a parameter or authority switch capable of passing this gate.
    historical=data.decode('utf-8').replace('\r\n','\n')
    if role=='Recorder':
        # The original script parameter becomes a dormant function parameter unchanged.
        line="param([Parameter(Mandatory=$true)][ValidateSet('Retire','Cold')][string]$Operation)\n"
        assert historical.count(line)==1
        head,historical=historical.split(line)
        parameter=head+line
    else:
        parameter=''
    preserved=(marker+'\nfunction Invoke-ColdPreserved'+role+'Predicates {\n'+parameter+
      "    throw 'D7 grants fixture diagnostics only; preserved host route is unconditionally withheld'\n"+
      '# D7 exact original body: BEGIN\n'+historical+'# D7 exact original body: END\n}\n'+
      '# D7 preserved host predicates: END\n\n')
    position=text.index('function ') if role=='Launcher' else text.index('try {')
    (root/new).write_text(text[:position]+preserved+text[position:],encoding='utf-8',newline='\n')
    assert (original/old).read_bytes()==data
print('Preserved dormant exact original host body predicates; both direct host routes remain unconditionally refused.')
