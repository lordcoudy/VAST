"""Focused synthetic-effects regression for the actual daemon/finalization bodies.

This is component evidence alongside the full composed fixture; it never imports
the production module, executes main, creates a real daemon or grants recovery.
"""
import ast
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
from types import SimpleNamespace
import unittest

ROOT=Path(__file__).resolve().parent
RED_SOURCE=ROOT/'composed-authored-run-8c31434b17944a6cbc8c5038dda83d70'/'source-snapshot'/'cold_restore_docker_archive_v6.py'
RED_SHA='8f68298509ff762d6a22fc594da535394b9c4cced8f48b2df800509e7c8777e1'
FUNCTIONS={'daemon','_frame','_secondary','_cause','_extract_cause','_clock','_write_reporting_json',
 '_attempt_result','_observe_returncode','_register_child','_finish_reporting_process',
 '_close_reporting_stream','_reporting_operation'}

def main():
    modes={'--original-candidate-red':(RED_SOURCE,'real-style-daemon-returncode-red-01'),
           '--corrected-candidate-green':(ROOT/'cold_restore_docker_archive_v6.py','real-style-daemon-returncode-green-01')}
    if len(sys.argv)!=2 or sys.argv[1] not in modes:
        return 2
    source,out_name=modes[sys.argv[1]]
    raw=source.read_bytes();source_sha=hashlib.sha256(raw).hexdigest()
    if source==RED_SOURCE and source_sha!=RED_SHA:
        raise ValueError('retained candidate source drift')
    if sum(x.stat().st_size for x in ROOT.rglob('*') if x.is_file())>16*1024**2-16384:
        raise ValueError('diagnostic cohort cap')
    out=ROOT/out_name
    out.mkdir(exist_ok=False)
    tree=ast.parse(raw)
    nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in FUNCTIONS]
    if {n.name for n in nodes}!=FUNCTIONS:
        raise ValueError('focused actual function membership drift')
    calls=[]
    class InertOwnedProcess:
        synthetic=True
        fixture_id='controlled-real-style-nonzero-daemon'
        pid=None
        returncode=7
        def poll(self):return self.returncode
        def send_signal(self,number):calls.append(['signal',number])
        def kill(self):calls.append(['kill'])
        def wait(self,timeout):calls.append(['wait',timeout]);return self.returncode
    def start(argv,**kwargs):
        if argv!=['fixture-daemon']:
            raise ValueError('external process crossover')
        calls.append(['inert_start',argv])
        return InertOwnedProcess()
    def write_json(name,value):
        data=(json.dumps(value)+'\n').encode()
        if len(data)>16384:raise ValueError('fixture source record cap')
        with (out/name).open('xb') as stream:stream.write(data)
    state={'_DIAGNOSTIC_EFFECTS':None,'_OWNED_CHILDREN':[],'_COMMAND_REPORTS':[],
       '_FINALIZATION_ORDER':[],'_DIAGNOSTIC_FRAME':None,'_CASE_LIMIT':1048576,
       'DAEMONS':[],'CONTROL':out,'ENV':{},'Path':Path,'os':os,'sys':sys,'signal':signal,
       'json':json,'time':SimpleNamespace(monotonic=lambda:0.0),
       'subprocess':SimpleNamespace(Popen=start,DEVNULL=subprocess.DEVNULL),
       'runtime_binary':lambda name:'fixture-daemon','write_json':write_json,
       'fail':lambda reason:(_ for _ in ()).throw(RuntimeError(reason))}
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),state)
    capture=io.StringIO()
    with contextlib.redirect_stdout(capture):
        observed=state['_reporting_operation'](lambda:state['daemon'](['fixture-daemon'],'controlled-daemon'),lambda:None)
    class DaemonReturncodePredicate(unittest.TestCase):
        def test_nonzero_real_style_daemon_closure_is_refused(self):
            child=observed['children'][0]
            self.assertEqual(child['original_returncode'],7)
            self.assertEqual(child['closure'],'closed')
            self.assertFalse(child['forced_kill'])
            self.assertTrue(child['requires_successful_exit'])
            self.assertFalse(observed['diagnostic_complete'])
    stderr=io.StringIO()
    result=unittest.TextTestRunner(stream=stderr,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(DaemonReturncodePredicate))
    metadata={'kind':'D7_real_style_daemon_predicate_control_v1','fixture':True,'recovery_acceptance':False,
      'source':str(source),'source_sha256':source_sha,'source_after_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
      'controlled_effects':['process factory returning inert owned handle','clock','runtime path predicate','ordinary exclusive fixture files'],
      'functions':sorted(FUNCTIONS),'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
      'process_calls':calls,'no_real_process_or_main_executed':True,
      'observed_predicate':{'requires_successful_exit':observed['children'][0]['requires_successful_exit'],
                           'diagnostic_complete':observed['diagnostic_complete'],'original_returncode':7},
      'scope':'Controlled component regression only; internal printed decision is not a live recovery receipt.'}
    outputs={'unittest.original.stderr':stderr.getvalue().encode(),'internal-controlled.original.stdout':capture.getvalue().encode(),
             'result.original.v1.json':(json.dumps(metadata,indent=2)+'\n').encode()}
    if sum(len(x) for x in outputs.values())+sum(x.stat().st_size for x in out.rglob('*') if x.is_file())>1048576:
        raise ValueError('case cap')
    for name,data in outputs.items():
        with (out/name).open('xb') as stream:stream.write(data)
    sys.stderr.write(stderr.getvalue())
    print(json.dumps({'case':str(out),'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'recovery_acceptance':False}))
    return 0 if result.wasSuccessful() else 1

if __name__=='__main__':raise SystemExit(main())
