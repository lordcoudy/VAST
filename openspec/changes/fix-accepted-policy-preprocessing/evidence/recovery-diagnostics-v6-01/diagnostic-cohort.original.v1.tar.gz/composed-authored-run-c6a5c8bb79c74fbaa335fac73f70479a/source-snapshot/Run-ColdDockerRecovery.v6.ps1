# D7 diagnostics derivative of pinned launcher v5 (54535e95...). No live entrypoint.
param([string]$DiagnosticFixture)
$ErrorActionPreference='Stop'
$utf8=[Text.UTF8Encoding]::new($false)
$ColdDiagnosticBase=$PSScriptRoot

# D7 preserved host predicates: BEGIN
function Invoke-ColdPreservedLauncherPredicates {
    throw 'D7 grants fixture diagnostics only; preserved host route is unconditionally withheld'
# D7 exact original body: BEGIN
# ONE cold03 recovery test (proposal 3a255914, amendments 8a1e58e6/8d2b9d4d). Runs only as the protected copy in
# E:\VAST-cold03-...\helpers-cold03 after provision03 and the exact cold02 retirement both passed. Holds read-share
# guards on the verified TAR, inventory, backup receipt, every authenticated runtime file and all used directories.
$ErrorActionPreference = 'Stop'
$utf8 = [Text.UTF8Encoding]::new($false)
$expectedRoot = 'E:\VAST-cold03-a3990e2870c940149785831b845aea91'
$wslRoot = '/mnt/e/VAST-cold03-a3990e2870c940149785831b845aea91'
$helpers = Join-Path $expectedRoot 'helpers-cold03'
$oldRoot = 'E:\STUDY\VAST\tmp\host-cache-cleanup-20261012\s3-host-archive-3518d90e1d1d48edb2c740e536df6435'
$imageHash = 'd8c5c7ab248d2a574eea502e2ad8729358bd77938fed655788f4acde91772a0e'
$pins = [ordered]@{
    'ColdRootSecurity.v2.ps1' = '69ca07ee87fa93f55f510f46335856acd8b52f58700e8dfdf5f0f0c17cf204a6'
    'Native-ColdGuardian.v1.ps1' = 'e2cbb87a20667aac6039993c70395c600dc861992b85f91260daee9f30a2314a'
    'native_heartbeat_lease_v1.py' = '8aae687de0b919f90c8a12f34bc7798920bc0c41250049aef3595225a4bd7fb4'
    'cold_restore_docker_archive_v5.py' = '6a63c732ae26f3dc24187779a1434021a932e00725fdc31edab05d051dd9993f'
    'run_isolated_cold_restore_v5.sh' = '7dcfe31bb79f01aec5276ca9d471de338597fd1b4d8225893a24b7927b6559b0'
    'Capture-DockerCleanupAudit.v3.ps1' = 'f46125edb0771fc30b5cdabc82a440b641e01e9fd0bb16185bdbeb5ff3d55018'
}
if ($PSScriptRoot -cne $helpers) { throw 'Cold launcher is not the protected helper copy' }
$moduleStream = [IO.FileStream]::new((Join-Path $helpers 'ColdRootSecurity.v2.ps1'), [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
if ([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($moduleStream)).ToLowerInvariant() -cne $pins['ColdRootSecurity.v2.ps1']) { throw 'Security module drift' }
. (Join-Path $helpers 'ColdRootSecurity.v2.ps1')
if ($ColdRootPath -cne $expectedRoot -or [Security.Principal.WindowsIdentity]::GetCurrent().User.Value -cne $ColdOwnerSid) { throw 'Root or identity drift' }
$guards = [Collections.Generic.List[object]]::new()
$rootGuard = Open-ColdGuard $ColdRootPath $true
$guards.Add($rootGuard)
if (@(Test-ColdObjectSddl $rootGuard.record.sddl $true $true).Count) { throw 'Root descriptor not restrictive' }
$guards.Add((Open-ColdGuard $helpers $true))
foreach ($name in $pins.Keys) {
    $guard = Open-ColdGuard (Join-Path $helpers $name) $false
    $guards.Add($guard)
    if ([VastCold.Native]::Sha256($guard.handle) -cne $pins[$name]) { throw "Protected helper drift: $name" }
}
$launcherGuard = Open-ColdGuard $PSCommandPath $false
$guards.Add($launcherGuard)
$launcherSha256 = [VastCold.Native]::Sha256($launcherGuard.handle)
function Read-GuardedJson([string]$Path) {
    $guard = Open-ColdGuard $Path $false
    $guards.Add($guard)
    [pscustomobject]@{value=([IO.File]::ReadAllText($Path, $utf8) | ConvertFrom-Json);sha256=[VastCold.Native]::Sha256($guard.handle)}
}
# Gates: provision03 passed (original recorder, launcher, guest), runtime manifest identity, retirement passed.
$recorded = (Read-GuardedJson (Join-Path $ColdRootPath 'recorded-provision03\original.result.v1.json')).value
$launch = (Read-GuardedJson (Join-Path $ColdRootPath 'provision-launch03\original.result.v1.json')).value
$guest = (Read-GuardedJson (Join-Path $ColdRootPath 'provision03\result.v1.json')).value
$manifest = Read-GuardedJson (Join-Path $ColdRootPath 'runtime03\runtime_manifest.v1.json')
if ($recorded.original_launcher_returncode -ne 0 -or $null -ne $recorded.recorder_failure -or
    $launch.original_returncode -ne 0 -or $launch.forced_kill -or $launch.guardian_stopped -or $launch.stop_marker_written -or
    $launch.guardian_errors.Count -or $launch.post_tree_violations.Count -or $launch.elapsed_seconds -gt 900 -or
    $guest.status -cne 'authenticated_runtime_provisioned' -or $guest.manifest_sha256 -cne $manifest.sha256 -or
    $launch.runtime_manifest_sha256 -cne $manifest.sha256) { throw 'Authenticated provision03 did not pass' }
$retired = (Read-GuardedJson (Join-Path $ColdRootPath 'retire-cold02-scratch01\result.v1.json')).value
$recordedRetire = (Read-GuardedJson (Join-Path $ColdRootPath 'recorded-retire03\original.result.v1.json')).value
if ($retired.status -cne 'only_owned_failed_scratch_retired' -or $recordedRetire.original_launcher_returncode -ne 0 -or
    $null -ne $recordedRetire.recorder_failure) { throw 'Exact cold02 scratch retirement did not pass' }
# Held immutable inputs: TAR, inventory and backup receipt with guarded ancestors.
$inputs = [ordered]@{archive=(Join-Path $oldRoot 'upload03\docker-all-227.downloaded.tar');inventory=(Join-Path $oldRoot 'inventory.downloaded.jsonl');
    backup=(Join-Path $oldRoot 'finalize04\result.v1.json')}
for ($directory = [IO.DirectoryInfo]::new($oldRoot); $null -ne $directory.Parent; $directory = $directory.Parent) { $guards.Add((Open-ColdGuard $directory.FullName $true)) }
foreach ($relative in @('upload03','finalize04')) { $guards.Add((Open-ColdGuard (Join-Path $oldRoot $relative) $true)) }
$inputRecords = [ordered]@{}
foreach ($entry in $inputs.GetEnumerator()) {
    $guard = Open-ColdGuard $entry.Value $false
    $guards.Add($guard)
    $inputRecords[$entry.Key] = $guard.record
}
# Every authenticated runtime file and directory is held read-only for the whole test.
$runtimeRoot = Join-Path $ColdRootPath 'runtime03\rootfs'
foreach ($directory in @((Join-Path $ColdRootPath 'runtime03'), $runtimeRoot) + @([IO.Directory]::EnumerateDirectories($runtimeRoot, '*', [IO.SearchOption]::AllDirectories))) {
    $guards.Add((Open-ColdGuard $directory $true))
}
foreach ($record in ([IO.File]::ReadAllText((Join-Path $ColdRootPath 'runtime03\runtime_manifest.v1.json'), $utf8) | ConvertFrom-Json).files) {
    $guard = Open-ColdGuard (Join-Path $runtimeRoot ($record.relative_path.Replace('/','\'))) $false
    $guards.Add($guard)
}
$allowedReparse = @(@($manifest.value.symlinks) | ForEach-Object { 'runtime03/rootfs/' + $_.relative_path })
$actors = @(Get-ColdConcurrentActors (Get-ColdAncestorProcessIds))
if ($actors.Count) { throw 'Concurrent mutating actor present' }
foreach ($relative in @('cold-launch03','cold03','captures')) {
    $path = Join-Path $ColdRootPath $relative
    [VastCold.Native]::CreateDirectoryExclusive($path)
    $guards.Add((Open-ColdGuard $path $true))
}
$tree = Get-ColdTreeViolations $ColdRootPath $allowedReparse
if ($tree.violations.Count) { throw ('Protected tree not admitted: ' + ($tree.violations -join ',')) }
$control = Join-Path $ColdRootPath 'cold-launch03'
$capture = Join-Path $helpers 'Capture-DockerCleanupAudit.v3.ps1'
$pre = Join-Path $ColdRootPath 'captures\cold03-pre'
$post = Join-Path $ColdRootPath 'captures\cold03-post'
$sessionId = 'a3990e2870c940149785831b845aea91-cold03'
$script:heartbeatSequence = [long]0
$script:publicationRetries = [long]0
$script:stopped = $false
$script:stopMarkerWritten = $false
$guardianErrors = [Collections.Generic.List[object]]::new()
. (Join-Path $helpers 'Native-ColdGuardian.v1.ps1')
function Invoke-PreservationCapture([string]$Name,[string]$CaptureRoot) {
    $p = [Diagnostics.Process]::new()
    $p.StartInfo.FileName = [Environment]::ProcessPath
    $p.StartInfo.UseShellExecute = $false
    $p.StartInfo.CreateNoWindow = $true
    $p.StartInfo.RedirectStandardOutput = $true
    $p.StartInfo.RedirectStandardError = $true
    foreach($a in @('-NoLogo','-NoProfile','-NonInteractive','-File',$capture,'-CaptureRoot',$CaptureRoot)) { $p.StartInfo.ArgumentList.Add($a) }
    [void]$p.Start()
    $o = $p.StandardOutput.ReadToEndAsync()
    $e = $p.StandardError.ReadToEndAsync()
    $p.WaitForExit()
    [IO.File]::WriteAllText((Join-Path $control "$Name.stdout"),$o.GetAwaiter().GetResult(),$utf8)
    [IO.File]::WriteAllText((Join-Path $control "$Name.stderr"),$e.GetAwaiter().GetResult(),$utf8)
    [IO.File]::WriteAllText((Join-Path $control "$Name.result.json"),(ConvertTo-Json @{original_returncode=$p.ExitCode;capture_root=$CaptureRoot}),$utf8)
    return $p.ExitCode
}
if ((Invoke-PreservationCapture 'pre' $pre) -ne 0 -or (Get-FileHash -LiteralPath (Join-Path $pre 'image-identities.stdout.raw') -Algorithm SHA256).Hash.ToLowerInvariant() -cne $imageHash) { throw 'Desktop pre-test preservation audit failed; no cold test started' }
$minimumC = [IO.DriveInfo]::new('C:\').AvailableFreeSpace
$minimumE = [IO.DriveInfo]::new('E:\').AvailableFreeSpace
if ($minimumC -lt 40GB -or $minimumE -lt 112GB) { throw 'Fresh post-capture cold03 C40/E112 admission failed; no guest attempt started' }
Publish-NativeHeartbeat $minimumC $minimumE
$psi = [Diagnostics.ProcessStartInfo]::new()
$psi.FileName = 'C:\Windows\System32\wsl.exe'
foreach ($a in @('--distribution','Ubuntu','--user','root','--exec','/usr/bin/env','-i','PATH=/usr/sbin:/usr/bin:/sbin:/bin','LANG=C','LC_ALL=C',
                 ('VAST_COLD_RUNTIME_MANIFEST_SHA256=' + $manifest.sha256),'/usr/bin/bash','--noprofile','--norc',($wslRoot + '/helpers-cold03/run_isolated_cold_restore_v5.sh'))) { $psi.ArgumentList.Add($a) }
$psi.UseShellExecute = $false
$psi.CreateNoWindow = $true
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true
$psi.StandardOutputEncoding = $utf8
$psi.StandardErrorEncoding = $utf8
$process = [Diagnostics.Process]::new()
$process.StartInfo = $psi
if (-not $process.Start()) { throw 'Cold launcher process not started' }
$stdout = $process.StandardOutput.ReadToEndAsync()
$stderr = $process.StandardError.ReadToEndAsync()
$started = [Diagnostics.Stopwatch]::StartNew()
$forcedKill = $false
while (-not $process.WaitForExit(2000)) {
    # Guest budget 3 h; hard deadline 3 h + 10 min. A forced kill blocks acceptance.
    if ($started.Elapsed.TotalSeconds -ge 11400) {
        $forcedKill = $true
        $guardianErrors.Add(@{stage='hard-deadline';type='forced_kill';note='linux_guest_may_outlive_wsl_exe'})
        try { $process.Kill($true) } catch { $guardianErrors.Add(@{stage='hard-deadline-kill';type=$_.Exception.GetType().FullName}) }
        if (!$process.WaitForExit(30000)) { $guardianErrors.Add(@{stage='hard-deadline-wait';type='process_still_running'}) }
        break
    }
    if ($script:stopped) { continue }
    try {
        $cFree = [IO.DriveInfo]::new('C:\').AvailableFreeSpace
        $eFree = [IO.DriveInfo]::new('E:\').AvailableFreeSpace
        $minimumC = [Math]::Min($minimumC, $cFree)
        $minimumE = [Math]::Min($minimumE, $eFree)
        if ($cFree -lt 40GB -or $eFree -lt 12GB) { Stop-NativeGuardian 'Native C/E floor failed; stop only this owned recovery test.' }
        else { Publish-NativeHeartbeat $cFree $eFree }
    } catch {
        $guardianErrors.Add(@{stage='sample-or-publish';type=$_.Exception.GetType().FullName})
        Stop-NativeGuardian 'Native guardian sample or publication failed; stop only this owned test.'
    }
}
if (!$forcedKill) { $process.WaitForExit() }
$started.Stop()
$exitCode = if ($process.HasExited) { $process.ExitCode } else { $null }
$out = if ($stdout.Wait(30000)) { $stdout.GetAwaiter().GetResult() } else { $guardianErrors.Add(@{stage='stdout-drain';type='timeout'}); '' }
$err = if ($stderr.Wait(30000)) { $stderr.GetAwaiter().GetResult() } else { $guardianErrors.Add(@{stage='stderr-drain';type='timeout'}); '' }
[IO.File]::WriteAllText((Join-Path $control 'original.stdout'), $out, $utf8)
[IO.File]::WriteAllText((Join-Path $control 'original.stderr'), $err, $utf8)
$postRC = Invoke-PreservationCapture 'post' $post
$same = $false
if ($postRC -eq 0) { $same = (Get-FileHash -LiteralPath (Join-Path $post 'image-identities.stdout.raw') -Algorithm SHA256).Hash.ToLowerInvariant() -ceq $imageHash }
$finalC = $null
$finalE = $null
try {
    $finalC = [IO.DriveInfo]::new('C:\').AvailableFreeSpace
    $finalE = [IO.DriveInfo]::new('E:\').AvailableFreeSpace
    $minimumC = [Math]::Min($minimumC, $finalC)
    $minimumE = [Math]::Min($minimumE, $finalE)
    if ($finalC -lt 40GB -or $finalE -lt 12GB) { Stop-NativeGuardian 'Final post-capture C/E floor failed.' }
} catch {
    $guardianErrors.Add(@{stage='final-sample';type=$_.Exception.GetType().FullName})
    Stop-NativeGuardian 'Final native floor sample unavailable.'
}
$guestStatus = $null
try {
    $resultGuard = Open-ColdGuard (Join-Path $ColdRootPath 'cold03\result.v1.json') $false
    $guards.Add($resultGuard)
    $guestStatus = ([IO.File]::ReadAllText($resultGuard.path, $utf8) | ConvertFrom-Json).status
} catch { $guardianErrors.Add(@{stage='guest-result';type=$_.Exception.GetType().FullName}) }
$inputDrift = @(foreach ($entry in $inputs.GetEnumerator()) {
    $held = ($guards | Where-Object { $_.path -ceq $entry.Value } | Select-Object -First 1)
    $now = Get-ColdHandleRecord $held.handle
    if ($now.file_index -cne $inputRecords[$entry.Key].file_index -or $now.size -ne $inputRecords[$entry.Key].size) { $entry.Key }
})
if ($inputDrift.Count) { $guardianErrors.Add(@{stage='held-input-identity';type=($inputDrift -join ',')}) }
$postTree = Get-ColdTreeViolations $ColdRootPath $allowedReparse
if ($postTree.violations.Count) { $guardianErrors.Add(@{stage='post-tree-security';type=($postTree.violations -join ',')}) }
$result = [ordered]@{session=$sessionId;amendment_sha256=$ColdAmendmentSha256;library_amendment_sha256='8d2b9d4dd1ca4b6cda5ce5a0a4807582af34bf46e1f9f02449d69054416f420e';
    runtime_manifest_sha256=$manifest.sha256;held_inputs=$inputRecords;original_returncode=$exitCode;forced_kill=$forcedKill;guest_status=$guestStatus;
    heartbeat_advances=$script:heartbeatSequence;publication_retries=$script:publicationRetries;guardian_errors=@($guardianErrors.ToArray());
    final_c_free=$finalC;final_e_free=$finalE;post_capture_returncode=$postRC;desktop_image_projection_unchanged=$same;
    stop_marker_written=$script:stopMarkerWritten;guardian_stopped=$script:stopped;minimum_observed_c_free=$minimumC;minimum_observed_e_free=$minimumE;
    post_tree_violations=@($postTree.violations);elapsed_seconds=$started.Elapsed.TotalSeconds;launcher_sha256=$launcherSha256;helper_sha256=$pins;
    local_image_deletions=0;finished_utc=[DateTimeOffset]::UtcNow.ToString('o')}
[IO.File]::WriteAllText((Join-Path $control 'original.result.v1.json'), (ConvertTo-Json $result -Depth 6), $utf8)
Write-Output $out
Write-Output (ConvertTo-Json $result -Compress -Depth 6)
foreach ($guard in $guards) { $guard.handle.Dispose() }
$moduleStream.Dispose()
if ($exitCode -ne 0 -or $forcedKill -or $postRC -ne 0 -or !$same -or $script:stopped -or $guardianErrors.Count -gt 0 -or $null -eq $finalC -or
    $null -eq $finalE -or $minimumC -lt 40GB -or $minimumE -lt 12GB -or $guestStatus -cne 'cold_projection_and_cleanup_pass_pending_log_review') { exit 1 }
exit 0
# D7 exact original body: END
}
# D7 preserved host predicates: END

function Get-ColdFixtureHash([string]$Path) {
    $file=Get-Item -LiteralPath $Path
    if ($file.PSIsContainer -or ($file.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $file.Length -gt 1048576) { throw 'Fixture source unsafe' }
    return [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([IO.File]::ReadAllBytes($Path))).ToLowerInvariant()
}
function Read-ColdDiagnosticFixture([string]$Path) {
    if (![IO.Path]::IsPathFullyQualified($Path)) { throw 'Fixture path not absolute' }
    $item=Get-Item -LiteralPath $Path
    if ($item.PSIsContainer -or $item.Name -cne 'fixture.json' -or $item.Length -gt 16384 -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Fixture manifest unsafe' }
    if ($item.Directory.Parent.FullName -cne $ColdDiagnosticBase) { throw 'Fixture root foreign' }
    $raw=[IO.File]::ReadAllBytes($item.FullName)
    $sha=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($raw)).ToLowerInvariant()
    $sealPath=[IO.Path]::ChangeExtension($Path,'sha256')
    $sealInfo=Get-Item -LiteralPath $sealPath
    if($sealInfo.PSIsContainer -or $sealInfo.Length -ne 64 -or ($sealInfo.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Fixture seal unsafe'}
    if ([IO.File]::ReadAllText($sealPath,$utf8) -cne $sha) { throw 'Fixture seal mismatch' }
    $value=$utf8.GetString($raw) | ConvertFrom-Json -AsHashtable
    $document=[Text.Json.JsonDocument]::Parse($utf8.GetString($raw))
    try {
        foreach($obj in @($document.RootElement,$document.RootElement.GetProperty('helper_sha256'))) {
            $seen=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
            foreach($property in $obj.EnumerateObject()) { if(!$seen.Add($property.Name)){throw 'Duplicate fixture key'} }
        }
    } finally {$document.Dispose()}
    $keys=@('kind','fixture','recovery_acceptance','case','nonce','case_root','helper_sha256','planning_commit','case_limit','cohort_limit')
    if (@($value.Keys).Count -ne $keys.Count -or @($value.Keys | Where-Object {$_ -cnotin $keys}).Count) { throw 'Fixture membership drift' }
    if ($value.kind -cne 'cold_diagnostics_fixture_v6' -or $value.fixture -isnot [bool] -or !$value.fixture -or $value.recovery_acceptance -isnot [bool] -or $value.recovery_acceptance) { throw 'Fixture scope drift' }
    $cases=@('primary_forced','primary_unknown','signal_send','command_receipt','guest_receipt','timer_disable','timer_restore','mask_restore','stream_close','cleanup','graceful','outer_zero_unknown','native_budget','operator_stop','launcher_raw_write','recorder_raw_write','launcher_receipt','recorder_receipt','identity_clock','diagnostic_capture','launcher_drain','recorder_drain','daemon_order','daemon_receipt')
    if ($value.case -cnotin $cases -or $value.nonce -cnotmatch '^[a-f0-9]{32}$' -or $value.case_root -cne $item.Directory.FullName -or $item.Directory.Name -cne ('case-'+$value.case+'-'+$value.nonce)) { throw 'Fixture identity drift' }
    if ($value.planning_commit -cne '4666e9e21741eda1f2f5b72d5a2de4bba6a7cd1a' -or $value.case_limit -ne 1048576 -or $value.cohort_limit -ne 16777216 -or ($value.case_limit -isnot [int] -and $value.case_limit -isnot [long]) -or ($value.cohort_limit -isnot [int] -and $value.cohort_limit -isnot [long])) { throw 'Fixture gates drift' }
    $names=@('cold_restore_docker_archive_v6.py','Run-RecordedColdOperation.v6.ps1','Run-ColdDockerRecovery.v6.ps1','Native-ColdGuardian.v6.ps1')
    if (@($value.helper_sha256.Keys).Count -ne $names.Count -or @($value.helper_sha256.Keys | Where-Object {$_ -cnotin $names}).Count) { throw 'Fixture helper membership drift' }
    foreach($name in $names) { if ((Get-ColdFixtureHash (Join-Path $ColdDiagnosticBase $name)) -cne $value.helper_sha256[$name]) { throw 'Fixture helper drift' } }
    foreach($name in @('guest.result.v6.json','launcher.result.v6.json','recorder.result.v6.json','0001-fixture-command.stdout','0001-fixture-command.stderr','0001-fixture-command.result.json')) { if(Test-Path -LiteralPath (Join-Path $value.case_root $name)){throw 'Fixture output already exists; no replay'} }
    for($directory=$item.Directory;$null -ne $directory;$directory=$directory.Parent) { if ($directory.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Fixture ancestor redirected' } }
    return $value
}
function New-ColdDiagnosticFrame([string]$Layer) {
    return [ordered]@{layer=$Layer;fixture=$true;recovery_acceptance=$false;primary=$null;secondary=[Collections.Generic.List[object]]::new();capture_unavailable=$false;original_child_returncode=$null;child_pid=$null;closure='not_started';forced_kill=$false;child_report=$null;child_report_available=$false;result_attempted=$false;result_available=$null;diagnostic_complete=$false}
}
function Set-ColdDiagnosticIdentity($Fixture,$Frame) {
    $Frame.kind='cold_diagnostics_fixture_report_v6';$Frame.case=$Fixture.case;$Frame.nonce=$Fixture.nonce
    $Frame.planning_commit=$Fixture.planning_commit;$Frame.helper_sha256=$Fixture.helper_sha256
}
function Add-ColdDiagnosticCause($Frame,[Exception]$Original,[string]$Phase,[bool]$Primary=$false) {
    try {
        $row=[ordered]@{operation=$Frame.layer;phase=$Phase;reason_code='diagnostic-external-failure';type=$Original.GetType().FullName;hresult=[int]$Original.HResult;exception_contents_retained=$false;synthetic_provider=$true}
        if ($utf8.GetByteCount((ConvertTo-Json $row -Compress)) -gt 16384) { throw 'Diagnostic cause cap' }
        if ($null -eq $Frame.primary) { $Frame.primary=$row } else { $Frame.secondary.Add($row) }
    } catch { $Frame.capture_unavailable=$true; if ($null -eq $Frame.primary) { $Frame.primary=@{operation=$Frame.layer;phase=$Phase;reason_code='diagnostic-capture-unavailable';exception_contents_retained=$false} } }
}
function Get-ColdDiagnosticBytes([string]$Root) {
    $sum=0L
    foreach($file in [IO.Directory]::EnumerateFiles($Root,'*',[IO.SearchOption]::AllDirectories)) { $sum += [IO.FileInfo]::new($file).Length }
    return $sum
}
function Write-ColdDiagnosticBytes($Fixture,[string]$Name,[byte[]]$Bytes) {
    if ($Name -cnotmatch '^[a-z0-9_.-]+$') { throw 'Fixture output name refused' }
    if ((Get-ColdDiagnosticBytes $Fixture.case_root)+$Bytes.Length -gt 1032192 -or (Get-ColdDiagnosticBytes $ColdDiagnosticBase)+$Bytes.Length -gt 16760832) { throw 'Fixture output cap' }
    $stream=[IO.FileStream]::new((Join-Path $Fixture.case_root $Name),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
    try { $stream.Write($Bytes,0,$Bytes.Length) } finally { $stream.Dispose() }
}
function Invoke-ColdDiagnosticCapture($Fixture,$Frame,[string]$Executable,[string[]]$Arguments,[scriptblock]$Monitor) {
    $p=[Diagnostics.Process]::new()
    $p.StartInfo.FileName=$Executable
    $p.StartInfo.UseShellExecute=$false
    $p.StartInfo.CreateNoWindow=$true
    $p.StartInfo.RedirectStandardOutput=$true
    $p.StartInfo.RedirectStandardError=$true
    $p.StartInfo.StandardOutputEncoding=$utf8
    $p.StartInfo.StandardErrorEncoding=$utf8
    foreach($argument in $Arguments) { $p.StartInfo.ArgumentList.Add($argument) }
    $out=[Text.StringBuilder]::new();$err=[Text.StringBuilder]::new()
    $buffers=@([char[]]::new(4096),[char[]]::new(4096))
    $reads=@($null,$null);$ended=@($false,$false)
    $clock=[Diagnostics.Stopwatch]::StartNew()
    $owned=$false
    try {
        if (!$p.Start()) { throw 'Fixture child not started' }
        $owned=$true
        $Frame.child_pid=$p.Id
        $Frame.child_start_utc_ticks=$p.StartTime.ToUniversalTime().Ticks
        $Frame.observer_pid=$PID
        $Frame.closure='unknown'
        $readers=@($p.StandardOutput,$p.StandardError);$writers=@($out,$err)
        $reads[0]=$readers[0].ReadAsync($buffers[0],0,4096)
        $reads[1]=$readers[1].ReadAsync($buffers[1],0,4096)
        while (!$p.HasExited -or !$ended[0] -or !$ended[1]) {
            if ($clock.Elapsed.TotalSeconds -ge 60) { $Frame.forced_kill=$true;throw 'Fixture watchdog' }
            if ($null -ne $Monitor -and !$p.HasExited) { & $Monitor }
            for($i=0;$i -lt 2;$i++) {
                if (!$ended[$i] -and $reads[$i].IsCompleted) {
                    if($i -eq 0 -and $Fixture.case -ceq ($Frame.layer+'_drain')){throw 'Controlled drain failure'}
                    $n=$reads[$i].GetAwaiter().GetResult()
                    if (!$n) { $ended[$i]=$true;continue }
                    [void]$writers[$i].Append($buffers[$i],0,$n)
                    if ($utf8.GetByteCount($writers[$i].ToString()) -gt 131072) { throw 'Fixture channel cap' }
                    $reads[$i]=$readers[$i].ReadAsync($buffers[$i],0,4096)
                }
            }
            [void]$p.WaitForExit(5)
        }
        $Frame.original_child_returncode=$p.ExitCode
        $Frame.closure='closed'
    } catch {
        $original=$_
        Add-ColdDiagnosticCause $Frame $original.Exception 'capture' $true
        $hasExited=$false
        if($owned){try{$hasExited=$p.HasExited}catch{Add-ColdDiagnosticCause $Frame $_.Exception 'closure-observation'}}
        if ($owned -and !$hasExited) {
            $Frame.forced_kill=$true
            try { $p.Kill($true);[void]$p.WaitForExit(10000) } catch { Add-ColdDiagnosticCause $Frame $_.Exception 'owned-child-teardown' }
        }
        if($owned){
            try{
                if($p.HasExited){$Frame.original_child_returncode=$p.ExitCode;$Frame.closure='closed'}
            }catch{Add-ColdDiagnosticCause $Frame $_.Exception 'final-closure-observation';$Frame.closure='unknown'}
        }
    } finally {
        foreach($channel in @('stdout','stderr')) {
            try {
                if ($Fixture.case -ceq ($Frame.layer+'_raw_write')) { throw 'Controlled raw-write failure' }
                $text=if($channel -ceq 'stdout'){$out.ToString()}else{$err.ToString()}
                Write-ColdDiagnosticBytes $Fixture ($Frame.layer+'.original.'+$channel) ($utf8.GetBytes($text))
            } catch { Add-ColdDiagnosticCause $Frame $_.Exception ($channel+'-write') }
        }
        if ($Frame.child_pid) { foreach($stream in @($p.StandardOutput,$p.StandardError)) { try {$stream.Dispose()} catch {Add-ColdDiagnosticCause $Frame $_.Exception 'stream-close'} } }
        try {$p.Dispose()} catch {Add-ColdDiagnosticCause $Frame $_.Exception 'process-close'}
    }
    return $Frame
}
function Complete-ColdDiagnosticLayer($Fixture,$Frame,[string]$ChildResult) {
    try {
        $childPath=Join-Path $Fixture.case_root $ChildResult
        $childInfo=Get-Item -LiteralPath $childPath
        if ($childInfo.Length -gt 524288 -or ($childInfo.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Fixture child report unsafe' }
        $Frame.child_report=([IO.File]::ReadAllText($childPath,$utf8) | ConvertFrom-Json -AsHashtable)
        $child=$Frame.child_report
        $expectedLayer=if($Frame.layer -ceq 'launcher'){'guest'}else{'launcher'}
        if($child.kind -cne 'cold_diagnostics_fixture_report_v6' -or $child.layer -cne $expectedLayer -or $child.fixture -ne $true -or $child.recovery_acceptance -ne $false -or $child.case -cne $Fixture.case -or $child.nonce -cne $Fixture.nonce -or $child.planning_commit -cne $Fixture.planning_commit){throw 'Foreign child report'}
        foreach($name in $Fixture.helper_sha256.Keys){if($child.helper_sha256[$name] -cne $Fixture.helper_sha256[$name]){throw 'Foreign child source report'}}
        $Frame.child_report_available=$true
    } catch { Add-ColdDiagnosticCause $Frame $_.Exception 'child-result-read' }
    $nativeFail=$false
    if ($Frame.layer -ceq 'launcher') {
        $Frame.native_causes=@($script:diagnosticCauses.ToArray())
        $Frame.native_capture_failures=@($script:nativeDiagnosticCaptureFailures.ToArray())
        $Frame.native_capture_unavailable=[bool]$script:nativeDiagnosticCaptureUnavailable
        $Frame.native_pending_cause=$script:pendingNativeDiagnosticCause
        $Frame.native_stopped=[bool]$script:stopped
        $Frame.native_guardian_errors=@($guardianErrors.ToArray())
        $nativeFail=$Frame.native_causes.Count -or $Frame.native_capture_failures.Count -or $Frame.native_capture_unavailable -or $Frame.native_stopped
    }
    $Frame.diagnostic_complete=($Frame.original_child_returncode -ceq 0 -and $Frame.closure -ceq 'closed' -and !$Frame.forced_kill -and $null -eq $Frame.primary -and !$Frame.secondary.Count -and !$Frame.capture_unavailable -and $Frame.child_report_available -and $Frame.child_report.diagnostic_complete -and !$nativeFail)
    $Frame.result_attempted=$true
    try {
        if ($Fixture.case -ceq ($Frame.layer+'_receipt')) { throw 'Controlled layer receipt failure' }
        Write-ColdDiagnosticBytes $Fixture ($Frame.layer+'.result.v6.json') ($utf8.GetBytes((ConvertTo-Json $Frame -Depth 16 -Compress)))
        $Frame.result_available=$true
    } catch { $Frame.result_available=$false;$Frame.diagnostic_complete=$false;Add-ColdDiagnosticCause $Frame $_.Exception 'layer-result-write' }
    Write-Output (ConvertTo-Json $Frame -Depth 16 -Compress)
    return [bool]$Frame.diagnostic_complete
}
function Set-ColdNativeFixture($Fixture) {
    $script:NativeDiagnosticFixture=$true
    $script:heartbeatSequence=0L;$script:publicationRetries=0L;$script:stopped=$false;$script:stopMarkerWritten=$false
    $script:minimumC=$null;$script:minimumE=$null
    $script:diagnosticCauses=[Collections.Generic.List[object]]::new()
    $script:nativeDiagnosticCaptureFailures=[Collections.Generic.List[object]]::new()
    $script:nativeDiagnosticCaptureUnavailable=$false;$script:pendingNativeDiagnosticCause=$null
    $script:fixtureTick=0L
    $script:fixtureNativeCase=$Fixture.case
    $script:fixtureNativeRoot=$Fixture.case_root
    $script:NativeDiagnosticEffects=@{
        tick={param($phase) $script:fixtureTick += [long]([Diagnostics.Stopwatch]::Frequency/100);if($script:fixtureNativeCase -ceq 'native_budget' -and $phase -ceq 'post-write'){$script:fixtureTick += [Diagnostics.Stopwatch]::Frequency};return $script:fixtureTick}
        freeC={param($phase) return 40GB+1L};freeE={param($phase) return 12GB+1L}
        exists={param($phase,$path) return (Test-Path -LiteralPath $path)}
        utc={param($phase) return 'fixture-labelled-utc'}
        write={param($phase,$path,$payload) [IO.File]::WriteAllText($path,$payload,$utf8)}
        move={param($phase,$from,$to) [IO.File]::Move($from,$to,$true)}
        append={param($phase,$path,$payload) [IO.File]::AppendAllText($path,$payload,$utf8)}
        sleep={param($phase,$milliseconds) return}
    }
}
function Invoke-ColdDiagnosticLauncher([string]$ManifestPath) {
    $fixture=Read-ColdDiagnosticFixture $ManifestPath
    $frame=New-ColdDiagnosticFrame 'launcher'
    Set-ColdDiagnosticIdentity $fixture $frame
    $control=$fixture.case_root;$sessionId='fixture-'+$fixture.nonce
    $guardianErrors=[Collections.Generic.List[object]]::new()
    . (Join-Path $ColdDiagnosticBase 'Native-ColdGuardian.v6.ps1')
    Set-ColdNativeFixture $fixture
    $monitor={
        if (!$script:stopped) {
            try { Publish-NativeHeartbeat (40GB+1L) (12GB+1L) } catch { Add-ColdDiagnosticCause $frame $_.Exception 'sample-or-publish' $true;Stop-NativeGuardian 'Fixture native publication failed.' }
        }
        if ($fixture.case -ceq 'operator_stop' -and !$script:stopped) { Stop-NativeGuardian 'Fixture operator stop.' }
    }
    $python=(Get-Command python -CommandType Application | Select-Object -First 1).Source
    [void](Invoke-ColdDiagnosticCapture $fixture $frame $python @('-I','-B',(Join-Path $ColdDiagnosticBase 'cold_restore_docker_archive_v6.py'),'--diagnostics-fixture',$ManifestPath) $monitor)
    $closed=@(Complete-ColdDiagnosticLayer $fixture $frame 'guest.result.v6.json')
    foreach($value in $closed) { if($value -is [string]){Write-Output $value} }
    return [bool]$closed[-1]
}
if ($MyInvocation.InvocationName -cne '.') {
    try {
        if ([string]::IsNullOrEmpty($DiagnosticFixture) -or $args.Count) { throw 'D7 fixture-only launcher dispatch refused' }
        $complete=@(Invoke-ColdDiagnosticLauncher $DiagnosticFixture)
        foreach($value in $complete){if($value -is [string]){Write-Output $value}}
        if($complete[-1]){exit 0}else{exit 1}
    } catch { Write-Output (ConvertTo-Json @{fixture=$true;recovery_acceptance=$false;entrypoint_failure_type=$_.Exception.GetType().FullName} -Compress);exit 1 }
}
