"""Authored D7 composed fixture checks. No live cold/storage/production dispatch."""
import ast
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import unittest
import uuid

HERE=Path(__file__).resolve().parent
CASE_LIMIT=1024*1024
COHORT_LIMIT=16*CASE_LIMIT
HELPERS=('cold_restore_docker_archive_v6.py','Run-RecordedColdOperation.v6.ps1',
         'Run-ColdDockerRecovery.v6.ps1','Native-ColdGuardian.v6.ps1')
PLANNING='4666e9e21741eda1f2f5b72d5a2de4bba6a7cd1a'
ORIGINAL=Path('E:/STUDY/VAST/tmp/host-cache-cleanup-20261012')
ORIGINAL_PINS={'cold_restore_docker_archive_v5.py':'6a63c732ae26f3dc24187779a1434021a932e00725fdc31edab05d051dd9993f',
 'Run-ColdDockerRecovery.v5.ps1':'54535e950c0782129172e1822058b2d4a64ff1cb7d55dab36510c1fc6b20cec0',
 'Run-RecordedColdOperation.v3.ps1':'de2d4bf496b59e9e2b5f0e7bbced0a057da752c8b072b1f4e4fc6165bc1195fc',
 'Native-ColdGuardian.v1.ps1':'e2cbb87a20667aac6039993c70395c600dc861992b85f91260daee9f30a2314a',
 'native_heartbeat_lease_v1.py':'8aae687de0b919f90c8a12f34bc7798920bc0c41250049aef3595225a4bd7fb4'}
ORIGINAL_PINS.update({'ColdRootSecurity.v2.ps1':'69ca07ee87fa93f55f510f46335856acd8b52f58700e8dfdf5f0f0c17cf204a6',
 'run_isolated_cold_restore_v5.sh':'7dcfe31bb79f01aec5276ca9d471de338597fd1b4d8225893a24b7927b6559b0',
 'Capture-DockerCleanupAudit.v3.ps1':'f46125edb0771fc30b5cdabc82a440b641e01e9fd0bb16185bdbeb5ff3d55018'})
OBSERVATIONS=[]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def directory_bytes(root):
    total=0
    for path in root.rglob('*'):
        if path.is_symlink():
            raise ValueError('redirected diagnostic subtree')
        if path.is_file():
            total+=path.stat().st_size
    return total

def read_json(path):
    raw=path.read_bytes()
    if len(raw)>CASE_LIMIT:
        raise ValueError('report cap')
    return json.loads(raw)

def make_case(case,mutation=None):
    if directory_bytes(HERE)>COHORT_LIMIT-CASE_LIMIT:
        raise ValueError('cohort cap reserve')
    nonce=uuid.uuid4().hex
    root=HERE/('case-'+case+'-'+nonce)
    root.mkdir(mode=0o700)
    manifest={'kind':'cold_diagnostics_fixture_v6','fixture':True,'recovery_acceptance':False,
      'case':case,'nonce':nonce,'case_root':str(root),'helper_sha256':{name:sha(HERE/name) for name in HELPERS},
      'planning_commit':PLANNING,'case_limit':CASE_LIMIT,'cohort_limit':COHORT_LIMIT}
    if mutation:
        mutation(manifest)
    payload=json.dumps(manifest,sort_keys=True,separators=(',',':')).encode()
    (root/'fixture.json').write_bytes(payload)
    (root/'fixture.sha256').write_text(hashlib.sha256(payload).hexdigest(),encoding='ascii')
    return root

def invoke(case,mutation=None):
    root=make_case(case,mutation)
    executable=shutil.which('pwsh')
    if not executable:
        raise RuntimeError('PowerShell7 fixture interpreter unavailable')
    argv=[executable,'-NoLogo','-NoProfile','-NonInteractive','-File',str(HERE/'Run-RecordedColdOperation.v6.ps1'),'-DiagnosticFixture',str(root/'fixture.json')]
    started=time.monotonic()
    process=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    try:
        stdout,stderr=process.communicate(timeout=60)
    except subprocess.TimeoutExpired:
        # Only the driver's exact owned child is touched; its incomplete evidence remains failed.
        process.kill()
        stdout,stderr=process.communicate(timeout=10)
        raise RuntimeError('composed fixture timed out')
    if len(stdout)+len(stderr)>CASE_LIMIT//2:
        raise ValueError('outer capture cap')
    (root/'driver.original.stdout').write_bytes(stdout)
    (root/'driver.original.stderr').write_bytes(stderr)
    observed={'case':case,'root':str(root),'nonce':root.name.rsplit('-',1)[-1],
      'original_driver_child_returncode':process.returncode,'elapsed_seconds':time.monotonic()-started,
      'stdout_sha256':hashlib.sha256(stdout).hexdigest(),'stderr_sha256':hashlib.sha256(stderr).hexdigest(),
      'fixture':True,'recovery_acceptance':False,'source_sha256':{name:sha(HERE/name) for name in HELPERS}}
    (root/'driver.observation.json').write_text(json.dumps(observed,indent=2)+'\n')
    if directory_bytes(root)>CASE_LIMIT or directory_bytes(HERE)>COHORT_LIMIT:
        raise ValueError('whole diagnostic output cap')
    OBSERVATIONS.append(observed)
    return root,process.returncode

def guest(root):
    return read_json(root/'guest.result.v6.json')

def command(root):
    return guest(root)['command_reports'][0]

class ComposedDiagnostics(unittest.TestCase):
    def check_failure(self,case):
        root,rc=invoke(case)
        self.assertEqual(rc,1)
        self.assertFalse(read_json(root/'recorder.result.v6.json')['diagnostic_complete'])
        self.assertFalse(read_json(root/'recorder.result.v6.json')['recovery_acceptance'])
        return root
    def test_both_waits_preserve_primary_and_attempted_result(self):
        root=self.check_failure('primary_unknown')
        row=command(root)
        self.assertEqual(row['primary']['reason_code'],'fixture_initiating_failure')
        self.assertEqual([x['timeout_seconds'] for x in row['termination']['waits']],[30,30])
        self.assertEqual([x['phase'] for x in row['secondary']],['sigterm_wait','sigkill_wait'])
        self.assertEqual(row['closure'],'unknown')
        self.assertIsNone(row['original_returncode'])
        self.assertTrue(row['result_attempted'])
        self.assertTrue((root/'0001-fixture-command.result.json').is_file())
    def test_forced_closed_is_not_graceful(self):
        root=self.check_failure('primary_forced');row=command(root)
        self.assertTrue(row['forced_kill']);self.assertEqual(row['original_returncode'],-9)
        self.assertFalse(guest(root)['all_children_proved_closed'])
    def test_signal_send_failure_is_separate(self):
        root=self.check_failure('signal_send');row=command(root)
        self.assertFalse(row['termination']['sigterm_sent'])
        self.assertIn('sigterm_send',[x['phase'] for x in row['secondary']])
    def test_identity_clock_failure_retains_ownership_and_closes(self):
        root=self.check_failure('identity_clock');row=command(root)
        self.assertEqual(row['child']['kind'],'identity_unavailable')
        self.assertIn('child_identity_observation',[x['phase'] for x in row['secondary']])
        self.assertEqual(row['closure'],'closed')
        self.assertTrue(row['termination']['sigterm_attempted'])
        self.assertTrue(row['result_attempted'])
        self.assertTrue((root/'0001-fixture-command.result.json').exists())
    def test_diagnostic_capture_failure_does_not_hide_primary_type(self):
        root=self.check_failure('diagnostic_capture');row=command(root)
        self.assertEqual(row['primary']['exception_types'],['_FixtureUnavailableDiagnostic'])
        self.assertTrue(row['primary']['capture_failure']);self.assertTrue(row['capture_unavailable'])
        self.assertTrue(row['result_attempted']);self.assertTrue((root/'0001-fixture-command.result.json').exists())
    def test_outstanding_daemon_cleanup_preserves_reverse_order(self):
        root,rc=invoke('daemon_order');self.assertEqual(rc,0)
        row=guest(root)
        self.assertEqual(row['outstanding_finalization_order'],['dockerd','containerd'])
        self.assertEqual([x['original_returncode'] for x in row['children']],[-15,-15])
        self.assertTrue(row['diagnostic_complete']);self.assertFalse(row['recovery_acceptance'])
        self.assertTrue(all(x['result_available'] for x in row['children']))
    def test_daemon_receipt_failure_blocks_all_child_completeness(self):
        root=self.check_failure('daemon_receipt');row=guest(root)
        self.assertTrue(row['all_children_proved_closed'])
        self.assertFalse(row['diagnostic_complete'])
        daemon=next(x for x in row['children'] if x['operation']=='dockerd')
        self.assertFalse(daemon['result_available']);self.assertTrue(daemon['result_attempted'])
        self.assertFalse((root/'dockerd.closed.json').exists())
    def test_partial_timer_disable_restores_known_mask(self):
        row=command(self.check_failure('timer_disable'))
        self.assertEqual(row['signal_restoration']['timer_restore'],'unavailable')
        self.assertEqual(row['signal_restoration']['mask_restore'],'returned')
        self.assertIn('timer_disable',[x['phase'] for x in row['secondary']])
    def test_timer_restore_does_not_skip_mask_restore(self):
        row=command(self.check_failure('timer_restore'))
        self.assertEqual(row['signal_restoration']['timer_restore'],'failed')
        self.assertEqual(row['signal_restoration']['mask_restore'],'returned')
    def test_mask_restore_is_preserved(self):
        row=command(self.check_failure('mask_restore'))
        self.assertEqual(row['signal_restoration']['mask_restore'],'failed')
    def test_both_stream_closes_are_attempted(self):
        row=command(self.check_failure('stream_close'))
        self.assertEqual(row['stream_closure'],{'stdout':'failed','stderr':'failed'})
        self.assertTrue({'stdout_close','stderr_close'}<={x['phase'] for x in row['secondary']})
    def test_cleanup_is_secondary_to_primary(self):
        row=guest(self.check_failure('cleanup'))
        self.assertEqual(row['primary']['reason_code'],'fixture_initiating_failure')
        self.assertIn('cleanup',[x['phase'] for x in row['secondary']])
    def test_command_receipt_failure_reaches_parent(self):
        root=self.check_failure('command_receipt');row=command(root)
        self.assertTrue(row['result_attempted']);self.assertFalse(row['result_available'])
        self.assertFalse((root/'0001-fixture-command.result.json').exists())
    def test_guest_receipt_failure_is_not_invented(self):
        root=self.check_failure('guest_receipt')
        self.assertFalse((root/'guest.result.v6.json').exists())
        self.assertFalse(read_json(root/'launcher.result.v6.json')['child_report_available'])
        lines=(root/'launcher.original.stdout').read_text().splitlines()
        self.assertTrue(any(json.loads(line).get('result_failure') for line in lines if line.startswith('{')))
    def test_outer_zero_cannot_prove_inner_closure(self):
        root=self.check_failure('outer_zero_unknown')
        launch=read_json(root/'launcher.result.v6.json')
        self.assertEqual(launch['original_child_returncode'],0)
        self.assertFalse(launch['diagnostic_complete'])
        self.assertFalse(guest(root)['all_children_proved_closed'])
    def test_graceful_actual_chain_remains_nonauthorizing(self):
        root,rc=invoke('graceful');self.assertEqual(rc,0)
        row=command(root)
        self.assertEqual(row['child']['kind'],'actual_process')
        self.assertGreater(row['child']['pid'],0)
        self.assertEqual(row['original_returncode'],0)
        self.assertEqual((root/'0001-fixture-command.stdout').read_text().strip(),'tiny-owned-fixture-child')
        for name in ('guest.result.v6.json','launcher.result.v6.json','recorder.result.v6.json'):
            value=read_json(root/name);self.assertTrue(value['diagnostic_complete']);self.assertFalse(value['recovery_acceptance'])
    def test_late_recorder_write_keeps_known_launcher_zero(self):
        root=self.check_failure('recorder_raw_write')
        row=read_json(root/'recorder.result.v6.json')
        self.assertEqual(row['original_child_returncode'],0)
        self.assertEqual(row['primary']['phase'],'stdout-write')
        self.assertIn('stderr-write',[x['phase'] for x in row['secondary']])
    def test_late_launcher_write_keeps_known_guest_zero(self):
        root=self.check_failure('launcher_raw_write')
        self.assertEqual(read_json(root/'launcher.result.v6.json')['original_child_returncode'],0)
    def test_outer_drain_failure_remains_separate(self):
        for case,layer in (('launcher_drain','launcher'),('recorder_drain','recorder')):
            with self.subTest(case=case):
                root=self.check_failure(case);row=read_json(root/(layer+'.result.v6.json'))
                self.assertEqual(row['primary']['phase'],'capture')
                self.assertTrue(row['result_attempted']);self.assertFalse(row['diagnostic_complete'])
    def test_launcher_receipt_failure_reaches_recorder(self):
        root=self.check_failure('launcher_receipt')
        self.assertFalse((root/'launcher.result.v6.json').exists())
        self.assertFalse(read_json(root/'recorder.result.v6.json')['child_report_available'])
    def test_recorder_receipt_failure_has_bounded_emergency_capture(self):
        root,rc=invoke('recorder_receipt');self.assertEqual(rc,1)
        self.assertFalse((root/'recorder.result.v6.json').exists())
        final=json.loads((root/'driver.original.stdout').read_text().splitlines()[-1])
        self.assertEqual(final['original_child_returncode'],0)
        self.assertFalse(final['result_available']);self.assertFalse(final['diagnostic_complete'])
    def test_native_budget_and_operator_stop_propagate(self):
        for case in ('native_budget','operator_stop'):
            with self.subTest(case=case):
                root=self.check_failure(case);launch=read_json(root/'launcher.result.v6.json')
                self.assertTrue(launch['native_stopped'])
                self.assertEqual(command(root)['primary']['reason_code'],'cold_operator_stop_latched')
                if case=='native_budget':
                    self.assertTrue(launch['native_causes'])
                    self.assertEqual(launch['native_causes'][0]['phase'],'post-write')
                self.assertIsInstance(launch['native_causes'],list)
                self.assertIsInstance(launch['native_capture_failures'],list)
                self.assertIsInstance(launch['native_guardian_errors'],list)
    def test_foreign_extra_command_or_live_scope_is_refused(self):
        for mutation in (lambda x:x.update(command='/usr/sbin/mkfs.ext4'),lambda x:x.update(fixture=False),lambda x:x.update(case_limit=1),lambda x:x.update(case_limit=float(CASE_LIMIT))):
            root,rc=invoke('graceful',mutation)
            self.assertEqual(rc,1)
            self.assertFalse((root/'guest.result.v6.json').exists())
            self.assertFalse((root/'0001-fixture-command.stdout').exists())
    def test_guest_missing_or_live_mode_is_refused(self):
        for mode in ([],['admission'],['--live'],['--diagnostics-fixture']):
            result=subprocess.run([sys.executable,'-I','-B',str(HERE/HELPERS[0]),*mode],capture_output=True,timeout=5)
            self.assertNotEqual(result.returncode,0)
    def test_pure_gate_bodies_and_originals_preserved(self):
        old=ast.parse((ORIGINAL/'cold_restore_docker_archive_v5.py').read_bytes())
        new=ast.parse((HERE/HELPERS[0]).read_bytes())
        names={'projection_differences','validate_manifest','validate_versions','validate_apt_quiet','guard','check_runtime_state','main'}
        before={n.name:ast.dump(n,include_attributes=False) for n in old.body if isinstance(n,ast.FunctionDef) and n.name in names}
        after={n.name:ast.dump(n,include_attributes=False) for n in new.body if isinstance(n,ast.FunctionDef) and n.name in names}
        self.assertEqual(before,after)
        for name,pin in ORIGINAL_PINS.items():
            self.assertEqual(sha(ORIGINAL/name),pin)
            protected=Path('E:/VAST-cold03-a3990e2870c940149785831b845aea91/helpers-cold03')/name
            if name!='Run-RecordedColdOperation.v3.ps1':
                self.assertEqual(sha(protected),pin)
    def test_original_outer_host_predicates_remain_unchanged_and_withheld(self):
        for old,new in (('Run-ColdDockerRecovery.v5.ps1','Run-ColdDockerRecovery.v6.ps1'),('Run-RecordedColdOperation.v3.ps1','Run-RecordedColdOperation.v6.ps1')):
            original=(ORIGINAL/old).read_text()
            derivative=(HERE/new).read_text()
            preserved=derivative.split('# D7 exact original body: BEGIN\n',1)[1].split('# D7 exact original body: END\n',1)[0]
            if new.startswith('Run-Recorded'):
                original=original.split("param([Parameter(Mandatory=$true)][ValidateSet('Retire','Cold')][string]$Operation)\n",1)[1]
            self.assertEqual(preserved,original)
            self.assertIn("throw 'D7 grants fixture diagnostics only; preserved host route is unconditionally withheld'",derivative)
    def test_sealed_fixture_no_replay_and_source_join_refusal(self):
        root,rc=invoke('graceful');self.assertEqual(rc,0)
        argv=[shutil.which('pwsh'),'-NoLogo','-NoProfile','-NonInteractive','-File',str(HERE/HELPERS[1]),'-DiagnosticFixture',str(root/'fixture.json')]
        before={x.name:sha(x) for x in root.iterdir() if x.is_file()}
        rerun=subprocess.run(argv,capture_output=True,timeout=5)
        self.assertEqual(rerun.returncode,1)
        self.assertEqual(before,{x.name:sha(x) for x in root.iterdir() if x.is_file()})
        foreign,rc=invoke('graceful',lambda x:x['helper_sha256'].update({HELPERS[0]:'0'*64}))
        self.assertEqual(rc,1);self.assertFalse((foreign/'guest.result.v6.json').exists())
    def test_actual_shared_writer_refuses_whole_case_cap_before_creation(self):
        root=make_case('graceful')
        (root/'bounded-fixture-filler.bin').write_bytes(b'0'*600000)
        process=subprocess.run([shutil.which('pwsh'),'-NoLogo','-NoProfile','-NonInteractive','-File',str(HERE/'Test-SealedDiagnosticWriteCap.v6.ps1'),'-Manifest',str(root/'fixture.json')],capture_output=True,timeout=5)
        self.assertEqual(process.returncode,0)
        self.assertTrue(json.loads(process.stdout)['point_of_use_cap_refused_before_write'])
        self.assertFalse((root/'cap-target.bin').exists())
        self.assertLess(directory_bytes(root),CASE_LIMIT)
        (root/'cap-check.original.stdout').write_bytes(process.stdout)
        (root/'cap-check.original.stderr').write_bytes(process.stderr)
    def test_retained_causes_have_bounded_sanitized_metadata(self):
        def visit(value):
            if isinstance(value,dict):
                if 'reason_code' in value:
                    self.assertLessEqual(len(str(value['reason_code']).encode()),1024)
                    self.assertLessEqual(len(json.dumps(value).encode()),16384)
                    self.assertFalse(value.get('exception_contents_retained',False))
                    self.assertNotIn('message',value)
                for item in value.values():visit(item)
            elif isinstance(value,list):
                for item in value:visit(item)
        self.assertTrue(OBSERVATIONS)
        for observation in OBSERVATIONS:
            root=Path(observation['root'])
            for name in ('guest.result.v6.json','launcher.result.v6.json','recorder.result.v6.json'):
                if (root/name).is_file():visit(read_json(root/name))

def main():
    if sys.argv[1:]!=['--fixture-only']:
        print('Refused: only --fixture-only is available; no live dispatch.',file=sys.stderr)
        return 2
    report_root=HERE/('composed-authored-run-'+uuid.uuid4().hex)
    report_root.mkdir(mode=0o700)
    source_before={name:sha(HERE/name) for name in HELPERS}
    snapshot=report_root/'source-snapshot'
    snapshot.mkdir()
    subjects={}
    for name in (*HELPERS,'author_guest_v6.py','guest_reporting_v6.fragment.py.txt','author_preserved_outer_predicates.py','Test-SealedDiagnosticWriteCap.v6.ps1','fidelity.v1.md',Path(__file__).name):
        data=(HERE/name).read_bytes()
        subjects[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
        if directory_bytes(HERE)+len(data)>COHORT_LIMIT:
            raise ValueError('source snapshot cohort cap')
        (snapshot/name).write_bytes(data)
    (snapshot/'manifest.v1.json').write_text(json.dumps({'fixture':True,'recovery_acceptance':False,'subjects':subjects},indent=2)+'\n')
    raw=io.StringIO()
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(ComposedDiagnostics)
    started=time.monotonic()
    result=unittest.TextTestRunner(stream=raw,verbosity=2).run(suite)
    summary={'kind':'D7_composed_fixture_authored_results_v6','author':'audit_integration','planning_commit':PLANNING,
      'approval_comment':6180355014,'fixture':True,'recovery_acceptance':False,'tests_run':result.testsRun,
      'failures':len(result.failures),'errors':len(result.errors),'elapsed_seconds':time.monotonic()-started,
      'source_before':source_before,'source_after':{name:sha(HERE/name) for name in HELPERS},
      'original_preservation':{name:sha(ORIGINAL/name)==pin for name,pin in ORIGINAL_PINS.items()},
      'observations':OBSERVATIONS,'cohort_bytes':directory_bytes(HERE),
      'scope':'Authored actual recorder/launcher/guest composition; synthetic effects and labelled inner timeout handles; no live storage/restore/backing/commands.'}
    logs=raw.getvalue().encode()
    payload=(json.dumps(summary,indent=2)+'\n').encode()
    if len(logs)+len(payload)>CASE_LIMIT or directory_bytes(HERE)+len(logs)+len(payload)>COHORT_LIMIT:
        raise ValueError('final fixture output cap')
    (report_root/'unittest.original.stderr').write_bytes(logs)
    (report_root/'result.original.v6.json').write_bytes(payload)
    sys.stderr.write(logs.decode())
    print(json.dumps({'report_root':str(report_root),'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'recovery_acceptance':False}))
    if summary['source_before']!=summary['source_after'] or not all(summary['original_preservation'].values()):
        return 1
    return 0 if result.wasSuccessful() else 1

if __name__=='__main__':
    raise SystemExit(main())
