"""Preserve bounded authored source associated with the retained failed fixture run."""
import hashlib
import json
from pathlib import Path

root=Path(__file__).resolve().parent
report=root/'composed-authored-run-b4ec9ef804b8451eb4420e2a46945eba'
value=json.loads((report/'result.original.v6.json').read_bytes())
out=root/'composed-first-run-source-snapshot-01'
out.mkdir(exist_ok=False)
subjects={}
for name in (*value['source_before'], 'author_guest_v6.py', 'guest_reporting_v6.fragment.py.txt', 'test_cold_recovery_diagnostics_v6.py'):
    raw=(root/name).read_bytes()
    sha=hashlib.sha256(raw).hexdigest()
    if name in value['source_before']:
        assert sha==value['source_before'][name]==value['source_after'][name]
    (out/name).write_bytes(raw)
    subjects[name]={'bytes':len(raw),'sha256':sha}
(out/'manifest.v1.json').write_text(json.dumps({'author':'audit_integration','fixture':True,'recovery_acceptance':False,'failed_report':str(report),'subjects':subjects},indent=2)+'\n')
print(json.dumps({'snapshot':str(out),'subjects':subjects}))
