param(
    [Parameter(Mandatory=$true)][ValidateSet('RedAdmission','GreenNative')][string]$Suite,
    [Parameter(Mandatory=$true)][string]$Source,
    [Parameter(Mandatory=$true)][string]$SourceSha256,
    [Parameter(Mandatory=$true)][string]$OutputRoot
)
$ErrorActionPreference = 'Stop'
$utf8 = [Text.UTF8Encoding]::new($false)
$harnessHash=(Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash.ToLowerInvariant()
if ((Get-FileHash -LiteralPath $Source -Algorithm SHA256).Hash.ToLowerInvariant() -cne $SourceSha256) { throw 'Pinned native fixture source drift' }
if ($Suite -ceq 'RedAdmission' -and $SourceSha256 -cne 'e2cbb87a20667aac6039993c70395c600dc861992b85f91260daee9f30a2314a') { throw 'RED must use original native helper' }
if (Test-Path -LiteralPath $OutputRoot) { throw 'Fixture output namespace occupied' }
[void][IO.Directory]::CreateDirectory($OutputRoot)
. $Source
# Serialization is an external effect. Only the typed-cause serialization is
# failed in its finite fixture case; report/closure decisions stay unchanged.
function ConvertTo-Json {
    param([object]$InputObject,[int]$Depth=2,[switch]$Compress)
    if ($script:NativeDiagnosticFault -ceq 'cause-serialization-failure' -and $Depth -eq 8 -and $Compress) { throw [InvalidOperationException]::new('fixture cause serialization failure') }
    Microsoft.PowerShell.Utility\ConvertTo-Json -InputObject $InputObject -Depth $Depth -Compress:$Compress
}
function Assert-Fixture([bool]$Condition,[string]$Reason) { if (!$Condition) { throw $Reason } }
function Write-FixtureRecord([string]$Path,[object]$Record) {
    $bytes=$utf8.GetBytes((ConvertTo-Json $Record -Depth 16))
    $caseUsed=[long]0
    foreach($file in Get-ChildItem -LiteralPath ([IO.Path]::GetDirectoryName($Path)) -File) { $caseUsed+=$file.Length }
    if ($bytes.Length+$caseUsed -gt 1MB) { throw 'Fixture case exceeds 1MiB' }
    $cohortUsed=[long]0
    foreach($file in Get-ChildItem -LiteralPath $PSScriptRoot -File -Recurse) { $cohortUsed+=$file.Length }
    # Only this cap-refusal case supplies a finite synthetic usage observation.
    # All ordinary writes use the actual retained cohort, including prior REDs.
    if ($script:fixtureCohortFull) { $cohortUsed=[long]16MB }
    if ($bytes.Length+$cohortUsed -gt 16MB) { throw 'Fixture cohort exceeds 16MiB' }
    $stream=[IO.File]::Open($Path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
    try { $stream.Write($bytes) } finally { $stream.Dispose() }
}
$cases = if ($Suite -ceq 'RedAdmission') { @('admission-floor') } else {
    @('admission-floor','sample-failure','write-failure','flush-labelled-failure','move-failure','post-write-budget','post-move-budget','operator-stop','graceful','sanitized-cause','cause-record-failure','cause-serialization-failure','stop-record-failure','provider-crossover','provider-missing','cause-count-bound','retry-code5','retry-code32','retry-code33','retry-foreign-facility','retry-unsupported-code','retry-expired','retry-stopped','case-byte-bound','cohort-byte-bound')
}
$rows=[Collections.Generic.List[object]]::new()
$failed=$false
foreach ($case in $cases) {
    $control=Join-Path $OutputRoot $case
    [void][IO.Directory]::CreateDirectory($control)
    $sessionId='diagnostics-fixture-v6-'+$case
    $script:heartbeatSequence=[long]0
    $script:publicationRetries=[long]0
    $script:stopped=$false
    $script:stopMarkerWritten=$false
    $script:minimumC=$null
    $script:minimumE=$null
    $script:diagnosticCauses=[Collections.Generic.List[object]]::new()
    $script:nativeDiagnosticCaptureFailures=[Collections.Generic.List[object]]::new()
    $script:nativeDiagnosticCaptureUnavailable=$false
    $script:pendingNativeDiagnosticCause=$null
    $guardianErrors=[Collections.Generic.List[object]]::new()
    $script:NativeDiagnosticFixture=$true
    $script:NativeDiagnosticFault=$case
    $script:fixtureMoveAttempts=0
    $script:fixtureCohortFull=$false
    $script:NativeDiagnosticEffects=@{
        tick={ param($phase)
            if (($script:NativeDiagnosticFault -ceq 'post-write-budget' -and $phase -ceq 'post-write') -or
                ($script:NativeDiagnosticFault -ceq 'post-move-budget' -and $phase -ceq 'post-move')) { return [long](2*[Diagnostics.Stopwatch]::Frequency) }
            if ($script:NativeDiagnosticFault -ceq 'retry-expired' -and $phase -ceq 'move') { return [long][Diagnostics.Stopwatch]::Frequency }
            return [long]0
        }
        freeC={ param($phase)
            if ($script:NativeDiagnosticFault -ceq 'sample-failure') { throw [InvalidOperationException]::new('fixture sample failure') }
            return [long]45GB
        }
        freeE={ param($phase) return [long]20GB }
        exists={ param($phase,$path) return $false }
        utc={ param($phase) return '1970-01-01T00:00:00.0000000Z' }
        write={ param($phase,$path,$payload)
            if ($script:NativeDiagnosticFault -ceq 'stop-record-failure' -and $phase -ceq 'stop-write') { throw [IO.IOException]::new('fixture stop write failure') }
            if ($script:NativeDiagnosticFault -cin @('write-failure','flush-labelled-failure')) { throw [IO.IOException]::new('fixture controlled write/flush failure') }
            if ($script:NativeDiagnosticFault -ceq 'sanitized-cause') { throw [IO.IOException]::new(('secret-token-fixture-only='+'x'*4096)) }
        }
        move={ param($phase,$from,$to)
            if ($script:NativeDiagnosticFault -ceq 'move-failure') { throw [InvalidOperationException]::new('fixture move failure') }
            $script:fixtureMoveAttempts+=1
            $retryCodes=@{'retry-code5'=-2147024891;'retry-code32'=-2147024864;'retry-code33'=-2147024863;'retry-foreign-facility'=-2146232800;'retry-unsupported-code'=-2147024894;'retry-expired'=-2147024864;'retry-stopped'=-2147024864}
            if ($retryCodes.ContainsKey($script:NativeDiagnosticFault) -and $script:fixtureMoveAttempts -eq 1) {
                if ($script:NativeDiagnosticFault -ceq 'retry-stopped') { Stop-NativeGuardian 'fixture stop during move' }
                $inner=[IO.IOException]::new('fixture wrapped move failure',$retryCodes[$script:NativeDiagnosticFault])
                throw [Management.Automation.MethodInvocationException]::new('fixture invocation wrapper',$inner)
            }
        }
        append={ param($phase,$path,$payload) }
        sleep={ param($phase,$milliseconds) }
    }
    $caught=$null
    $assertion=$null
    try {
        if ($case -cin @('case-byte-bound','cohort-byte-bound')) {
            $oversized=Join-Path $control 'refused-output.json'
            $script:fixtureCohortFull=($case -ceq 'cohort-byte-bound')
            $capFailure=$null
            try {
                $value=if($case -ceq 'case-byte-bound'){@{fixture_payload='x'*1MB}}else{@{fixture=$true;usage_provider='finite-synthetic-full-cohort'}}
                Write-FixtureRecord $oversized $value
            } catch { $capFailure=$_.Exception.Message }
            $script:fixtureCohortFull=$false
            $capReason=if($case -ceq 'case-byte-bound'){'Fixture case exceeds 1MiB'}else{'Fixture cohort exceeds 16MiB'}
            Assert-Fixture ($capFailure -ceq $capReason -and !(Test-Path -LiteralPath $oversized)) 'Output-cap exhaustion created or accepted output'
        }
        if ($case -ceq 'cause-count-bound') {
            for($repeat=0;$repeat -lt 64;$repeat++) { Add-ColdNativeCause ([IO.IOException]::new('secret-token-fixture-only')) 'native-heartbeat-publication' 'write' $null $null }
            Assert-Fixture ($script:diagnosticCauses.Count -eq 32 -and $script:diagnosticCauses[31].reason_code -ceq 'diagnostic-cause-count-bound') 'Typed cause exhaustion was not explicit/bounded'
        }
        if ($case -cin @('cause-record-failure','stop-record-failure')) { $script:diagnosticCauses=[int]42 }
        if ($case -ceq 'stop-record-failure') {
            Stop-NativeGuardian 'fixture operator stop'
            Assert-Fixture ($script:stopped -and !$script:stopMarkerWritten -and $guardianErrors.Count -eq 1) 'Diagnostic recorder replaced original sticky-stop write failure'
            Assert-Fixture ($script:nativeDiagnosticCaptureUnavailable -and $script:nativeDiagnosticCaptureFailures.Count -eq 1 -and $script:pendingNativeDiagnosticCause.phase -ceq 'stop-write') 'Sticky-stop primary/secondary capture failure disappeared'
        }
        if ($case -ceq 'provider-crossover') { $script:NativeDiagnosticFixture=$false }
        if ($case -ceq 'provider-missing') { $script:NativeDiagnosticEffects=$null }
        if ($case -ceq 'operator-stop') { Stop-NativeGuardian 'fixture operator stop' }
        $cFree=if ($case -cin @('admission-floor','cause-record-failure','cause-serialization-failure')) { [long]39GB } else { [long]45GB }
        try { Publish-NativeHeartbeat $cFree ([long]20GB) } catch { $caught=$_.Exception }
        if ($case -cin @('cause-record-failure','cause-serialization-failure')) {
            Assert-Fixture ($caught.Message -ceq 'Heartbeat floor or stopped state not admitted') 'Diagnostic capture failure masked the initiating publication error'
            Assert-Fixture ($script:nativeDiagnosticCaptureUnavailable -and $script:nativeDiagnosticCaptureFailures.Count -eq 1) 'Diagnostic capture failure was not separately retained'
            Assert-Fixture ($script:pendingNativeDiagnosticCause.phase -ceq 'admission' -and $script:pendingNativeDiagnosticCause.reason_code -ceq 'heartbeat-floor-or-stopped') 'Unavailable-list fallback lost bounded primary'
        } elseif ($case -ceq 'stop-record-failure') {
            Assert-Fixture ($caught.Message -ceq 'Heartbeat floor or stopped state not admitted' -and $script:nativeDiagnosticCaptureFailures.Count -eq 2) 'Stop handling or separate subsequent publication failure drifted'
        } elseif ($case -cin @('provider-crossover','provider-missing')) {
            Assert-Fixture ($null -ne $caught -and $script:heartbeatSequence -eq 0 -and $script:diagnosticCauses[0].phase -ceq 'temporary-check') 'Fixture provider crossover/missing-provider reached live native effects'
        } elseif ($case -cin @('retry-code5','retry-code32','retry-code33')) {
            Assert-Fixture ($null -eq $caught -and $script:publicationRetries -eq 1 -and $script:fixtureMoveAttempts -eq 2 -and $script:heartbeatSequence -eq 1) 'Existing admitted Win32 move retry changed'
        } elseif ($case -cin @('retry-foreign-facility','retry-unsupported-code','retry-expired','retry-stopped')) {
            Assert-Fixture ($null -ne $caught -and $script:publicationRetries -eq 0 -and $script:fixtureMoveAttempts -eq 1 -and $script:heartbeatSequence -eq 0) 'Existing refused move retry boundary changed'
        } elseif ($case -ceq 'cause-count-bound') {
            Assert-Fixture ($null -eq $caught -and $script:diagnosticCauses.Count -eq 32) 'Cause count bound changed publication decisions'
        } elseif ($case -cin @('graceful','case-byte-bound','cohort-byte-bound')) {
            Assert-Fixture ($null -eq $caught -and $script:heartbeatSequence -eq 1 -and !$script:stopped) 'Synthetic graceful publication did not retain its outcome'
            Assert-Fixture ($script:diagnosticCauses.Count -eq 0) 'Graceful synthetic publication fabricated a cause'
        } else {
            Assert-Fixture ($null -ne $caught) 'Controlled native failure was accepted'
            Assert-Fixture ($script:diagnosticCauses.Count -gt 0) 'Initiating native failure phase/cause was lost'
            $cause=$script:diagnosticCauses[0]
            Assert-Fixture ($cause.operation -ceq 'native-heartbeat-publication' -and $cause.synthetic_provider -eq $true) 'Native cause lacks bounded fixture identity'
            $expected=@{
                'admission-floor'='admission'; 'sample-failure'='sample-c'; 'write-failure'='write';
                'flush-labelled-failure'='write'; 'move-failure'='move'; 'post-write-budget'='post-write';
                'post-move-budget'='post-move'; 'operator-stop'='admission'; 'sanitized-cause'='write'
            }[$case]
            Assert-Fixture ($cause.phase -ceq $expected) 'Native failure phase drifted'
            Assert-Fixture ($cause.internal_flush_close_observation -ceq 'unavailable-inside-WriteAllText') 'Unobserved internal flush/close was fabricated'
            Assert-Fixture ($null -ne $cause.hresult -and $cause.exception_types.Count -gt 0) 'Native exception identity/HRESULT lost'
            $serialized=ConvertTo-Json $cause -Depth 10 -Compress
            Assert-Fixture ($utf8.GetByteCount($serialized) -le 16384 -and $utf8.GetByteCount($cause.reason_code) -le 1024) 'Native typed cause/reason exceeded bound'
            Assert-Fixture (!$serialized.Contains('secret-token-fixture-only') -and !$serialized.Contains('xxxx')) 'Exception contents leaked into native diagnostics'
            if ($case -ceq 'post-move-budget') { Assert-Fixture ($script:stopped -and $script:stopMarkerWritten) 'Late publication cleared sticky stop' }
            if ($case -ceq 'operator-stop') { Assert-Fixture ($script:stopped -and $script:stopMarkerWritten) 'Operator stop was cleared' }
        }
    } catch { $assertion=$_.Exception.Message; $failed=$true }
    $record=[ordered]@{
        kind='cold_native_diagnostics_fixture_v6';case_id=$case;fixture=$true;recovery_acceptance=$false;
        source_sha256=$SourceSha256;harness_sha256=$harnessHash;clock_provider='finite-synthetic-ticks';effect_provider='finite-fixture-effects';
        observed_exception_type=$(if ($caught) { $caught.GetType().FullName } else { $null });
        diagnostic_causes=$(if($script:diagnosticCauses -is [Collections.Generic.List[object]]){@($script:diagnosticCauses.ToArray())}else{@()});guardian_errors=@($guardianErrors.ToArray());
        diagnostic_capture_failures=@($script:nativeDiagnosticCaptureFailures.ToArray());diagnostic_capture_unavailable=$script:nativeDiagnosticCaptureUnavailable;pending_native_cause=$script:pendingNativeDiagnosticCause;
        heartbeat_advances=$script:heartbeatSequence;guardian_stopped=$script:stopped;stop_marker_written=$script:stopMarkerWritten;
        assertion_passed=($null -eq $assertion);assertion_failure=$assertion
    }
    Write-FixtureRecord (Join-Path $control 'result.original.v1.json') $record
    $rows.Add(@{case_id=$case;assertion_passed=($null -eq $assertion)})
}
$script:NativeDiagnosticEffects=$null
$script:NativeDiagnosticFixture=$false
Write-FixtureRecord (Join-Path $OutputRoot 'suite.original.v1.json') @{kind='cold_native_diagnostics_suite_v6';fixture=$true;recovery_acceptance=$false;source_sha256=$SourceSha256;harness_sha256=$harnessHash;cases=$rows.ToArray();successful=(!$failed)}
Write-Output (ConvertTo-Json @{suite=$Suite;cases=$rows.Count;successful=(!$failed);fixture=$true;recovery_acceptance=$false} -Compress)
if ($failed) { exit 1 }
exit 0
