"""Seal bounded author evidence; read original/protected subjects without executing them."""
import hashlib
import json
from pathlib import Path

root=Path(__file__).resolve().parent
report=root/'composed-authored-run-8c31434b17944a6cbc8c5038dda83d70'
result=json.loads((report/'result.original.v6.json').read_bytes())
assert result['tests_run']==31 and result['failures']==result['errors']==0
assert result['fixture'] is True and result['recovery_acceptance'] is False
assert result['source_before']==result['source_after']
def record(path):
    raw=path.read_bytes()
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
names=(*result['source_before'],'test_cold_recovery_diagnostics_v6.py','Test-SealedDiagnosticWriteCap.v6.ps1',
       'author_guest_v6.py','guest_reporting_v6.fragment.py.txt','author_preserved_outer_predicates.py',
       'fidelity.v1.md','guest-outer-author-conformance.v1.md',Path(__file__).name)
subjects={name:record(root/name) for name in names}
for name,pin in result['source_before'].items():
    assert subjects[name]['sha256']==pin
    assert record(report/'source-snapshot'/name)==subjects[name]
assert subjects['Native-ColdGuardian.v6.ps1']['sha256']=='7a04890c383bc50ca0d77ba4cdf99e284c64ffab2bc6ad74a0f08560cb8c5b2b'
original=Path('E:/STUDY/VAST/tmp/host-cache-cleanup-20261012')
protected=Path('E:/VAST-cold03-a3990e2870c940149785831b845aea91/helpers-cold03')
pins={
'ColdRootSecurity.v2.ps1':'69ca07ee87fa93f55f510f46335856acd8b52f58700e8dfdf5f0f0c17cf204a6',
'Native-ColdGuardian.v1.ps1':'e2cbb87a20667aac6039993c70395c600dc861992b85f91260daee9f30a2314a',
'native_heartbeat_lease_v1.py':'8aae687de0b919f90c8a12f34bc7798920bc0c41250049aef3595225a4bd7fb4',
'cold_restore_docker_archive_v5.py':'6a63c732ae26f3dc24187779a1434021a932e00725fdc31edab05d051dd9993f',
'run_isolated_cold_restore_v5.sh':'7dcfe31bb79f01aec5276ca9d471de338597fd1b4d8225893a24b7927b6559b0',
'Capture-DockerCleanupAudit.v3.ps1':'f46125edb0771fc30b5cdabc82a440b641e01e9fd0bb16185bdbeb5ff3d55018',
'Run-ColdDockerRecovery.v5.ps1':'54535e950c0782129172e1822058b2d4a64ff1cb7d55dab36510c1fc6b20cec0',
'Run-RecordedColdOperation.v3.ps1':'de2d4bf496b59e9e2b5f0e7bbced0a057da752c8b072b1f4e4fc6165bc1195fc'}
preservation={}
for name,pin in pins.items():
    before=record(original/name)
    assert before['sha256']==pin
    row={'original':before}
    if name!='Run-RecordedColdOperation.v3.ps1':
        held=record(protected/name)
        assert held==before
        row['protected_cold03']=held
    preservation[name]=row
def size(path):
    return sum(p.stat().st_size for p in path.rglob('*') if p.is_file())
case_sizes={p.name:size(p) for p in root.glob('case-*') if p.is_dir()}
assert max(case_sizes.values())<=1048576 and size(root)<=16777216
evidence={str(p.relative_to(root)):record(p) for p in (report/'result.original.v6.json',report/'unittest.original.stderr',report/'source-snapshot'/'manifest.v1.json')}
manifest={'kind':'D7_guest_outer_authored_candidate_manifest_v1','author':'audit_integration','fixture':True,
 'recovery_acceptance':False,'independent_review':'pending','planning_commit':'4666e9e21741eda1f2f5b72d5a2de4bba6a7cd1a',
 'approval_comment':6180355014,'subjects':subjects,'evidence':evidence,'original_preservation':preservation,
 'tests_run':31,'failures':0,'errors':0,'elapsed_seconds':result['elapsed_seconds'],
 'cohort_bytes_before_seal':size(root),'max_case_bytes':max(case_sizes.values()),'case_directories':len(case_sizes),
 'limits':{'reason_bytes':1024,'cause_bytes':16384,'case_bytes':1048576,'cohort_bytes':16777216},
 'scope':'Author candidate only; no real storage/restore/image/qualification authority; originals retained.'}
payload=(json.dumps(manifest,indent=2)+'\n').encode()
assert size(root)+len(payload)<=16777216
out=root/'guest-outer-author-manifest.v1.json'
with out.open('xb') as stream:stream.write(payload)
print(json.dumps({'manifest':str(out),'manifest_sha256':hashlib.sha256(payload).hexdigest(),'subjects':subjects,'evidence':evidence,'cohort_bytes_after_seal':size(root),'max_case_bytes':max(case_sizes.values())}))
