"""Preserve source of a completed authored diagnostic fixture run, never alter it."""
import hashlib
import json
import sys
from pathlib import Path
root=Path(__file__).resolve().parent
assert len(sys.argv)==2 and sys.argv[1].startswith('composed-authored-run-') and '/' not in sys.argv[1] and '\\' not in sys.argv[1]
report=root/sys.argv[1]
value=json.loads((report/'result.original.v6.json').read_bytes())
out=report/'source-snapshot'
out.mkdir(exist_ok=False)
subjects={}
for name in (*value['source_before'],'author_guest_v6.py','guest_reporting_v6.fragment.py.txt','test_cold_recovery_diagnostics_v6.py'):
    raw=(root/name).read_bytes()
    sha=hashlib.sha256(raw).hexdigest()
    if name in value['source_before']:
        assert sha==value['source_before'][name]==value['source_after'][name]
    (out/name).write_bytes(raw)
    subjects[name]={'bytes':len(raw),'sha256':sha}
(out/'manifest.v1.json').write_text(json.dumps({'fixture':True,'recovery_acceptance':False,'subjects':subjects},indent=2)+'\n')
print(json.dumps({'snapshot':str(out),'subjects':subjects}))
