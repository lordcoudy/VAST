"""Read-only working-byte recomputation using retained inventory parser bodies.

Only stdlib imports and audit function/configuration bodies execute. No project
module imports, tests, recipes, source copies, Git ref/object writes or workloads.
"""
import ast
import hashlib
import json
from pathlib import Path
import subprocess

ROOT=Path('C:/Users/s-a-balashov/.codex/worktrees/fix-accepted-policy-preprocessing/VAST')
OUT=Path(__file__).resolve().parent
CAP=819200
BASE=OUT.parent
tool=BASE/'inventory_static.py'
tool_raw=tool.read_bytes()
assert hashlib.sha256(tool_raw).hexdigest()=='c818ec5cf2d09df7ccbeec88ba8c8b45b515caf62e05a11487e847a993504708'
prior=json.loads((BASE/'inventory.v1.json').read_bytes())
parsed=ast.parse(tool_raw)
ns={'ROOT':ROOT,'__name__':'retained_audit_parser_functions_only'}
definitions=[n for n in parsed.body if isinstance(n,(ast.Import,ast.ImportFrom,ast.FunctionDef))]
exec(compile(ast.Module(body=definitions,type_ignores=[]),str(tool),'exec'),ns)
git=ns['git']
head=git('rev-parse','HEAD').decode().strip()
commits=dict(prior['commits']);commits['integrated']=head
trees={}
for label,commit in commits.items():
    entries={}
    for row in git('ls-tree','-rz',commit).split(b'\0'):
        if row:
            meta,name=row.split(b'\t',1);mode,kind,oid=meta.decode().split()
            entries[name.decode()]={'mode':mode,'kind':kind,'blob':oid}
    trees[label]=entries
ns.update({'TREES':trees,'CACHE':{},'PARSED':{},'COMMITS':commits,'HEAD':head})
changed=git('diff','--name-only','--','scripts','deploy','configs').decode().splitlines()
leaf='scripts/publication_image_freeze_receipt_validation_v1.py'
expected={leaf,'scripts/publication_image_build_v1.py','scripts/publication_qualification_image_refreeze_v1.py'}
for base,docker in [('deploy/deepstream/checkpoint','Dockerfile.runtime'),('deploy/savant/publication','Dockerfile'),('deploy/openvino_gva/publication','Dockerfile'),('deploy/gstreamer_custom/publication','Dockerfile')]:
    expected.update({base+'/'+docker,base+'/runtime-source-allowlist.txt'})
assert set(changed)|{leaf}==expected,(changed,expected)
working={}
for relative in sorted(expected):
    payload=(ROOT/relative).read_bytes()
    # This is a computed prospective blob identity; no object/ref is written.
    oid=hashlib.sha1(b'blob '+str(len(payload)).encode()+b'\0'+payload).hexdigest()
    old=trees['integrated'].get(relative)
    working[relative]={'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest(),
                       'prospective_blob_oid':oid,'baseline_git_blob':old['blob'] if old else None}
    trees['integrated'][relative]={'mode':'100644','kind':'blob','blob':oid}
    ns['CACHE'][oid]=payload
for label in trees:
    ns['preload'](v['blob'] for p,v in trees[label].items() if p.startswith('scripts/') and p.endswith('.py'))
def assigned(node,name):
    return isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in node.targets)
start=next(i for i,n in enumerate(parsed.body) if assigned(n,'GUARDIAN_SEEDS'))
end=next(i for i,n in enumerate(parsed.body) if assigned(n,'controls'))
# The exact retained statements construct all-depth literal/fixed/finite graphs,
# the four COPY/manifest/native groups and five actual producer contexts.
exec(compile(ast.Module(body=parsed.body[start:end],type_ignores=[]),str(tool),'exec'),ns)
def function(path,name):
    raw=path if isinstance(path,bytes) else (ROOT/path).read_bytes()
    return next(n for n in ast.parse(raw).body if isinstance(n,ast.FunctionDef) and n.name==name)
stock=git('show',head+':scripts/publication_image_build_v1.py')
leaf_raw=(ROOT/leaf).read_bytes()
faithful={name:ast.dump(function(stock,name),include_attributes=False)==ast.dump(function(leaf_raw,name),include_attributes=False)
          for name in ('_require','_canonical_json','_receipt_sha256','load_publication_image_freeze_receipt')}
assert all(faithful.values())
old_reader=function(git('show',head+':scripts/publication_qualification_image_refreeze_v1.py'),'_load_build_receipt')
new_reader=function('scripts/publication_qualification_image_refreeze_v1.py','_load_build_receipt')
old_call=next(n for n in ast.walk(old_reader) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='load_publication_image_freeze_receipt')
old_call.func=ast.Name(id='load_publication_image_freeze_receipt',ctx=ast.Load())
ordering_preserved=ast.dump(old_reader,include_attributes=False)==ast.dump(new_reader,include_attributes=False)
assert ordering_preserved
for row in ns['RUNTIME']:
    assert not any(row[k] for k in ('python_missing','python_extra','guardian_missing','host_only_leakage','copy_missing','copy_extra','context_missing_copy_or_dockerfile'))
    assert leaf in row['copy']['paths'] and leaf in row['declared_sources']
    assert 'scripts/publication_image_build_v1.py' not in row['copy']['paths']
    assert 'scripts/materialize_runtime_build_context_v3.py' not in row['copy']['paths']
    assert not row['native_graph']['missing_declared'] and not row['native_graph']['extra_declared'] and not row['native_graph']['unresolved_quoted_includes']
for row in ns['IMAGES']:
    assert not row['copy_missing'] and not row['copy_extra'] and not row['missing_project_imports'] and not row['missing_repo_local_include_inputs']
    assert not any(row['historical_changes'][old]['changed_context_paths'] or row['historical_changes'][old]['manifest_changed_paths'] for old in ('ACA','65','f549'))
    assert row['aggregate_sha256']==next(x for x in prior['native_worker_rows'] if x['name']==row['name'])['aggregate_sha256']
graphs={name:ns[value] for name,value in [('guardian','GUARDIAN'),('qualification','QUALIFICATION'),('supplemental_guardian','GUARDIAN_SUPPLEMENT'),('supplemental_qualification','QUALIFICATION_SUPPLEMENT')]}
def compact_graph(value):
    return {'seeds':value['seeds'],'paths':value['paths'],'edge_count':len(value['edges']),
            'edge_canonical_sha256':hashlib.sha256(json.dumps(value['edges'],sort_keys=True,separators=(',',':')).encode()).hexdigest(),
            'fixed_and_finite_targets':[r for r in value['literal_file_references'] if r.get('kind')=='fixed_sibling_file_target'],
            'nonliteral_or_file_loader_calls':value['nonliteral_or_file_loader_calls'],
            'external_import_roots':value['external_import_roots'],
            'finite_import_edges':[r for r in value['edges'] if r.get('kind')=='finite_module_name_literal']}
def compact_runtime(row):
    return {**{k:v for k,v in row.items() if k not in ('python_graph','supplemental_python_graph','copy')},
            'python_graph':compact_graph(row['python_graph']),
            'supplemental_python_graph':compact_graph(row['supplemental_python_graph']),
            'copy':{'paths':row['copy']['paths'],'stage_to_stage':row['copy']['stage_to_stage']}}
records={p:{'bytes':len(ns['raw'](p)),'sha256':ns['sha'](ns['raw'](p)),
            'prospective_blob_oid':trees['integrated'][p]['blob']} for p in sorted(ns['all_paths']|expected)}
after={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in working}
assert all(after[p]==working[p]['sha256'] for p in working)
report={'kind':'D8_independent_working_byte_static_review_v1','reviewer':'audit_integration','baseline_commit':head,
 'scope':'Working-byte static source/COPY/context review only; not exact-commit or physical/package/consumer/whole-diff acceptance',
 'verdict':'CLEAR_bounded_static_scope_pending_host_bootstrap_regression_and_other_gates',
 'retained_tool':{'path':str(tool),'sha256':hashlib.sha256(tool_raw).hexdigest(),'execution':'Only unchanged stdlib imports/parser functions/configuration computation; Git baseline overlaid with pinned current bytes in memory'},
 'no_project_imports_tests_or_workloads':True,'working_subjects':working,'working_after_sha256':after,
 'faithful_stock_AST_functions':faithful,'refreeze_only_reader_call_substitution':ordering_preserved,
 'graphs':{k:compact_graph(v) for k,v in graphs.items()},'runtime_rows':[compact_runtime(r) for r in ns['RUNTIME']],'native_worker_rows':ns['IMAGES'],'source_records':records,
 'host_graph':compact_graph(ns['HOST_GRAPH']),
 'runtime_route_disposition':{'default':'fragment DEFAULT -> refreeze.load_identity_patch -> _physical_file -> shared leaf reader -> _descriptor; no host builder load',
 'materializer':'preserved host-only fixed load in builder.materialize_image_context and four host shell build recipes; retain DS/Savant BUILD_ONLY and OV/GST context declarations; absent all final COPY',
 'legacy':'three finite legacy fragment modules remain host legacy; guardian explicit authority-v2 validator bypasses map',
 'host_builder':'public same-leaf alias under explicit ordinary ROOT/scripts host bootstrap; dependency-free arbitrary file loading is not claimed supported'},
 'status_porcelain':git('status','--porcelain').decode(),'limits':{'control_bytes':CAP},
 'still_open':['fresh isolated host spec-loader bootstrap regression evidence','full2.8 package/import-order/actual-image checks','physical renewal/pins/parity','genuine126016/29/20/42 consumers','whole-diff1.7','capacity1.5','exact-commit review']}
payload=(json.dumps(report,sort_keys=True,separators=(',',':'))+'\n').encode()
current=sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file())
assert current+len(payload)<=CAP-16384,(current,len(payload),CAP)
with (OUT/'inventory.working.original.v1.json').open('xb') as stream:stream.write(payload)
print(json.dumps({'report':str(OUT/'inventory.working.original.v1.json'),'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest(),
 'graph_counts':{k:len(v['paths']) for k,v in graphs.items()},
 'runtime_counts':{r['system']:{'declared':len(r['declared_sources']),'python':len(r['python_graph']['paths']),'copy':len(r['copy']['paths']),'context':len(r['actual_context'])} for r in ns['RUNTIME']},
 'native_contexts_unchanged':True,'control_bytes':current+len(payload)}))
