# Independent D8 evidence review and task 1.7 disposition

Reviewer /root/audit_integration; read-only, no duplicate execution. Root authored production, audit_capacity the test/evidence. D7 authorship is this reviewer's; independent D7 review is joined separately. Baseline8840e2230c9dda560870774867b2ce38dc4fd2d8; no implemented commit accepted.

Verdicts: **CLEAR for the bounded D8 source correction and original behavioral evidence; BLOCK for blanket original execution-plan resource conformance; task 1.7 approval HELD pending the explicit resource disposition, implemented exact commit, required current checks and recorded delegated decision.** No new source-correctness defect was found. Physical/genuine acceptance remains downstream.

## Exact D8 bindings and original outcomes

Paths below are under E:/STUDY/VAST/tmp/completion-implementation-20261015/package-reader-bounded-01/ unless stated otherwise.

- GREEN author manifest: 13031 B, SHA256 02b4ae6a33539c493853a39de29f6730f82213681bbd92290a538103a575b1f5.
- leaf-green-01.execution.original.v1.json: 4880 B, SHA256 29e598f214bc7067faca9467c10f8d1c580ca684e7912389b81e227ed4d803f3. Original RC0, 46.0643213 s, no timeout/retry. Four unittest methods, no failures/errors/skips.
- Executed test snapshot v8 and current tests/test_publication_image_freeze_receipt_validation_v1.py: 35036 B, SHA256 4a1f91ab36979154b022328926a6cf00235399c7e300198a32dd861433fa133b.
- Leaf: 1677 B, f1f674a644ec0ac7b1e652fdb5736945be876a792160d41de15aa9a53cdacf03; refreeze: 65306 B, 8f3a01748576aa887531393467a9aa225aacc0d7615361e21588b4df7fc7ca24; builder: 33186 B, a41dbdfb733d2a2a64272d770b20a43670703cb499a3caf9025afa4f84f1223b. Current bytes equal executed production pins and the earlier static review.

All57 fresh child records/raw hashes match:54RC0/three RC2 refusals,60s bounds, recovery=false. All24 stock/leaf pairs agree:6returns/18errors, canonical/self-hash bytes and exception type/message/cause/context/suppression. Stock quirks and outer descriptor/symlink/hardlink refusals survive.

Unchanged DEFAULT_DEPENDENCIES.load_identity_patch returns the preserved-stock patch. Loaded modules match one effective code directory and pinned targets/hashes, without builder/materializer. This lower callback does not exercise the full fragment/guardian consumer.

Native checks verify87provenance members (85exact baseline symlinks/two physical files),377old catalog size/hash/link rows and75metadata mode/device/inode/link/content/target rows. Regular metadata155218B; five stock originals match. RED04 remains RC1/missing builder wrapped as invalid native_probe receipt;01-03 remain preparation failures. RED manifest SHA256de2d77e8f1882b6b664532ac7a6e34f1ae7dc118c76197339691195f38f68064 is preserved.

Host alias uses actual ROOT/scripts in fresh-I-B; normal/file-spec builder readers and fragment defaults share identity. This covers that host contract, not arbitrary dependency-free loading or every cold order. No production rescue fallback is needed.

## Resource-plan finding

Original execution-plan.v1.md says unqualified "<=8MiB staged sources" and "one fresh exclusive package-staging tree". Preserved failed01 package contains 4407612 B; correct02 source pair contains 8269987 B. Cumulative original staged source payload was **12677599 B before GREEN**, exceeding 8388608 B, with two retained staging roots. Original plan compliance cannot be claimed.

The later GREEN plan explicitly charges only active02 plus the new view against8MiB, and failed01 under16MiB retained total. Fresh static native accounting verifies view lstat bytes78416 and active02+view8348403 (<8388608). That narrower active-input/forensic distinction is documented, but is not proof that the original unqualified source/one-tree bound was met. Accepting it as the original meaning silently would alter the conformance claim.

At this read, native retained roots are4407612 and8503893 B; bounded controls1472781 B; external review controls295492 B before this receipt; live test35036 B. Combined14714814 B is below16MiB. Both roots and all failures remain protected. Report/case checks and recorded C: observations are bounded-stage evidence, not whole-chain backing qualification. Adjacent36/36 checks disclose1541016 B static context payload; peak was not measured and must not be invented.

Required disposition must preserve the historical deviation and original bytes/plans without deletion, relabeling, budget enlargement or local rerun. Root proposes cumulative all-retained-source refusal before copy/view writes, closing this cohort to allocations, and mandatory new-commit hosted CI with one fresh tree under original8MiB/16MiB. This mitigation remains review-pending. Behavioral GREEN survives with resource BLOCK; recount retention copies/receipts.

## Whole-source/integration preservation join

Prior review PR9comment6179567194 was superseded by P1comment6179777830; no standalone older review report is proven. Catalog integrated-0cb95-inventory.original.v1.json (671302B,SHA2567d62dca5d5d92835c14cd72894d8f2a50e715d9629d61ada8e7e7141b067b830) reproduces3543rename-aware Git changed rows ead12cec->0cb95;3553raw object differences represent that same scope. Catalog is not approval.

Exact0cb95 tree b7e90e2b44bf1ef20453efd3779a6434fb9ea729 has12982 paths. Current8840 tree c53cb538aebe3d8e42f6ab01f3e18816577d2c8e has12983. Only four planning blobs differ and the pinned D7 amendment is added; all854 scripts/tests/configs/deploy/.ci/.github objects survive unchanged. Current implementation deltas are precisely the eleven reviewed D8 production/deploy subjects plus the new reviewed test. Scoped .gitattributes append preserves its old prefix; task changes close only separately approved1.8/2.6. No production CI or native/worker source changed.

Combined supervisor/service hashes remain5552db9bfba5333c07b7745cc435f26d901620b0fb1a7f58dc7fd79027053d83 and39999a59a23804646a3ae972fdbb03354b32519916daf9445b77d4a4fea13e1a. All four main specs and36 accepted S3 archive objects remain identical to ead12cec. Old qualify-full-benchmark/tasks.md is byte-identical to0cb95, SHA256514354827361fbc39177f261f3ea08b554bd06cbda65560e91562a8ef03e5851, with nine unchecked tasks; it remains active/unarchived. Historical fixture/evidence objects are untouched by D8.

D7 independent report a41beb6ace994c53cc786e5fd1ab916b51ff38ccc760f9f5e9cd05a0c90edcf2 CLEAR binds helpers/conformance/31-case run; same-PR Git join remains pending. Static review.final.v1.md SHA2565047e929e44b88b3b44412d03742d228cdfe2f50f91132b87c228f8b524e690e binds four COPY/list additions, fixed/finite/default routes and unchanged native/worker contexts. Materializer BUILD_ONLY and host legacy routes survive; changed controller closure implies no producer acceptance.

## Task 1.7 gate and downstream limits

P1's missing host builder on the supported lower default path is resolved at these working bytes by the faithful leaf, ordinary refreeze reader and four reviewed COPY/allowlist additions. The inherited source/integration join plus independently reviewed D8/D7 changes has no unresolved source defect at this observation. Task1.7 still needs a deliberate implemented same-PR commit, exact-commit re-verification, appropriate focused/current hosted checks and explicit delegated approval after the resource finding is dispositioned. Earlier0cb/4666/8840 CI cannot be rebound to that future commit.

Do not make renewed images or genuine consumers prerequisites to the code review that enables4.3: that would create a cycle. Separate open gates are full2.8/source cold-order coverage and4.1 closure verification; actual-image interpreters/default point-of-use4.2; capacity1.5 plus fresh ownership before4.3; renewal/refreeze/parity/pins4.3-4.5; physical/ext4 and genuine3840/3968/126016 plus29/20/42 refusals5.2-5.3; full conformance5.4, distinct qualification5.5, sync/archive and final-head checks/approval/merge. No capacity, recovery, image action, genuine consumer, archive or final acceptance follows from this review.
