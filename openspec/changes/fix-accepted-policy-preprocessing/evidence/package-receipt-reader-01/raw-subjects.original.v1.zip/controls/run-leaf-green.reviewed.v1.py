from pathlib import Path
import subprocess, json, hashlib, shutil, time, datetime
BASE=Path('E:/STUDY/VAST/tmp/completion-implementation-20261015/package-reader-bounded-01')
REPO=Path('C:/Users/s-a-balashov/.codex/worktrees/fix-accepted-policy-preprocessing/VAST')
TEST=REPO/'tests/test_publication_image_freeze_receipt_validation_v1.py'
RUNTIME='/home/s-a-balashov/.local/state/vast/publication/runtime/full-publication-cp312-v1/bin/python'
STAGE='/var/tmp/vast-package-reader-bounded-01-bfb577dbdaf349fb8d1a5834b32e287f'
def sha(b):return hashlib.sha256(b).hexdigest()
def write(name,b):
 p=BASE/name;assert not p.exists();p.write_bytes(b)
 return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def native_counts():
 code='''from pathlib import Path
import json
roots=[Path("/var/tmp/vast-package-reader-bounded-01-7a6f57c4c3894226a059882997612c38"),Path("/var/tmp/vast-package-reader-bounded-01-bfb577dbdaf349fb8d1a5834b32e287f")]
print(json.dumps([{"root":str(root),"bytes":sum(p.lstat().st_size for p in root.rglob("*") if p.is_file() or p.is_symlink())} for root in roots]))'''
 r=subprocess.run(['wsl','-d','Ubuntu','--',RUNTIME,'-I','-B','-c',code],capture_output=True,timeout=60,check=True)
 return json.loads(r.stdout)
def controls():
 roots=[BASE,BASE.parent/'dependency-inventory-integrated-01/d8-working-review-01']
 values=[{'root':str(p),'bytes':sum(v.lstat().st_size for v in p.rglob('*') if v.is_file() or v.is_symlink())} for p in roots]
 assert values[1]['bytes']<=819200
 return values
test_sha=sha(TEST.read_bytes());assert test_sha=='4a1f91ab36979154b022328926a6cf00235399c7e300198a32dd861433fa133b'
assert sha((BASE/'green-overlay.execution-plan.proposed.v1.md').read_bytes())=='f1efe91d8441578e873370d3d9108a13ca1c6a84567f06bb882241f73eaae3c8'
pin=BASE/'green-overlay.pinned-inputs.original.v2.json';assert sha(pin.read_bytes())=='29f21adbbf53c167b7e342c8fa4c6f0c2dbcbb6b352b594b927b969033e7d75e'
subjects=[]
for name,digest in {
 'scripts/publication_image_freeze_receipt_validation_v1.py':'f1f674a644ec0ac7b1e652fdb5736945be876a792160d41de15aa9a53cdacf03',
 'scripts/publication_qualification_image_refreeze_v1.py':'8f3a01748576aa887531393467a9aa225aacc0d7615361e21588b4df7fc7ca24',
 'scripts/publication_image_build_v1.py':'a41dbdfb733d2a2a64272d770b20a43670703cb499a3caf9025afa4f84f1223b'}.items():
 p=REPO/name;b=p.read_bytes();assert sha(b)==digest;subjects.append({'path':str(p),'bytes':len(b),'sha256':digest})
stock=json.loads((BASE/'stock-authority.original.manifest.v1.json').read_bytes())
for row in stock['files']:assert sha((BASE/'stock-authority.original'/row['path']).read_bytes())==row['sha256']
native_before=native_counts();control_before=controls();before=shutil.disk_usage('C:/').free
assert before>=40*1024**3
assert sum(v['bytes'] for v in control_before)<=4*1024**2
assert sum(v['bytes'] for v in native_before+control_before)+TEST.stat().st_size<=16*1024**2
assert not (BASE/'leaf-green-01').exists()
argv=['wsl','-d','Ubuntu','--','env',
 'VAST_PACKAGE_READER_STOCK=/mnt/e/STUDY/VAST/tmp/completion-implementation-20261015/package-reader-bounded-01/stock-authority.original',
 'VAST_PACKAGE_READER_STAGE='+STAGE,
 'VAST_PACKAGE_READER_REUSE_SOURCES=/mnt/e/STUDY/VAST/tmp/completion-implementation-20261015/package-reader-bounded-01/default-chain-red-02/staged-sources.original.v1.json',
 'VAST_PACKAGE_READER_CASE_SUFFIX=-green01',
 'VAST_PACKAGE_READER_OVERLAY_PIN=/mnt/e/STUDY/VAST/tmp/completion-implementation-20261015/package-reader-bounded-01/green-overlay.pinned-inputs.original.v2.json',
 'VAST_PACKAGE_READER_REPORTS=/mnt/e/STUDY/VAST/tmp/completion-implementation-20261015/package-reader-bounded-01/leaf-green-01',
 RUNTIME,'-I','-B','/mnt/c/Users/s-a-balashov/.codex/worktrees/fix-accepted-policy-preprocessing/VAST/tests/test_publication_image_freeze_receipt_validation_v1.py','-v']
started=time.monotonic()
try:
 r=subprocess.run(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=900,check=False)
 timed_out=False
except subprocess.TimeoutExpired as error:
 assert len(error.stdout or b'')+len(error.stderr or b'')<=1024**2
 write('leaf-green-01.unittest.original.stdout',error.stdout or b'');write('leaf-green-01.unittest.original.stderr',error.stderr or b'')
 write('leaf-green-01.timeout.original.v1.json',json.dumps({'timed_out':True,'budget_seconds':900,'argv':argv,'recovery_acceptance':False},indent=2).encode()+b'\n')
 raise
elapsed=time.monotonic()-started
assert len(r.stdout)+len(r.stderr)<=1024**2
originals=[write('leaf-green-01.unittest.original.stdout',r.stdout),write('leaf-green-01.unittest.original.stderr',r.stderr)]
after=shutil.disk_usage('C:/').free;native_after=native_counts();control_after=controls()
successful=(r.returncode==0 and b'Ran 4 tests' in r.stderr and r.stderr.rstrip().endswith(b'OK'))
record={'kind':'bounded-leaf-green-original-execution.v1','author':'audit_capacity','Verdict':'GREEN' if successful else 'FAILED_RETAINED',
 'recordedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':argv,'original_returncode':r.returncode,
 'timed_out':False,'elapsed_seconds':elapsed,'test_sha256':test_sha,'production_source_pins':subjects,
 'C_free_before':before,'C_free_after':after,'C_floor_bytes':40*1024**3,
 'native_before':native_before,'native_after':native_after,'controls_before':control_before,'controls_after':control_after,
 'total_after_before_receipt':sum(v['bytes'] for v in native_after+control_after)+TEST.stat().st_size,
 'budget_bytes':{'staged_sources':8*1024**2,'case':1024**2,'reports':4*1024**2,'total':16*1024**2},
 'stock_generation_authority':'preserved stock outside package code roots',
 'original_outputs':originals,'recovery_acceptance':False,'actual_image_hardware_capacity_consumer_acceptance':False,
 'no_automatic_retry':True,'scope':'Four portable source-only tests: lower default callback,24stock-leaf cases,outer physical refusals,host alias/default identity.',
 'adjacent_scope':'Separate original36/36existing adjacent tests had static aggregate context payload1541016B, sequential fake contexts; not receipt-only or a measured peak. Controls included in bounded root.'}
row=write('leaf-green-01.execution.original.v1.json',json.dumps(record,indent=2).encode()+b'\n')
print(json.dumps(row));print(json.dumps({'Verdict':record['Verdict'],'elapsed':elapsed,'original_returncode':r.returncode,'totalBeforeFinalReceipt':record['total_after_before_receipt']}))
assert before>=40*1024**3 and after>=40*1024**3 and elapsed<=900
assert sum(v['bytes'] for v in control_after)+row['bytes']<=4*1024**2
assert record['total_after_before_receipt']+row['bytes']<=16*1024**2
assert sha(TEST.read_bytes())==test_sha
for subject in subjects:assert sha(Path(subject['path']).read_bytes())==subject['sha256']
for subject in stock['files']:assert sha((BASE/'stock-authority.original'/subject['path']).read_bytes())==subject['sha256']
assert successful,'Original failure retained; stop without retry.'
