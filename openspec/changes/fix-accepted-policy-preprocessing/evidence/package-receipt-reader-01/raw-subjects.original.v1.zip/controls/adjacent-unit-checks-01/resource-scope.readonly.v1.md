# Adjacent regression resource scope

The original run completed once: 36 tests, 36 successes, zero failures, errors or
skips, 57.048 seconds, Python 3.12.3. The original report SHA256 is
f4fcebcad1754c99206a5559a86113448fcb69b9b878802b45b67166cc1ddf58.
Raw stderr is 7,772 bytes (SHA256
64c20b6b2d9d47f769e3dcbad69a4edf822c8f33d14d33c5a6dc7e54b7be85e7);
stdout is empty. Recorded source subjects are unchanged before/after.

The runner supplied the deliberate host ROOT/scripts and ROOT/tests import search
roots. It did not prove a packaged or arbitrary dependency-free file-loader
invocation. A separate fresh isolated host regression covers the builder's
spec_from_file_location shape with the real host project dependency bootstrap.

The original builder tests materialize real small native/worker contexts into
their own TemporaryDirectory, and the fake-command-runner test invokes the same
materializer. These are broader than receipt-only metadata tests. No real Docker
command, image build, model copy, wheel copy, installation or restore occurred.
The current exact five source/dependency manifest payloads are:

- native_probe_deepstream: 12 files, 424,685 bytes, zero wheel paths.
- native_probe_openvino: 17 files, 493,554 bytes, zero wheel paths.
- native_probe_savant: 14 files, 442,039 bytes, zero wheel paths.
- analytics_worker_openvino: 4 files, 76,030 bytes, zero wheel paths.
- analytics_worker_tensorrt: 5 files, 104,708 bytes, zero wheel paths.

Their combined payload is 1,541,016 bytes. Inspection of
_build_selected_image_v1 shows one context per image shared by its fake A/B
builds; the tests run sequentially. This is a static payload calculation, not
observed total temporary filesystem occupancy or a whole-chain peak admission.
Original automatic test-temporary cleanup completed as part of the successful
tests; no protected historical input or retained evidence was removed.

Fresh Windows observation after completion: C free 54,475,079,680 bytes, E free
167,698,563,072 bytes. The earlier meaningful receipt RED observed C free
54,486,302,720 bytes before/after. Neither is a continuous peak measurement or
capacity/recovery/package/genuine-consumer acceptance. The full renewal peak and
task1.5 remain open. Retain this resource-scope correction with the original run;
do not describe its report-output cap as its temporary staging peak.
