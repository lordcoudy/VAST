from pathlib import Path
import subprocess, json, hashlib, time, uuid, shutil, os
BASE=Path('E:/STUDY/VAST/tmp/completion-implementation-20261015/package-reader-bounded-01')
REPO=Path('C:/Users/s-a-balashov/.codex/worktrees/fix-accepted-policy-preprocessing/VAST')
TEST=REPO/'tests/test_publication_image_freeze_receipt_validation_v1.py'
RUNTIME='/home/s-a-balashov/.local/state/vast/publication/runtime/full-publication-cp312-v1/bin/python'
def sha(b):return hashlib.sha256(b).hexdigest()
def write(name,b):
 p=BASE/name
 assert not p.exists(),str(p)
 p.write_bytes(b)
 return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
assert not (BASE/'default-chain-red-02').exists()
before=shutil.disk_usage('C:/').free
assert before>=40*1024**3
assert sha((BASE/'execution-plan.v1.md').read_bytes())=='752b9a3786a1cd00444bdc1cb6111efa32a7babc65a3c701871f575e2fbb806f'
authority=BASE/'stock-authority.original'
pins=json.loads((BASE/'stock-authority.original.manifest.v1.json').read_bytes())
for row in pins['files']:
 assert sha((authority/row['path']).read_bytes())==row['sha256']
 assert sha((REPO/row['path']).read_bytes())==row['sha256']
test_sha=sha(TEST.read_bytes())
stage='/var/tmp/vast-package-reader-bounded-01-'+uuid.uuid4().hex
argv=['wsl','-d','Ubuntu','--','env',
      'VAST_PACKAGE_READER_STOCK=/mnt/e/STUDY/VAST/tmp/completion-implementation-20261015/package-reader-bounded-01/stock-authority.original',
      'VAST_PACKAGE_READER_STAGE='+stage,
      'VAST_PACKAGE_READER_REPORTS=/mnt/e/STUDY/VAST/tmp/completion-implementation-20261015/package-reader-bounded-01/default-chain-red-02',
      RUNTIME,'-I','-B',
      '/mnt/c/Users/s-a-balashov/.codex/worktrees/fix-accepted-policy-preprocessing/VAST/tests/test_publication_image_freeze_receipt_validation_v1.py',
      'PublicationImageFreezeReceiptValidationV1Tests.test_default_packaged_identity_patch_loads_without_host_builder','-v']
started=time.monotonic()
result=subprocess.run(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15*60,check=False)
elapsed=time.monotonic()-started
stdout=write('default-chain-red-02.unittest.original.stdout',result.stdout)
stderr=write('default-chain-red-02.unittest.original.stderr',result.stderr)
after=shutil.disk_usage('C:/').free
assert after>=40*1024**3 and elapsed<=15*60
assert sha(TEST.read_bytes())==test_sha
for row in pins['files']:
 assert sha((authority/row['path']).read_bytes())==row['sha256']
 assert sha((REPO/row['path']).read_bytes())==row['sha256']
case=BASE/'default-chain-red-02'
sources=json.loads((case/'staged-sources.original.v1.json').read_bytes())
assert sources['scripts_python_count']==87 and sources['scripts_python_bytes']==3873232
assert all(row['bytes']==0 and row['sha256']==sha(b'') for row in sources['sources'] if row['artificial_path_existence_input'])
prepare=json.loads((case/'prepare-default-chain.stdout.original').read_bytes())
chain=json.loads((case/'default-chain.stdout.original').read_bytes())
assert prepare['stock_read_verified'] and chain['outcome']=='error' and chain['unchanged_default_callback']
error=chain['error']
assert error['type']=='publication_qualification_image_refreeze_v1.QualificationImageRefreezeV1Error' and error['message']=='invalid native_probe image receipt'
assert error['cause']['type']=='builtins.FileNotFoundError' and error['cause']['message'].endswith("/scripts/publication_image_build_v1.py'")
assert result.returncode==1 and b'FAILED (failures=1)' in result.stderr and b'Ran 1 test' in result.stderr
staged=sum(row['bytes'] for row in sources['sources'])
control_bytes=sum(p.stat().st_size for p in BASE.rglob('*') if p.is_file())
assert staged<=8*1024**2 and control_bytes<=4*1024**2 and staged+control_bytes<=16*1024**2
record={'kind':'meaningful-original-default-receipt-chain-red.v1','author':'audit_capacity',
 'specification_approval':{'commit':'8840e2230c9dda560870774867b2ce38dc4fd2d8','PR9Comment':6180731892},
 'fixture_label':'artificial-physical-metadata-only','Verdict':'EXPECTED_RED','original_returncode':result.returncode,
 'tests_run':1,'failures':1,'errors':0,'elapsed_seconds':elapsed,'argv':argv,'native_stage':stage,
 'test_path':str(TEST),'test_sha256':test_sha,'stock_authority_manifest_sha256':sha((BASE/'stock-authority.original.manifest.v1.json').read_bytes()),
 'source_commit':'8840e2230c9dda560870774867b2ce38dc4fd2d8','original_stock_builder_blob':'7d0936cf1e631744b874b3d3fc1bfc4d8800af99',
 'original_stock_builder_sha256':'7a8d6cf67de32515cf330073f3933b7af4216e552c5d606e8a17df500cf7938a',
 'stock_fixture_assemble_and_real_reader_verified':True,'default_callback_unchanged':True,'nested_error':error,
 'C_free_before':before,'C_free_after':after,'C_floor_bytes':40*1024**3,'stage_source_bytes':staged,
 'control_bytes_before_final_record':control_bytes,'caps_bytes':{'stage':8*1024**2,'case':1024**2,'reports':4*1024**2,'total':16*1024**2},
 'original_subjects':[stdout,stderr],'original_source_and_stock_bytes_unchanged':True,
 'recovery_acceptance':False,'dependency_wheel_source_build_image_acceptance':False,
 'excluded_acceptance':['Full public fragment endpoint/task2.8','actual runtime images/task4.2','P1 correction/GREEN','genuine consumers','hardware/parity','capacity/recovery/image action'],
 'next_action':'Stop before production/COPY edits; root may extract only after evaluating preserved meaningful RED.', 'previous_case':'01 setup error retained as non-RED;02 uses separated physical and package trees.'}
row=write('default-chain-red-02.execution.original.v1.json',json.dumps(record,indent=2).encode()+b'\n')
print(json.dumps(row))
print(json.dumps({'returncode':result.returncode,'tests':1,'failures':1,'elapsed':elapsed,'stageSourceBytes':staged,'retainedControlBytes':control_bytes,'nativeStage':stage,'testSHA256':test_sha}))
