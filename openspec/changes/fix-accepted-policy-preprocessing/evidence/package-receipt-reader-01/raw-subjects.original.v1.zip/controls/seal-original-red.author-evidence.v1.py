from pathlib import Path
import json, hashlib, ast, datetime
BASE=Path('E:/STUDY/VAST/tmp/completion-implementation-20261015/package-reader-bounded-01')
TEST=Path('C:/Users/s-a-balashov/.codex/worktrees/fix-accepted-policy-preprocessing/VAST/tests/test_publication_image_freeze_receipt_validation_v1.py')
def sha(b):return hashlib.sha256(b).hexdigest()
def subject(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
execution=json.loads((BASE/'default-chain-red-04.execution.original.v1.json').read_bytes())
native=json.loads((BASE/'native-stage-source-and-metadata.catalog.readonly.v1.json').read_bytes())
sources=json.loads((BASE/'default-chain-red-04/staged-sources.original.v1.json').read_bytes())
chain=json.loads((BASE/'default-chain-red-04/default-chain.stdout.original').read_bytes())
prepare=json.loads((BASE/'default-chain-red-04/prepare-default-chain.stdout.original').read_bytes())
assert execution['tests_run']==execution['failures']==1 and execution['errors']==0 and prepare['stock_read_verified']
assert chain['error']['message']=='invalid native_probe image receipt' and chain['error']['cause']['type']=='builtins.FileNotFoundError'
assert sources['scripts_python_count']==87 and sources['scripts_python_bytes']==3873232
assert sources['isolated_package_python_count']==86 and sources['isolated_package_python_bytes']==3862375
assert sha((BASE/'test-receipt-reader.meaningful-red.original.v4.py').read_bytes())==execution['test_sha256']
def red_method(p):
 cls=next(n for n in ast.parse(p.read_bytes()).body if isinstance(n,ast.ClassDef))
 fn=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='test_default_packaged_identity_patch_loads_without_host_builder')
 return ast.dump(fn,include_attributes=False)
assert red_method(TEST)==red_method(BASE/'test-receipt-reader.meaningful-red.original.v4.py')
casebytes={}
for row in native:
 for v in row['files']:
  if '/metadata-cases/' in v['path']:
   name=v['path'].split('/metadata-cases/',1)[1].split('/',1)[0]
   casebytes[name]=casebytes.get(name,0)+v['bytes']
assert all(v<=1024**2 for v in casebytes.values())
controls_before=sum(p.stat().st_size for p in BASE.rglob('*') if p.is_file())
native_bytes=sum(row['bytes'] for row in native)
assert controls_before<=4*1024**2 and native_bytes+controls_before+TEST.stat().st_size<=16*1024**2
subjects=[subject(p) for p in sorted(BASE.rglob('*')) if p.is_file()]
report={
 'kind':'package-receipt-reader-original-red-author-evidence.v1','author':'audit_capacity',
 'Verdict':'MEANINGFUL_ORIGINAL_RED_RETAINED','RecordedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'authority':{'reviewedCommit':'8840e2230c9dda560870774867b2ce38dc4fd2d8','PR9DelegatedApprovalComment':6180731892,'task':'2.7'},
 'meaningfulRED':{'case':'04','execution':subject(BASE/'default-chain-red-04.execution.original.v1.json'),
  'executedTestSource':subject(BASE/'test-receipt-reader.meaningful-red.original.v4.py'),
  'stockFixturePhysicallyAssembledAndReadByOriginalStockAuthority':True,
  'entry':'publication_policy_qualification_fragment_validation_v2.DEFAULT_DEPENDENCIES.load_identity_patch',
  'unchangedDefaults':True,'freshIsolatedInterpreter':True,'originalUnittestReturncode':1,
  'testCount':1,'failures':1,'errors':0,'elapsedSeconds':execution['elapsed_seconds'],
  'nestedError':chain['error'],'loadedProjectModules':chain['loaded_project_modules'],
  'projectCodeSearchRoots':chain['project_search_roots'],
  'rawUnittestStderr':subject(BASE/'default-chain-red-04.unittest.original.stderr'),
  'rawDefaultChainStderr':subject(BASE/'default-chain-red-04/default-chain.stderr.original'),
  'rawDefaultChainReport':subject(BASE/'default-chain-red-04/default-chain.stdout.original'),
  'rawStockPrepareReport':subject(BASE/'default-chain-red-04/prepare-default-chain.stdout.original')},
 'retainedPreparationFailures':[
  {'case':'01','classification':'NOT_RED','reason':'Materializer absence assertion contradicted real source-allowlist membership;0tests/1setupERROR.',
   'evidence':subject(BASE/'default-chain-red-01.preparation-failure.original.v1.json')},
  {'case':'02','classification':'NOT_RED','reason':'Stock fixture-generation source authority lacked the real native custody module; package child not started.',
   'evidence':subject(BASE/'default-chain-red-02.preparation-failure.original.v1.json')},
  {'case':'03','classification':'NOT_RED','reason':'Full host fragment builder absent from runtime union; stock valid patch verified but wrong entry import prevented receipt-chain execution.',
   'evidence':subject(BASE/'default-chain-red-03.preparation-failure.original.v1.json')}],
 'sourceTrees':{'stockAuthority':subject(BASE/'stock-authority.original.manifest.v1.json'),
  'stockBuilderBlob':'7d0936cf1e631744b874b3d3fc1bfc4d8800af99','stockBuilderSHA256':'7a8d6cf67de32515cf330073f3933b7af4216e552c5d606e8a17df500cf7938a',
  'fourStockFunctionBytes':1416,'fourStockFunctionSHA256':'ee3983227737448ff600f4f6524cac336a51844e4f5f077f056052294849e201',
  'stagedManifest':subject(BASE/'default-chain-red-04/staged-sources.original.v1.json'),
  'physicalProjectScripts':{'count':87,'bytes':3873232,'actualMaterializerPresent':True},
  'isolatedCodeScripts':{'count':86,'bytes':3862375,'builderAbsent':True,'actualMaterializerAbsent':True},
  'actualMaterializerLiteral':'scripts/materialize_runtime_build_context_v3.py',
  'allRealRegistryAllowlistAndSmallSourceBytesPreserved':True,'physicalProjectOutsideActualPackageSearchRoots':True,
  'emptyWheelInputs':'Artificial empty single-link path-existence metadata only; no real wheel bytes copied, installed, or attested.',
  'unchangedTreesReusedAfterChangedPreparation':'Case02trees were hash-verified and reused for fresh03/04metadata to avoid copying8.27MiB again; baseline code bytes were never overwritten.',
  'nativeOriginalFileCatalog':subject(BASE/'native-stage-source-and-metadata.catalog.readonly.v1.json')},
 'authoredCurrentTests':{'subject':subject(TEST),'methods':4,'faithfulStockLeafCases':24,
  'redMethodASTUnchangedFromExecutedSource':True,'onlyExecutedMethod':'test_default_packaged_identity_patch_loads_without_host_builder',
  'notYetExecuted':['24-case stock/leaf value/error/cause/context/canonical/self-hash matrix','Outer descriptor/symlink/hardlink refusal checks','Host public/leaf shared callable identity'],
  'changesAfterRED':'Two matrix refusal inputs and canonical input formatting corrected; physical-project materializer presence asserted. Executed original source retained separately.'},
 'resources':{'nativeRetainedRoots':[{'path':v['root'],'bytes':v['bytes'],'files':len(v['files'])} for v in native],
  'nativeRetainedBytes':native_bytes,'EControlBytesBeforeThisManifest':controls_before,'worktreeTestBytes':TEST.stat().st_size,
  'totalBeforeThisManifest':native_bytes+controls_before+TEST.stat().st_size,'sourceStagingBytesPerCorrectTreePair':8269987,
  'caseMetadataBytes':casebytes,'capsBytes':{'stagedSources':8*1024**2,'perCase':1024**2,'reports':4*1024**2,'total':16*1024**2},
  'CFreeBeforeMeaningfulRED':execution['C_free_before'],'CFreeAfterMeaningfulRED':execution['C_free_after'],'CFloorBytes':40*1024**3,
  'childSeconds':60,'cohortSeconds':15*60,'meaningfulExecutionSeconds':execution['elapsed_seconds'],
  'fullNewTreeDoesNotFitRemainingTotalBudget':True},
 'changeScope':'Only assigned test file plus new ignored controls/owned tiny native fixture staging. No production/COPY/default/CI edit by this author.',
 'recovery_acceptance':False,'dependency_wheel_source_build_image_acceptance':False,
 'excludedAcceptance':['P1 correction or GREEN','Full public fragment endpoint/task2.8','Actual images/task4.2','genuine complete consumers','hardware/parity','whole-chain capacity','live recovery/image action'],
 'next':'Stop before production/COPY; root owns extraction and must independently review implementation/current source checks. New GREEN overlay/provenance/report plan must preserve all baselines and total16MiB.',
 'originalSubjectsBeforeThisManifest':subjects,
 'manifestAuthorSource':subject(Path(__file__).resolve())}
p=BASE/'package-receipt-reader-red.author-manifest.v1.json';assert not p.exists();b=json.dumps(report,indent=2).encode()+b'\n';p.write_bytes(b)
controls=sum(p.stat().st_size for p in BASE.rglob('*') if p.is_file())
assert native_bytes+controls+TEST.stat().st_size<=16*1024**2
print(json.dumps({'path':str(p),'bytes':len(b),'sha256':sha(b),'nativeBytes':native_bytes,'controlBytesAfterManifest':controls,'totalIncludingTestAfterManifest':native_bytes+controls+TEST.stat().st_size,'remainingTotalBytes':16*1024**2-native_bytes-controls-TEST.stat().st_size}))
