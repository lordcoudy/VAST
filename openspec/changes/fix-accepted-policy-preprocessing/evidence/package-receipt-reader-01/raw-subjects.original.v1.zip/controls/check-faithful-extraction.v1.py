"""Read-only stock-span and extraction boundary check; no project imports."""
import ast
import hashlib
import json
import sys
from pathlib import Path

root, stock, output = map(Path, sys.argv[1:4])
names = ("_require", "_canonical_json", "_receipt_sha256", "load_publication_image_freeze_receipt")
stock_bytes = (stock / "scripts/publication_image_build_v1.py").read_bytes()
assert hashlib.sha256(stock_bytes).hexdigest() == "7a8d6cf67de32515cf330073f3933b7af4216e552c5d606e8a17df500cf7938a"
leaf_path = root / "scripts/publication_image_freeze_receipt_validation_v1.py"
leaf_bytes = leaf_path.read_bytes()
stock_tree = ast.parse(stock_bytes)
leaf_tree = ast.parse(leaf_bytes)

def spans(payload, tree):
    lines = payload.decode("utf-8").splitlines(keepends=True)
    return {node.name: "".join(lines[node.lineno-1:node.end_lineno]).encode()
            for node in tree.body if isinstance(node, ast.FunctionDef)}

original = spans(stock_bytes, stock_tree)
extracted = spans(leaf_bytes, leaf_tree)
assert set(extracted) == set(names)
for name in names:
    assert extracted[name] == original[name], name
imports = sorted({node.module if isinstance(node, ast.ImportFrom) else alias.name
                  for node in ast.walk(leaf_tree) if isinstance(node, (ast.Import, ast.ImportFrom))
                  for alias in node.names})
assert imports == ["__future__", "hashlib", "json", "pathlib", "stat", "typing"]
builder_path = root / "scripts/publication_image_build_v1.py"
builder_bytes = builder_path.read_bytes()
builder_tree = ast.parse(builder_bytes)
assert not any(isinstance(node, ast.FunctionDef) and node.name == names[-1] for node in builder_tree.body)
assert any(isinstance(node, ast.ImportFrom) and node.module == "publication_image_freeze_receipt_validation_v1"
           and {alias.name for alias in node.names} == {"RECEIPT_KIND", names[-1]} for node in builder_tree.body)
refreeze_path = root / "scripts/publication_qualification_image_refreeze_v1.py"
refreeze_bytes = refreeze_path.read_bytes()
refreeze_tree = ast.parse(refreeze_bytes)
assert not any(isinstance(node, ast.FunctionDef) and node.name == "_load_build_module" for node in refreeze_tree.body)
assert b"importlib" not in refreeze_bytes
old_refreeze_bytes = (stock / "scripts/publication_qualification_image_refreeze_v1.py").read_bytes()
old_refreeze = spans(old_refreeze_bytes, ast.parse(old_refreeze_bytes))["_load_build_receipt"]
new_refreeze = spans(refreeze_bytes, refreeze_tree)["_load_build_receipt"]
assert new_refreeze == old_refreeze.replace(b"_load_build_module().load_publication_image_freeze_receipt(physical)", b"load_publication_image_freeze_receipt(physical)")
groups = (("deploy/deepstream/checkpoint", "Dockerfile.runtime"),
          ("deploy/savant/publication", "Dockerfile"),
          ("deploy/openvino_gva/publication", "Dockerfile"),
          ("deploy/gstreamer_custom/publication", "Dockerfile"))
target = "scripts/" + leaf_path.name
packages = []
for directory, dockerfile in groups:
    manifest = (root / directory / "runtime-source-allowlist.txt").read_text().splitlines()
    docker = (root / directory / dockerfile).read_text()
    assert manifest.count(target) == 1
    assert docker.count(target) == 1
    assert "scripts/publication_image_build_v1.py" not in docker
    assert "scripts/materialize_runtime_build_context_v3.py" not in docker
    packages.append(directory)
result = {"outcome": "CLEAR", "stock_builder_sha256": hashlib.sha256(stock_bytes).hexdigest(),
          "exact_function_bytes": sum(len(original[name]) for name in names),
          "function_sha256": {name: hashlib.sha256(original[name]).hexdigest() for name in names},
          "leaf_sha256": hashlib.sha256(leaf_bytes).hexdigest(), "leaf_bytes": len(leaf_bytes),
          "builder_sha256": hashlib.sha256(builder_bytes).hexdigest(),
          "refreeze_sha256": hashlib.sha256(refreeze_bytes).hexdigest(),
          "stdlib_imports": imports, "four_package_groups": packages,
          "physical_package_or_recovery_acceptance": False}
with output.open("x", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2, sort_keys=True)
    stream.write("\n")
print(json.dumps(result, sort_keys=True))
