# Proposed bounded GREEN source view and verification

Authority remains PR9 comment6180731892 at8840 for D8/task2.7. This is a
reviewable execution plan, not a GREEN result or full2.8/4.2/5.3 acceptance.
Author: audit_capacity; production extraction is owned by root. No GREEN has run.

## Retained original and new source identities

Meaningful original RED04: execution SHA256
1d122d01321281a2dcaa92352294e24700a086083cfa7b396221d54addc43078;
executed test source70c85e80753b5f8abe4ca3ce42a45c45f684535bc19b9ecfba9ceafe659d6479.
The separate author manifestde2d77e8f1882b6b664532ac7a6e34f1ae7dc118c76197339691195f38f68064
retains the stock builder, original1416-byte closure, exact source trees and raw
outputs. Cases01/02/03 are preparation failures, never meaningful RED evidence.

Immutable GREEN input manifest `green-overlay.pinned-inputs.original.v2.json`,
SHA25629f21adbbf53c167b7e342c8fa4c6f0c2dbcbb6b352b594b927b969033e7d75e,
pins copies of exactly two current production sources under ignored controls:

- new leaf1677B, f1f674a644ec0ac7b1e652fdb5736945be876a792160d41de15aa9a53cdacf03;
- changed refreeze65306B,8f3a01748576aa887531393467a9aa225aacc0d7615361e21588b4df7fc7ca24.

The proposed tracked test is34712B, SHA256
b955a37746e13cb7603ef617531966ca622b7b0a539be00f5925733d317fdafe.
Exact diff from preserved pre-GREENv5 is
`green-test-infrastructure.proposed.v2.diff`, SHA256
d761abd66d9557abe08bc2e37346c4ac7ca93bd6ddf9429a424f7160ca02dac0.
Its original source snapshot is `test-receipt-reader.green-proposed.original.v7.py`.

## One effective source-code root

Reuse only the02 source trees as verified immutable inputs. Keep the physical
project's87scripts/3873232B and all exact real registry/allowlist/small source
bytes. Its materializer exists as build-input data outside interpreter search.
Retain the separate86-script/3862375B original package baseline unchanged.

Create one fresh exclusive native `green-code-view-01/scripts` directory under
that owned02 namespace. Its exact87members are85natural symlinks to unchanged
owned native baseline files, plus physical copies of the new leaf and changed
refreeze. Replace only the view entry for old refreeze; never overwrite the
baseline. Builder and actual materializer must be absent, including dangling
links. No host fragment-builder source is added.

Each link must resolve to its exact absolute baseline path and SHA256, with the
original target still single-link. The two physical files must match the sealed
source sizes/hashes and remain single-link. Verify all entries before and after
the cohort. Link creation changes no baseline inode, mode, link count or bytes.

The fresh -I -B child adds exactly this effective project-code directory to its
ordinary interpreter path. It must receive the physical project separately as
metadata, with no physical-project, host checkout or sealed-stock search path.
No __file__, loader, production default, validator or module-cache override is
used. Natural import paths stay in the one effective root. For each observed
project module, record its lexical __file__, resolved provenance and SHA256.
The revised loaded() predicate explicitly checks the sealed view manifest:
lexical path in the effective root; resolved path exactly the pinned native
baseline for links or the physical view file for replacements; exact hash.
It does not accept arbitrary paths outside the effective root.

This is a source-only view. Symlinks do not establish actual runtime-image
membership or package physical-custody acceptance. The four final Docker COPY
sets' independently reviewed materializer exclusion is a separate inventory
disposition; existing BUILD_ONLY/context entries remain untouched.

## Finite execution and truthful authority labels

Run the one new unittest class once (four methods), using the existing cp312
runtime and a fresh report directory and metadata-case suffix. Every child uses
-I -B, at most60seconds and the remaining cohort budget; outer execution is
bounded to15minutes. A child timeout retains partial raw output and a timeout
receipt, then fails; no retry occurs. Preserve every failure and original RED.

1. The preserved stock source authority independently assembles and reads a
   fresh valid physical patch. Its separate process may search the sealed stock
   authority followed by the original physical87-script input tree for native
   custody. This never supplies code to the actual package child. The actual
   package child invokes the unmodified packaged fragment-validation leaf's
   DEFAULT_DEPENDENCIES.load_identity_patch and must return the exact patch.
2. Compare stock1416-byte closure versus the actual new leaf in separate fresh
   interpreters for24cases: canonical/noncanonical/Unicode; stock bool/float
   schema equality and images-element quirks; foreign/missing kind/schema,
   schema string, missing/wrong/nonstring self-hash, wrong/missing images,
   nonobject JSON, NaN canonical refusal, malformed JSON/encoding, absent file,
   directory, symlink and hardlink. Compare complete returned values or exact
   error type/message/cause/context/suppression, canonical bytes and self-hash.
3. Preserve existing outer descriptor, symlink and hardlink refusals on separate
   freshly assembled valid patches; original patch bytes remain unchanged.
4. In a separate fresh host-source child, deliberately bootstrap only the real
   ROOT/scripts source path. Load the canonical builder and its ordinary
   spec_from_file_location alias, and assert both public readers are the leaf's
   same callable. Verify shared fragment dependency objects. This explicit host
   source bootstrap is distinct from the isolated package path and suite caches.

Fixture generation now reports reader_verified separately from stock_read_verified.
The latter is true only when the actually used builder/refreeze hashes match
the preserved stock pins. Ordinary CI using patched ROOT says current-production;
it cannot claim preserved-stock generation. The differential reader reference
always remains the exact sealed original1416-byte closure.

## Cumulative resource accounting

Retained native01/02trees currently total12735665B, including all earlier failed
metadata. The last sealed cumulative total including controls/test was13520039B;
new source pins, plans, test snapshots, root extraction/adjacent controls and the
independent static review must also be charged before execution.

Limits remain8MiB staged source payload/metadata,1MiB per metadata case,4MiB
reports/controls and16MiB total retained new contents/metadata. The effective view
adds66983B of physical source payload plus symlink target-string bytes; it does
not copy or re-charge existing target payload as newly retained content. Record
the view's logical exposed source size separately. The source guard charges the
existing8269987B correct-tree pair plus each new view entry's lstat size against
8MiB. All original native roots, full bounded control root, live test and the
external static-review controls are counted in the16MiB retained counter.

The explicit external review allocation is819200B under
`dependency-inventory-integrated-01/d8-working-review-01`; it is checked separately
and included in the4MiB report and16MiB total counters without overlap. Count the
root's new faithful-extraction and adjacent-unit-check controls in the bounded
root. The latter original36/36run is broader than receipt-only execution: static
review identifies1541016B aggregate native/worker context payload, no wheels or
real Docker/build/model calls, sequential contexts. This is static transient
payload, not a measured staging peak, and remains separately disclosed.

Observe actual Windows C>=40GiB immediately before any GREEN writes and after.
Report raw byte accounting separately from filesystem allocation/backing gain;
there is no whole-chain capacity acceptance. If any cap/pin/input/closure fails,
retain it and stop. Do not delete originals or repeat unchanged failed setup.

## Retained exclusions and coordination

Review this exact plan and test diff before running GREEN. Freeze new source
pins before the command. Retain all raw child/controller/unittest outputs,
link provenance, source before/after checks, caps and exact runtime identities.
No installation, wheel/model/data/image/TAR copy, Docker query/build, assessment,
parity, live recovery, image action or source-side handoff backup read is included.
Even a fully GREEN result does not complete the full public fragment endpoint,
actual-image4.2, genuine consumers5.3, capacity1.5, conformance/archive or acceptance.
