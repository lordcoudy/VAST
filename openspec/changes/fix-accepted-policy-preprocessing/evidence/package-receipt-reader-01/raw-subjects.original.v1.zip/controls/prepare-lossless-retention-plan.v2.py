"""Append-only v2 forecast with actual source-commit/Git-blob bindings."""
from pathlib import Path

base = Path('E:/STUDY/VAST/tmp/completion-implementation-20261015/package-reader-bounded-01')
program = (base / 'prepare-lossless-retention-plan.v1.py').read_text()
program = program.replace('same-pr-retention.lossless.plan.proposed.v1.json', 'same-pr-retention.lossless.plan.proposed.v2.json')
program = program.replace('same-pr-retention.lossless.catalog.proposed.v1.json', 'same-pr-retention.lossless.catalog.proposed.v2.json')
binding = '''
commit = 'e583ae4ac22ac660f280f45badc2a39c96d21c37'
def git(*args):
    return subprocess.run(['git', '-c', 'core.fsmonitor=false', '-C', str(REPO), *args],
        stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        timeout=30, check=True).stdout
assert git('rev-parse', 'HEAD').decode().strip() == commit
parents = git('rev-list', '--parents', '-n', '1', commit).decode().split()
assert len(parents) == 2 and parents[1].startswith('0cc262d0')
changed = [p.decode() for p in git('diff-tree', '--no-commit-id', '--name-only', '-z', '-r', commit).split(b'\\0') if p]
assert len(changed) == 12
rows = []
for relative in changed:
    raw = git('show', commit + ':' + relative)
    assert (REPO / relative).read_bytes() == raw
    blob = git('rev-parse', commit + ':' + relative).decode().strip()
    assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\\0' + raw).hexdigest() == blob
    rows.append({'path': relative, 'gitBlobSHA1': blob, 'bytes': len(raw), 'sha256': sha(raw)})
binding = {'commit': commit, 'parent': parents[1], 'changedPaths': rows,
           'physicalBytesEqualAll12CommitBlobs': True, 'newCIOrApprovalNotInferred': True}
'''
program = program.replace('entries = []\npayloads = {}', binding + '\nentries = []\npayloads = {}', 1)
program = program.replace("'kind': 'package-reader-lossless-raw-subject-catalog.v1',", "'kind': 'package-reader-lossless-raw-subject-catalog.v1', 'sourceBinding': binding,", 1)
program = program.replace("'kind': 'package-reader-lossless-retention-plan.v1',", "'kind': 'package-reader-lossless-retention-plan.v1', 'sourceBinding': binding,", 1)
program = program.replace('controls = tree_bytes(BASE)', '''readme += b'\\nSource-only commit e583ae4ac22ac660f280f45badc2a39c96d21c37 is bound by\\ntwelve exact Git blobs and physical-byte hashes. Its test43cdfd8d has not run\\nlocally; original GREEN4a1f91 remains historical behavior only. Exact-commit\\nhosted CI and recorded delegated approval remain required.\\n'
controls = tree_bytes(BASE)''', 1)
exec(compile(program, str(base / 'prepare-lossless-retention-plan.v1.py'), 'exec'))
