from pathlib import Path
import hashlib,difflib,ast,json
BASE=Path('E:/STUDY/VAST/tmp/completion-implementation-20261015/package-reader-bounded-01')
TEST=Path('C:/Users/s-a-balashov/.codex/worktrees/fix-accepted-policy-preprocessing/VAST/tests/test_publication_image_freeze_receipt_validation_v1.py')
original=TEST.read_text(encoding='utf-8')
assert hashlib.sha256(original.encode()).hexdigest()=='4a1f91ab36979154b022328926a6cf00235399c7e300198a32dd861433fa133b'
new=original.replace('from pathlib import Path\n\n\nROOT', 'from pathlib import Path\nfrom unittest import mock\n\n\nROOT',1)
new=new.replace('''        if retained:
            cls.directory = Path(retained)
            if reused:
                assert cls.directory.is_dir()
            else:
                cls.directory.mkdir(exist_ok=False)
''','''        if retained:
            cls.directory = Path(retained)
''',1)
needle='''        cls.project = cls.directory / "physical-project"
'''
replacement='''        cls.controls = Path(os.environ.get("VAST_PACKAGE_READER_REPORTS", str(cls.directory / "reports")))
        assert not reused or cls.overlay_pin, "reused sources require retained-root pin"
        cls._guard_source_allocation(0)
        if retained:
            if reused:
                assert cls.directory.is_dir()
            else:
                cls.directory.mkdir(exist_ok=False)
        cls.project = cls.directory / "physical-project"
'''
assert needle in new;new=new.replace(needle,replacement,1)
needle='''        cls.controls = Path(os.environ.get("VAST_PACKAGE_READER_REPORTS", str(cls.directory / "reports")))
        cls.controls.mkdir(exist_ok=False)
'''
assert needle in new;new=new.replace(needle,'''        cls.controls.mkdir(exist_ok=False)
''',1)
needle='''        cls.sources = []
        if reused:
'''
replacement='''        cls.sources = []
        if not reused:
            anticipated = 0
            for relative in paths:
                size = 0 if relative.endswith(".whl") else (ROOT / relative).stat().st_size
                anticipated += size
                if relative.startswith("scripts/") and relative.endswith(".py") and Path(relative).name != MATERIALIZER_NAME:
                    anticipated += size
            cls._guard_source_allocation(anticipated)
        if reused:
'''
assert needle in new;new=new.replace(needle,replacement,1)
new=new.replace('''            destination.write_bytes(content)
''','''            cls._write_staged_source(destination, content)
''',1)
new=new.replace('''                packaged.write_bytes(content)
''','''                cls._write_staged_source(packaged, content)
''',1)
needle='''            (view / "scripts").mkdir(parents=True, exist_ok=False)
            replacements = {row["path"]: row for row in cls.overlay_pin["source_files"]}
'''
replacement='''            replacements = {row["path"]: row for row in cls.overlay_pin["source_files"]}
            assert view.name.startswith("green-code-view-") and view.name == cls.overlay_pin["view_name"]
            anticipated_view = sum(row["bytes"] for row in replacements.values()) + sum(
                len(os.fsencode(str((baseline / row["path"]).absolute()))) for row in cls.sources
                if row["tree"] == "packaged-source" and row["path"] not in replacements)
            cls._guard_source_allocation(anticipated_view)
            (view / "scripts").mkdir(parents=True, exist_ok=False)
'''
assert needle in new;new=new.replace(needle,replacement,1)
new=new.replace('''                link.symlink_to(target.absolute())
''','''                cls._guard_source_allocation(len(os.fsencode(str(target.absolute()))))
                link.symlink_to(target.absolute())
''',1)
new=new.replace('''                path.write_bytes(content)
                file_rows.append''','''                cls._write_staged_source(path, content)
                file_rows.append''',1)
needle='''    @classmethod
    def _check_caps(cls) -> None:
'''
helpers='''    @classmethod
    def _retained_source_bytes(cls) -> int:
        roots = [Path(path) for path in cls.overlay_pin["retained_native_roots"]] if cls.overlay_pin else [cls.directory]
        assert len(roots) == len(set(roots)) and cls.directory in roots
        total = 0
        for root in roots:
            if not root.exists():
                assert root == cls.directory and not os.environ.get("VAST_PACKAGE_READER_REUSE_SOURCES"), "retained source root missing"
                continue
            assert root.is_dir() and not root.is_symlink(), "retained source root changed"
            for subtree in root.iterdir():
                # "package" is the failed01 legacy source tree, never omitted.
                if subtree.name not in {"package", "physical-project", "packaged-source"} and not subtree.name.startswith("green-code-view-"):
                    continue
                for path in subtree.rglob("*"):
                    parts = path.relative_to(subtree).parts
                    if subtree.name == "physical-project" and parts[0] in {"metadata-cases", "reader-cases"}:
                        continue
                    if path.is_file() or path.is_symlink():
                        total += path.lstat().st_size
        return total

    @classmethod
    def _guard_source_allocation(cls, additional_bytes: int) -> None:
        assert isinstance(additional_bytes, int) and additional_bytes >= 0
        used = cls._retained_source_bytes()
        assert used + additional_bytes <= 8 * 1024 * 1024, (
            f"cumulative staged source cap exceeded: {used}+{additional_bytes}")
        cls._check_caps(additional_bytes=additional_bytes)

    @classmethod
    def _write_staged_source(cls, path: Path, content: bytes) -> None:
        cls._guard_source_allocation(len(content))
        with path.open("xb") as destination:
            destination.write(content)

    @classmethod
    def _check_caps(cls, *, additional_bytes: int = 0) -> None:
'''
assert needle in new;new=new.replace(needle,helpers,1)
new=new.replace('''        assert total <= 16 * 1024 * 1024, "cohort cap exceeded"
''','''        assert total + additional_bytes <= 16 * 1024 * 1024, "cohort cap exceeded"
''',1)
needle='''    def test_default_packaged_identity_patch_loads_without_host_builder(self) -> None:
'''
test='''    def test_retained_source_counter_covers_all_roots_and_link_bytes(self) -> None:
        # Tiny accounting metadata only: these files are never imported as sources.
        self._check_caps(additional_bytes=1024)
        fixture = self.controls / "source-counter-contract"
        old, current = fixture / "retained-a", fixture / "retained-b"
        rows = [
            (old / "package/old.py", b"old"),
            (current / "physical-project/input.py", b"input"),
            (current / "packaged-source/shared.py", b"shared!"),
            (current / "green-code-view-contract/scripts/new.py", b"view"),
            (current / "physical-project/metadata-cases/case.json", b"excluded-case"),
            (current / "physical-project/reader-cases/case.json", b"excluded-reader"),
        ]
        for path, data in rows:
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("xb") as output:
                output.write(data)
        link = current / "green-code-view-contract/scripts/shared.py"
        link.symlink_to((current / "packaged-source/shared.py").absolute())
        expected = 19 + link.lstat().st_size
        with mock.patch.object(type(self), "directory", current), mock.patch.object(
                type(self), "overlay_pin", {"retained_native_roots": [str(old), str(current)]}):
            self.assertEqual(self._retained_source_bytes(), expected)
            missing = fixture / "declared-missing"
            type(self).overlay_pin["retained_native_roots"].append(str(missing))
            with self.assertRaisesRegex(AssertionError, "retained source root missing"):
                self._retained_source_bytes()
        self.assertLessEqual(sum(path.lstat().st_size for path in fixture.rglob("*")
                                 if path.is_file() or path.is_symlink()), 1024)
        self._check_caps()

    def test_cumulative_source_guard_refuses_before_a_new_write(self) -> None:
        destination = self.project / "forbidden-staging-write.py"
        with mock.patch.object(type(self), "_retained_source_bytes", return_value=12_677_599):
            with self.assertRaisesRegex(AssertionError, "cumulative staged source cap exceeded"):
                self._write_staged_source(destination, b"x")
        self.assertFalse(destination.exists())

'''
assert needle in new;new=new.replace(needle,test+needle,1)
ast.parse(new)
diff=''.join(difflib.unified_diff(original.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='preserved-behavioral-green-4a1f91',tofile='prospective-cumulative-guard'))
p=BASE/'cumulative-source-guard.proposed.v4.diff';assert not p.exists();p.write_text(diff,encoding='utf-8')
print(json.dumps({'diff':str(p),'diffBytes':p.stat().st_size,'diffSHA256':hashlib.sha256(p.read_bytes()).hexdigest(),'prospectiveTestBytes':len(new.encode()),'prospectiveTestSHA256':hashlib.sha256(new.encode()).hexdigest(),'applied':False,'testsRun':False}))
