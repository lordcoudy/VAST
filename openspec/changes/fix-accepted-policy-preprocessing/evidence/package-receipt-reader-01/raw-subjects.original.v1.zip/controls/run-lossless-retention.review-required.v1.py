"""Run only after independent exact-plan CLEAR and root authorization."""
from pathlib import Path, PurePosixPath
import ctypes
import datetime
import hashlib
import io
import json
import os
import stat
import subprocess
import zipfile

BASE = Path('E:/STUDY/VAST/tmp/completion-implementation-20261015/package-reader-bounded-01')
PLAN_PATH = BASE / 'same-pr-retention.lossless.plan.proposed.v2.json'
CATALOG_PATH = BASE / 'same-pr-retention.lossless.catalog.proposed.v2.json'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encode(value):
    return json.dumps(value, separators=(',', ':'), ensure_ascii=False).encode() + b'\n'


def size(root):
    return sum(p.lstat().st_size for p in root.rglob('*') if p.is_file() or p.is_symlink())


def main():
    import sys
    assert len(sys.argv) == 2 and len(sys.argv[1]) == 64, 'Pass the independently reviewed plan SHA256.'
    plan_raw = PLAN_PATH.read_bytes()
    assert sha(plan_raw) == sys.argv[1]
    plan = json.loads(plan_raw)
    catalog_raw = CATALOG_PATH.read_bytes()
    assert len(catalog_raw) == plan['catalogBytes'] and sha(catalog_raw) == plan['catalogSHA256']
    catalog = json.loads(catalog_raw)
    target = Path(plan['target'])
    assert not target.exists()
    roots = {kind: Path(path) for kind, path in catalog['sourceRoots'].items()}
    roots['P'] = Path('//wsl.localhost/Ubuntu' + catalog['sourceRoots']['P'])
    repo = roots['W']
    os.environ['GIT_OPTIONAL_LOCKS'] = '0'
    git = lambda *args: subprocess.run(
        ['git', '-c', 'core.fsmonitor=false', '-C', str(repo), *args],
        stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        timeout=30, check=True).stdout
    assert git('rev-parse', 'HEAD').decode().strip() == plan['sourceBinding']['commit']
    for row in plan['sourceBinding']['changedPaths']:
        raw = (repo / row['path']).read_bytes()
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
    excluded = {PLAN_PATH, CATALOG_PATH}
    result_source = BASE / plan['generatedResult']['sourceName']
    assert not result_source.exists()
    for kind in ('C', 'R'):
        actual = {p.relative_to(roots[kind]).as_posix() for p in roots[kind].rglob('*')
                  if p.is_file() and p not in excluded}
        expected = {row[2] for row in catalog['entries'] if row[1] == kind}
        assert actual == expected, 'Control scope drift: prepare/review a new plan.'
    payloads = {}
    for name, kind, relative, count, digest in catalog['entries']:
        assert not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
        assert '\\' not in name and '\0' not in name and ':' not in name
        assert not PurePosixPath(relative).is_absolute() and '..' not in PurePosixPath(relative).parts
        path = roots[kind] / relative
        assert path.is_file() and not path.is_symlink()
        raw = path.read_bytes()
        assert len(raw) == count and sha(raw) == digest, 'Raw subject drift.'
        payloads[name] = raw
    assert len(payloads) == len(catalog['entries'])
    memory = io.BytesIO()
    with zipfile.ZipFile(memory, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, raw in sorted(payloads.items()):
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | 0o644) << 16
            archive.writestr(info, raw, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    archive_raw = memory.getvalue()
    assert len(archive_raw) == plan['archive']['bytes'] and sha(archive_raw) == plan['archive']['sha256']
    native_roots = [row[0] for row in plan['resourceForecast']['nativeRetained']]
    query = ('import json;from pathlib import Path;roots=' + repr(native_roots) +
             ';print(json.dumps([[r,sum(p.lstat().st_size for p in Path(r).rglob("*") '
             'if p.is_file() or p.is_symlink())] for r in roots]))')
    native = json.loads(subprocess.run(
        ['wsl.exe', '-d', 'Ubuntu', '--exec', '/usr/bin/python3', '-I', '-B', '-c', query],
        stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        timeout=30, check=True).stdout)
    assert native == plan['resourceForecast']['nativeRetained']
    test = Path(plan['test'][0])
    assert test.stat().st_size == plan['test'][1] and sha(test.read_bytes()) == plan['test'][2]
    current = sum(row[1] for row in native) + size(roots['C']) + size(roots['R']) + test.stat().st_size
    forecast = plan['resourceForecast']
    assert current == forecast['currentBeforePlan'] + len(plan_raw) + len(catalog_raw)
    assert forecast['forecastGlobalRetained'] <= 16777216
    assert forecast['forecastReportControls'] <= 4194304
    assert size(roots['R']) <= 819200
    samples = [target / plan['archive']['path'], target / plan['catalogTarget'],
               target / plan['planTarget'], target / 'README.md', target / 'retention-result.v1.json']
    archive_prefix = repo / 'openspec/changes/archive/2026-10-15-fix-accepted-policy-preprocessing/evidence/package-receipt-reader-01'
    attr_paths = [p.relative_to(repo).as_posix() for p in samples] + [
        (archive_prefix / p.name).relative_to(repo).as_posix() for p in samples]
    attrs = git('check-attr', '-z', 'text', '--', *attr_paths).decode().split('\0')
    assert all(attrs[i + 1:i + 3] == ['text', 'unset'] for i in range(0, len(attrs) - 1, 3))
    available = ctypes.c_ulonglong()
    assert ctypes.windll.kernel32.GetDiskFreeSpaceExW('C:\\', ctypes.byref(available), None, None)
    new_target_max = len(archive_raw) + len(catalog_raw) + len(plan_raw) + plan['generatedREADME']['bytes'] + plan['generatedResult']['maxBytesEach']
    assert available.value - new_target_max >= 40 * 1024**3
    readme = plan['generatedREADME']['utf8Text'].encode()
    assert len(readme) == plan['generatedREADME']['bytes'] and sha(readme) == plan['generatedREADME']['sha256']
    outputs = {
        plan['archive']['path']: archive_raw, plan['catalogTarget']: catalog_raw,
        plan['planTarget']: plan_raw, 'README.md': readme,
    }
    target.mkdir(exist_ok=False)
    for name, raw in outputs.items():
        with (target / name).open('xb') as output:
            output.write(raw)
        assert (target / name).read_bytes() == raw
    with zipfile.ZipFile(target / plan['archive']['path']) as archive:
        assert len(archive.infolist()) == len(catalog['entries'])
        for name, raw in payloads.items():
            assert archive.read(name) == raw
    for name, kind, relative, count, digest in catalog['entries']:
        raw = (roots[kind] / relative).read_bytes()
        assert len(raw) == count and sha(raw) == digest, 'Original changed during retention.'
    native_after = json.loads(subprocess.run(
        ['wsl.exe', '-d', 'Ubuntu', '--exec', '/usr/bin/python3', '-I', '-B', '-c', query],
        stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        timeout=30, check=True).stdout)
    assert native_after == native
    metadata = catalog['physicalNamespaceOriginal']
    rows = metadata['relationships']
    metadata_query = ('import json,stat;from pathlib import Path;root=Path(' + repr(metadata['root']) +
                      ');rows=' + repr(rows) + ';out=[]\n'
                      'for row in rows:\n'
                      ' p=root/row[0];s=p.lstat();out.append([row[0],s.st_size,s.st_mode,s.st_dev,s.st_ino,s.st_nlink,'
                      'str(p.readlink()) if stat.S_ISLNK(s.st_mode) else None])\n'
                      'print(json.dumps(out))')
    metadata_after = json.loads(subprocess.run(
        ['wsl.exe', '-d', 'Ubuntu', '--exec', '/usr/bin/python3', '-I', '-B', '-c', metadata_query],
        stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        timeout=30, check=True).stdout)
    assert metadata_after == [[r[0], r[1], r[3], r[4], r[5], r[6], r[7]] for r in rows]
    result = {
        'kind': 'package-reader-lossless-retention-result.v1',
        'UTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'sourceCommit': plan['sourceBinding']['commit'], 'planSHA256': sha(plan_raw),
        'catalogSHA256': sha(catalog_raw), 'archiveSHA256': sha(archive_raw),
        'sourceEntries': len(payloads), 'everyRawEntryReadbackExact': True,
        'plainTargetReadbacksExact': True, 'CFreeBefore': available.value,
        'globalForecastIncludingBothResultReserves': forecast['forecastGlobalRetained'],
        'target': str(target),
        'targetSubjects': [[name, len(raw), sha(raw)] for name, raw in outputs.items()],
        'nativeRootSizesBeforeAndAfterEqual': native_after,
        'everyOriginalRawSubjectBytesUnchangedAfterWrite': True,
        'physicalMetadataLstatAndLinkRelationsMatchOriginalCatalogAfterWrite': True,
        'physicalCustodyOrTopologyReconstruction': False,
        'historicalSourceConformance': 'FAILED_BLOCK_UNCHANGED',
        'freshImplementedCommitHostedCIOrTaskClosureAcceptance': False,
        'testOrSourceExecution': False, 'imageDaemonOrGitMutation': False,
        'recovery_acceptance': False,
    }
    result_raw = encode(result)
    assert len(result_raw) <= plan['generatedResult']['maxBytesEach']
    for path in (result_source, target / plan['generatedResult']['targetName']):
        with path.open('xb') as output:
            output.write(result_raw)
        assert path.read_bytes() == result_raw
    actual_global = sum(row[1] for row in native) + size(BASE) + size(roots['R']) + test.stat().st_size + size(target)
    assert actual_global <= 16777216
    assert size(BASE) + size(roots['R']) + size(target) <= 4194304
    print(json.dumps({'result': str(result_source), 'resultBytes': len(result_raw),
                      'resultSHA256': sha(result_raw), 'actualGlobalBytes': actual_global,
                      'targetFiles': len(outputs) + 1, 'sourceEntries': len(payloads)}))


if __name__ == '__main__':
    main()
