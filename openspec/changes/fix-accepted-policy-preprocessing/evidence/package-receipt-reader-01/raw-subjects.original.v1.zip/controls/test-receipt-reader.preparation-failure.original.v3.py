from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
LEAF_NAME = "publication_image_freeze_receipt_validation_v1"
BUILDER_NAME = "publication_image_build_v1.py"
MATERIALIZER_NAME = "materialize_runtime_build_context_v3.py"
RECEIPT_KIND = "vast_publication_image_freeze_receipt_v1"
STOCK_BUILDER_SHA256 = "7a8d6cf67de32515cf330073f3933b7af4216e552c5d606e8a17df500cf7938a"
STOCK_FUNCTION_SHA256 = "ee3983227737448ff600f4f6524cac336a51844e4f5f077f056052294849e201"
STOCK_READER_SOURCE = '''def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)
def _canonical_json(value: object) -> bytes:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    ).encode("ascii")
def _receipt_sha256(payload: Mapping[str, object]) -> str:
    unsigned = dict(payload)
    unsigned.pop("receipt_sha256", None)
    return hashlib.sha256(_canonical_json(unsigned)).hexdigest()
def load_publication_image_freeze_receipt(path: Path) -> dict[str, object]:
    receipt_path = Path(path)
    info = receipt_path.lstat()
    _require(stat.S_ISREG(info.st_mode) and not receipt_path.is_symlink() and int(info.st_nlink) == 1, "producer receipt must be a physical single-link file")
    try:
        data = json.loads(receipt_path.read_bytes())
    except (UnicodeError, json.JSONDecodeError) as error:
        raise ValueError("producer receipt is not valid JSON") from error
    _require(isinstance(data, dict) and data.get("artifact_kind") == RECEIPT_KIND and data.get("schema_version") == 1, "producer receipt envelope drifted")
    _require(type(data.get("receipt_sha256")) is str and data["receipt_sha256"] == _receipt_sha256(data), "producer receipt self-identity drifted")
    _require(isinstance(data.get("images"), list), "producer receipt images are invalid")
    return data
'''


def _canonical(value: object) -> bytes:
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=True,
        allow_nan=False,
    ).encode("ascii")


def _signed(value: dict[str, object]) -> dict[str, object]:
    result = dict(value)
    result.pop("receipt_sha256", None)
    result["receipt_sha256"] = hashlib.sha256(_canonical(result)).hexdigest()
    return result


# These children use real read-only production functions. No build/capture,
# Docker, parity, assessment or dependency substitution is involved.
PREPARE_CHILD = r'''
import hashlib, json, sys
from pathlib import Path
authority, project, directory = map(Path, sys.argv[1:4])
sys.path.insert(0, str(authority / "scripts"))
# Native physical custody's pure source closure lives in the preserved input
# tree. This fixture-generation process is separate from the packaged child.
sys.path.append(str(project / "scripts"))
import publication_qualification_image_refreeze_v1 as refreeze
directory.mkdir(exist_ok=False)
def emit(name, value):
    path = directory / name
    path.write_bytes(refreeze._canonical(value) + b"\n")
    return path
build_sha = hashlib.sha256((project / refreeze.BUILD_REGISTRY_RELATIVE_PATH).read_bytes()).hexdigest()
registry_sha = hashlib.sha256((project / refreeze.REGISTRY_RELATIVE_PATH).read_bytes()).hexdigest()
def producer(group, images):
    value = {"artifact_kind": refreeze.BUILD_RECEIPT_KIND, "schema_version": 1,
             "group": group, "registry_path": refreeze.BUILD_REGISTRY_RELATIVE_PATH,
             "registry_sha256": build_sha, "images": images}
    value["receipt_sha256"] = refreeze.self_sha256(value, "receipt_sha256")
    return value
native_ids = {"native_probe_deepstream": "sha256:" + "1" * 64,
              "native_probe_openvino": "sha256:" + "2" * 64,
              "native_probe_savant": "sha256:" + "3" * 64}
native = emit("native.json", producer("native_probe", [
    {"name": name, "image_id": image_id} for name, image_id in native_ids.items()]))
workers = emit("workers.json", producer("analytics_worker", [
    {"name": "analytics_worker_openvino", "image_id": "sha256:" + "4" * 64,
     "base_image_id": native_ids["native_probe_openvino"], "identity_changed": False},
    {"name": "analytics_worker_tensorrt", "image_id": "sha256:" + "5" * 64,
     "base_image_id": native_ids["native_probe_deepstream"], "identity_changed": False}]))
repositories = {"deepstream": "vast/deepstream-publication-runtime-v3",
                "savant": "vast/savant-publication-runtime-v3",
                "openvino_gva": "vast/openvino-gva-publication-runtime-v3",
                "gstreamer_custom": "vast/gstreamer-custom-publication-runtime-v3"}
runtimes = {}
for number, system in enumerate(refreeze.SYSTEMS, start=6):
    digit = str(number)
    image_id = "sha256:" + digit * 64
    repository = repositories[system]
    final = repository + ":materialized"
    canonical = repository + "@" + image_id
    physical = {
        "final_reference": final,
        "deterministic_references": [final + "-determinism-a", final + "-determinism-b"],
        "image_id": image_id, "observed_repository_digests": [canonical],
        "canonical_repository_digest": canonical, "canonical_repository_digest_observed": True,
        "inspect_projection_sha256": digit * 64, "inspect_full_sha256": digit * 64,
        "architecture": "amd64", "os": "linux", "created": "1970-01-01T00:00:00Z",
        "entrypoint": ["/runtime"], "user": "root", "labels": {},
        "base": {"kind": "remote_digest", "image_id": "sha256:" + "a" * 64},
        "native_builder": None, "native_receipt": None,
        "source_identity": {
            "runtime_source_sha256": digit * 64, "runtime_source_count": 1,
            "dependency_set_sha256": digit * 64, "dependency_count": 1,
            "source_allowlist_sha256": digit * 64,
            "source_allowlist": {"path": "allowlist.txt", "size": 1, "sha256": digit * 64},
            "native_source_sha256": None, "native_source_count": 0},
        "embedded_files": {"/runtime": digit * 64},
        "embedded_aliases": {"runtime_entrypoint": {"path": "/runtime", "sha256": digit * 64}},
        "embedded_set_sha256": digit * 64}
    value = {"schema_version": 1, "artifact_kind": refreeze.RUNTIME_RECEIPT_KIND,
             "system": system, "build_registry_sha256": build_sha,
             "refreeze_registry_sha256": registry_sha,
             "candidate_binding_eligible": True, "blockers": [],
             "fragment_identity": {"image_id": image_id}, "physical_identity": physical}
    value["receipt_sha256"] = refreeze.self_sha256(value, "receipt_sha256")
    runtimes[system] = emit(system + ".json", value)
output = directory / "patch.json"
patch = refreeze.assemble_identity_patch(
    project_root=project, registry_path=project / refreeze.REGISTRY_RELATIVE_PATH,
    native_receipt=native, worker_receipt=workers, runtime_receipts=runtimes, output=output)
assert refreeze.load_identity_patch(project_root=project, patch_path=output,
                                    require_candidate_eligible=True) == patch
print(json.dumps({"patch": patch, "stock_read_verified": True,
                  "fixture_label": "artificial-physical-metadata-only",
                  "recovery_acceptance": False,
                  "source_paths": {"refreeze": refreeze.__file__}}, sort_keys=True))
'''

CHAIN_CHILD = r'''
import hashlib, json, sys, traceback
from pathlib import Path
package, project, patch = map(Path, sys.argv[1:4])
sys.path.insert(0, str(package / "scripts"))
import publication_policy_qualification_fragments_from_authority_v2 as fragment
import publication_policy_qualification_fragment_validation_v2 as validation
assert fragment.DEFAULT_DEPENDENCIES is validation.DEFAULT_DEPENDENCIES
assert fragment.DEFAULT_DEPENDENCIES.load_identity_patch is validation._default_load_identity_patch
assert validation.FragmentAuthorityDependenciesV2.__dataclass_fields__["load_identity_patch"].default is validation._default_load_identity_patch
for forbidden in ("publication_image_build_v1.py", "materialize_runtime_build_context_v3.py"):
    assert not (package / "scripts" / forbidden).exists(), forbidden
def chain(error):
    if error is None: return None
    return {"type": type(error).__module__ + "." + type(error).__qualname__,
            "message": str(error), "cause": chain(error.__cause__),
            "context": chain(error.__context__), "suppress_context": error.__suppress_context__}
def loaded():
    result = {}
    for name, module in sorted(sys.modules.items()):
        file = getattr(module, "__file__", None)
        if file and Path(file).is_file() and (name.startswith("publication_") or name.startswith("checkpoint_")):
            path = Path(file).resolve()
            assert path.is_relative_to((package / "scripts").resolve()), str(path)
            result[name] = {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
    return result
try:
    value = fragment.DEFAULT_DEPENDENCIES.load_identity_patch(
        project_root=project, patch_path=patch, require_candidate_eligible=True)
except Exception as error:
    print(json.dumps({"outcome": "error", "error": chain(error),
                      "loaded_project_modules": loaded(), "project_search_roots": [str(package / "scripts")],
                      "unchanged_default_callback": True, "recovery_acceptance": False}, sort_keys=True))
    traceback.print_exc()
    raise SystemExit(2)
print(json.dumps({"outcome": "return", "value": value,
                  "loaded_project_modules": loaded(), "project_search_roots": [str(package / "scripts")],
                  "unchanged_default_callback": True, "recovery_acceptance": False}, sort_keys=True))
'''


def _reader_child(mode: str) -> str:
    return r'''
import hashlib, json, stat, sys
from pathlib import Path
from typing import Mapping
project, path = map(Path, sys.argv[1:3])
RECEIPT_KIND = "vast_publication_image_freeze_receipt_v1"
''' + (
        "exec(compile(" + repr(STOCK_READER_SOURCE) + ", '<sealed-stock-reader>', 'exec'))\n"
        if mode == "stock" else
        "sys.path.insert(0, str(project / 'scripts'))\n"
        "from publication_image_freeze_receipt_validation_v1 import "
        "load_publication_image_freeze_receipt, _canonical_json, _receipt_sha256\n"
    ) + r'''
def chain(error):
    if error is None: return None
    return {"type": type(error).__module__ + "." + type(error).__qualname__,
            "message": str(error), "cause": chain(error.__cause__),
            "context": chain(error.__context__), "suppress_context": error.__suppress_context__}
try:
    value = load_publication_image_freeze_receipt(path)
    result = {"outcome": "return", "value": value,
              "canonical_hex": _canonical_json(value).hex(),
              "receipt_sha256": _receipt_sha256(value)}
except Exception as error:
    result = {"outcome": "error", "error": chain(error)}
print(json.dumps(result, sort_keys=True))
'''


class PublicationImageFreezeReceiptValidationV1Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        if hashlib.sha256(STOCK_READER_SOURCE.encode()).hexdigest() != STOCK_FUNCTION_SHA256:
            raise AssertionError("sealed original stock reader bytes drifted")
        cls.started = time.monotonic()
        cls.authority = Path(os.environ.get("VAST_PACKAGE_READER_STOCK", str(ROOT)))
        retained = os.environ.get("VAST_PACKAGE_READER_STAGE")
        reused = os.environ.get("VAST_PACKAGE_READER_REUSE_SOURCES")
        cls.temporary = None
        if retained:
            cls.directory = Path(retained)
            if reused:
                assert cls.directory.is_dir()
            else:
                cls.directory.mkdir(exist_ok=False)
        else:
            cls.temporary = tempfile.TemporaryDirectory(
                prefix="vast-package-reader-", dir="/var/tmp" if Path("/var/tmp").is_dir() else None)
            cls.directory = Path(cls.temporary.name)
        cls.project = cls.directory / "physical-project"
        if not reused:
            cls.project.mkdir()
        cls.package = cls.directory / "packaged-source"
        if not reused:
            cls.package.mkdir()
        cls.controls = Path(os.environ.get("VAST_PACKAGE_READER_REPORTS", str(cls.directory / "reports")))
        cls.controls.mkdir(exist_ok=False)
        registry = json.loads((ROOT / "configs/publication_qualification_image_refreeze_v1.json").read_bytes())
        paths = {"configs/publication_image_build_v1.json", "configs/publication_qualification_image_refreeze_v1.json"}
        for row in registry["systems"]:
            paths.update((row["source_allowlist"], row["dependency_allowlist"], row["dockerfile"]))
            for field in ("source_allowlist", "dependency_allowlist"):
                paths.update((ROOT / row[field]).read_text(encoding="utf-8").splitlines())
        cls.sources = []
        if reused:
            cls.sources = json.loads(Path(reused).read_bytes())["sources"]
            for row in cls.sources:
                content = (cls.directory / row["tree"] / row["path"]).read_bytes()
                assert len(content) == row["bytes"] and hashlib.sha256(content).hexdigest() == row["sha256"]
        for relative in (() if reused else sorted(paths)):
            destination = cls.project / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            artificial = relative.endswith(".whl")
            content = b"" if artificial else (ROOT / relative).read_bytes()
            destination.write_bytes(content)
            cls.sources.append({"tree": "physical-project", "path": relative, "bytes": len(content),
                                "sha256": hashlib.sha256(content).hexdigest(),
                                "artificial_path_existence_input": artificial})
            if relative.startswith("scripts/") and relative.endswith(".py") and Path(relative).name != MATERIALIZER_NAME:
                packaged = cls.package / relative
                packaged.parent.mkdir(parents=True, exist_ok=True)
                packaged.write_bytes(content)
                cls.sources.append({"tree": "packaged-source", "path": relative,
                                    "bytes": len(content), "sha256": hashlib.sha256(content).hexdigest(),
                                    "artificial_path_existence_input": False})
        assert sum(row["bytes"] for row in cls.sources) <= 8 * 1024 * 1024
        assert not (cls.package / "scripts" / BUILDER_NAME).exists()
        assert not (cls.package / "scripts" / MATERIALIZER_NAME).exists()
        cls._record("staged-sources.original.v1.json", {
            "sources": cls.sources,
            "scripts_python_count": sum(row["tree"] == "physical-project" and row["path"].startswith("scripts/") and row["path"].endswith(".py") for row in cls.sources),
            "scripts_python_bytes": sum(row["bytes"] for row in cls.sources if row["tree"] == "physical-project" and row["path"].startswith("scripts/") and row["path"].endswith(".py")),
            "isolated_package_python_count": sum(row["tree"] == "packaged-source" for row in cls.sources),
            "isolated_package_python_bytes": sum(row["bytes"] for row in cls.sources if row["tree"] == "packaged-source"),
            "omitted_from_isolated_package": ["scripts/" + MATERIALIZER_NAME],
            "physical_project_materializer_is_data_outside_package_search_root": True,
            "reused_hash_verified_source_inputs": bool(reused),
            "stock_builder_absent": True, "actual_materializer_absent": True,
            "fixture_label": "artificial-physical-metadata-only",
            "dependency_wheel_source_build_image_acceptance": False,
            "recovery_acceptance": False})

    @classmethod
    def tearDownClass(cls) -> None:
        cls._check_caps()
        for row in cls.sources:
            content = (cls.directory / row["tree"] / row["path"]).read_bytes()
            assert len(content) == row["bytes"] and hashlib.sha256(content).hexdigest() == row["sha256"]
        cls._record("staged-sources.after.v1.json", {"source_bytes_unchanged": True, "recovery_acceptance": False})
        if cls.temporary is not None:
            cls.temporary.cleanup()

    @classmethod
    def _check_caps(cls) -> None:
        assert time.monotonic() - cls.started <= 15 * 60, "cohort deadline exceeded"
        reports = sum(path.stat().st_size for path in cls.controls.rglob("*") if path.is_file())
        total = reports + sum(path.stat().st_size for path in cls.directory.rglob("*") if path.is_file() and not path.is_symlink() and not path.is_relative_to(cls.controls))
        assert reports <= 4 * 1024 * 1024, "reports cap exceeded"
        assert total <= 16 * 1024 * 1024, "cohort cap exceeded"

    @classmethod
    def _record(cls, name: str, value: object) -> None:
        path = cls.controls / name
        data = json.dumps(value, sort_keys=True, indent=2).encode() + b"\n"
        assert len(data) <= 1024 * 1024
        with path.open("xb") as output:
            output.write(data)

    def _invoke(self, name: str, program: str, *args: Path) -> tuple[subprocess.CompletedProcess[bytes], dict[str, object]]:
        self._check_caps()
        result = subprocess.run(
            [sys.executable, "-I", "-B", "-c", program, *(str(arg) for arg in args)],
            stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            timeout=60, check=False,
        )
        self.assertLessEqual(len(result.stdout) + len(result.stderr), 1024 * 1024)
        for suffix, content in (("stdout", result.stdout), ("stderr", result.stderr)):
            with (self.controls / f"{name}.{suffix}.original").open("xb") as output:
                output.write(content)
        self._record(f"{name}.execution.original.v1.json", {
            "argv": result.args, "original_returncode": result.returncode,
            "stdout_sha256": hashlib.sha256(result.stdout).hexdigest(),
            "stderr_sha256": hashlib.sha256(result.stderr).hexdigest(),
            "child_timeout_seconds": 60, "fixture_label": "artificial-physical-metadata-only",
            "recovery_acceptance": False})
        self._check_caps()
        return result, json.loads(result.stdout) if result.stdout else {}

    def _fixture(self, name: str) -> tuple[Path, dict[str, object]]:
        suffix = os.environ.get("VAST_PACKAGE_READER_CASE_SUFFIX", "")
        assert not suffix or (suffix.startswith("-") and suffix[1:].isalnum())
        destination = self.project / "metadata-cases" / (name + suffix)
        destination.parent.mkdir(exist_ok=True)
        result, report = self._invoke("prepare-" + name, PREPARE_CHILD, self.authority, self.project, destination)
        self.assertEqual(result.returncode, 0, result.stderr.decode(errors="replace"))
        self.assertIs(report["stock_read_verified"], True)
        self.assertLessEqual(sum(p.stat().st_size for p in destination.rglob("*") if p.is_file()), 1024 * 1024)
        return destination / "patch.json", report["patch"]

    def test_default_packaged_identity_patch_loads_without_host_builder(self) -> None:
        patch_path, expected = self._fixture("default-chain")
        result, report = self._invoke("default-chain", CHAIN_CHILD, self.package, self.project, patch_path)
        self.assertEqual(result.returncode, 0, json.dumps(report, sort_keys=True))
        self.assertEqual(report["outcome"], "return")
        self.assertEqual(report["value"], expected)
        self.assertIs(report["unchanged_default_callback"], True)

    def test_stock_and_leaf_receipt_cases_have_identical_results_and_errors(self) -> None:
        case_root = self.project / "reader-cases"
        case_root.mkdir()
        valid = _signed({"artifact_kind": RECEIPT_KIND, "schema_version": 1, "images": []})
        values = {
            "canonical": valid,
            "noncanonical": valid,
            "unicode": _signed({**valid, "note": "\u0442\u0435\u0441\u0442/\u00e9/\U0001f642"}),
            "schema-bool-stock-equality": _signed({**valid, "schema_version": True}),
            "schema-float-stock-equality": _signed({**valid, "schema_version": 1.0}),
            "images-elements-stock-quirk": _signed({**valid, "images": [None, True, "x", 1, {}]}),
            "foreign-kind": _signed({**valid, "artifact_kind": "foreign"}),
            "foreign-schema": _signed({**valid, "schema_version": 2}),
            "missing-kind": _signed({key: value for key, value in valid.items() if key != "artifact_kind"}),
            "missing-self-hash": {key: value for key, value in valid.items() if key != "receipt_sha256"},
            "wrong-self-hash": {**valid, "receipt_sha256": "0" * 64},
            "nonstring-self-hash": {**valid, "receipt_sha256": True},
            "wrong-images-type": _signed({**valid, "images": {}}),
            "missing-images": _signed({key: value for key, value in valid.items() if key != "images"}),
            "root-list": [],
            "nan-canonical-refusal": {**valid, "note": float("nan"), "receipt_sha256": "0" * 64},
        }
        cases = {}
        for name, value in values.items():
            path = case_root / (name + ".json")
            path.write_bytes(json.dumps(value, ensure_ascii=False, indent=2).encode() if name == "noncanonical" else json.dumps(value, ensure_ascii=True).encode())
            cases[name] = path
        for name, content in (("malformed-json", b"{"), ("invalid-encoding", b"\xff")):
            path = case_root / (name + ".json")
            path.write_bytes(content)
            cases[name] = path
        cases["missing-file"] = case_root / "absent.json"
        directory = case_root / "directory"
        directory.mkdir()
        cases["directory"] = directory
        target = case_root / "link-target.json"
        target.write_bytes(_canonical(valid))
        symbolic = case_root / "symlink.json"
        symbolic.symlink_to(target)
        cases["symlink"] = symbolic
        hard_target = case_root / "hard-target.json"
        hard_target.write_bytes(_canonical(valid))
        hard = case_root / "hardlink.json"
        os.link(hard_target, hard)
        cases["hardlink"] = hard
        self.assertLessEqual(sum(p.stat().st_size for p in case_root.rglob("*") if p.is_file()), 1024 * 1024)
        for name, path in cases.items():
            with self.subTest(case=name):
                stock_result, stock = self._invoke(name + "-stock", _reader_child("stock"), self.package, path)
                leaf_result, leaf = self._invoke(name + "-leaf", _reader_child("leaf"), self.package, path)
                self.assertEqual(stock_result.returncode, 0, stock_result.stderr.decode(errors="replace"))
                self.assertEqual(leaf_result.returncode, 0, leaf_result.stderr.decode(errors="replace"))
                self.assertEqual(leaf, stock)
                self.assertEqual(stock["outcome"], "return" if name in {
                    "canonical", "noncanonical", "unicode", "schema-bool-stock-equality",
                    "schema-float-stock-equality", "images-elements-stock-quirk"} else "error")

    def test_default_chain_keeps_outer_descriptor_and_physical_refusals(self) -> None:
        for name in ("descriptor", "receipt-symlink", "receipt-hardlink"):
            with self.subTest(case=name):
                patch_path, patch = self._fixture("outer-" + name)
                relative = patch["receipts"]["native_probe"]["path"]
                receipt = self.project / relative
                if name == "descriptor":
                    receipt.write_bytes(receipt.read_bytes() + b" ")
                elif name == "receipt-symlink":
                    target = receipt.with_name("native-target.json")
                    receipt.rename(target)
                    receipt.symlink_to(target)
                else:
                    os.link(receipt, receipt.with_name("native-hardlink.json"))
                result, report = self._invoke("outer-" + name, CHAIN_CHILD, self.package, self.project, patch_path)
                self.assertEqual(result.returncode, 2)
                self.assertEqual(report["outcome"], "error")
                message = report["error"]["message"]
                self.assertIn("descriptor drifted" if name == "descriptor" else "unaliased physical file", message)
                self.assertEqual(json.loads(patch_path.read_bytes()), patch)

    def test_host_public_reader_reexports_the_same_leaf_callable(self) -> None:
        program = r'''
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(sys.argv[1]) / "scripts"))
import publication_image_build_v1 as builder
import publication_image_freeze_receipt_validation_v1 as leaf
import publication_policy_qualification_fragments_from_authority_v2 as fragment
import publication_policy_qualification_fragment_validation_v2 as validation
assert builder.load_publication_image_freeze_receipt is leaf.load_publication_image_freeze_receipt
assert fragment.DEFAULT_DEPENDENCIES is validation.DEFAULT_DEPENDENCIES
assert fragment.DEFAULT_DEPENDENCIES.load_identity_patch is validation._default_load_identity_patch
print(json.dumps({"public_reader_shared": True, "default_dependencies_shared": True,
                  "recovery_acceptance": False}))
'''
        result, report = self._invoke("host-shared-identity", program, ROOT)
        self.assertEqual(result.returncode, 0, result.stderr.decode(errors="replace"))
        self.assertIs(report["public_reader_shared"], True)


if __name__ == "__main__":
    unittest.main()
