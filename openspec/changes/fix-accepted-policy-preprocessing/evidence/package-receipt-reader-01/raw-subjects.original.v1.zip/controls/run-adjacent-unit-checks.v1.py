"""Small adjacent source tests; no image or physical acceptance."""
import contextlib
import hashlib
import json
import sys
import time
import unittest
from pathlib import Path

root, output = map(Path, sys.argv[1:3])
output.mkdir(exist_ok=False)
sys.path[:0] = [str(root / "scripts"), str(root / "tests")]
modules = (
    "test_publication_image_build_v1",
    "test_publication_qualification_image_refreeze_v1",
    "test_publication_runtime_source_closure_guardian_v1",
    "test_checkpoint_deepstream_runtime_source_closure_v3",
    "test_checkpoint_savant_runtime_source_closure_v3",
    "test_checkpoint_openvino_gva_runtime_source_closure_v3",
    "test_checkpoint_gstreamer_custom_runtime_source_closure_v3",
)
paths = [root / "scripts" / (name + ".py") for name in (
    "publication_image_build_v1", "publication_image_freeze_receipt_validation_v1",
    "publication_qualification_image_refreeze_v1")]
paths += [root / "tests" / (name + ".py") for name in modules]
for directory, dockerfile in (("deploy/deepstream/checkpoint", "Dockerfile.runtime"),
                              ("deploy/savant/publication", "Dockerfile"),
                              ("deploy/openvino_gva/publication", "Dockerfile"),
                              ("deploy/gstreamer_custom/publication", "Dockerfile")):
    paths += [root / directory / name for name in (dockerfile, "runtime-source-allowlist.txt", "validate_runtime_source_closure_v3.py")]
def inventory():
    return {path.relative_to(root).as_posix(): {"bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest()} for path in paths}
before = inventory()
started = time.monotonic()
with (output / "unittest.stdout.original").open("x") as stdout, (output / "unittest.stderr.original").open("x") as stderr:
    with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
        suite = unittest.defaultTestLoader.loadTestsFromNames(modules)
        result = unittest.TextTestRunner(stream=stderr, verbosity=2).run(suite)
after = inventory()
assert before == after
elapsed = time.monotonic() - started
assert elapsed < 900
raw = {path.name: {"bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
       for path in output.iterdir() if path.is_file()}
assert sum(row["bytes"] for row in raw.values()) <= 1024 * 1024
report = {"successful": result.wasSuccessful(), "tests_run": result.testsRun,
          "failures": len(result.failures), "errors": len(result.errors), "skips": result.skipped,
          "elapsed_seconds": elapsed, "source_before": before, "source_after": after,
          "source_unchanged": True, "original_outputs": raw,
          "observed_python": sys.version, "physical_package_or_recovery_acceptance": False}
with (output / "result.original.v1.json").open("x") as stream:
    json.dump(report, stream, indent=2, sort_keys=True)
    stream.write("\n")
print(json.dumps({key: report[key] for key in ("successful", "tests_run", "failures", "errors", "skips", "elapsed_seconds")}))
raise SystemExit(0 if result.wasSuccessful() else 1)
