"""Data-only retention forecast: write plan/catalog, never archive/target/test."""
from pathlib import Path
import hashlib
import io
import json
import os
import stat
import subprocess
import zipfile

BASE = Path('E:/STUDY/VAST/tmp/completion-implementation-20261015/package-reader-bounded-01')
REVIEW = BASE.parent / 'dependency-inventory-integrated-01/d8-working-review-01'
REPO = Path('C:/Users/s-a-balashov/.codex/worktrees/fix-accepted-policy-preprocessing/VAST')
TARGET = REPO / 'openspec/changes/fix-accepted-policy-preprocessing/evidence/package-receipt-reader-01'
PLAN = BASE / 'same-pr-retention.lossless.plan.proposed.v1.json'
CATALOG = BASE / 'same-pr-retention.lossless.catalog.proposed.v1.json'
assert not TARGET.exists() and not PLAN.exists() and not CATALOG.exists()
os.environ['GIT_OPTIONAL_LOCKS'] = '0'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encode(value):
    return json.dumps(value, separators=(',', ':'), ensure_ascii=False).encode() + b'\n'


def tree_bytes(root):
    return sum(path.lstat().st_size for path in root.rglob('*') if path.is_file() or path.is_symlink())


roots = [
    '/var/tmp/vast-package-reader-bounded-01-7a6f57c4c3894226a059882997612c38',
    '/var/tmp/vast-package-reader-bounded-01-bfb577dbdaf349fb8d1a5834b32e287f',
]
query = ('import json;from pathlib import Path; roots=' + repr(roots) +
         ';print(json.dumps([[r,sum(p.lstat().st_size for p in Path(r).rglob("*") '
         'if p.is_file() or p.is_symlink())] for r in roots]))')
native = json.loads(subprocess.run(
    ['wsl.exe', '-d', 'Ubuntu', '--exec', '/usr/bin/python3', '-I', '-B', '-c', query],
    stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
    timeout=30, check=True).stdout)
assert [row[1] for row in native] == [4407612, 8503893], 'Held native scope changed; re-review.'

test = REPO / 'tests/test_publication_image_freeze_receipt_validation_v1.py'
assert sha(test.read_bytes()) == '43cdfd8d27147b1cb38975ea1910a0ebaa69e8f375df7bc5df265acb215d2656'
metadata_path = BASE / 'physical-metadata.generated.catalog.original.v1.json'
metadata_raw = metadata_path.read_bytes()
assert sha(metadata_raw) == 'd14497d79042569422fc6feb6d3436674ca8353f433d593a241e5d3cbca6f9ff'
metadata = json.loads(metadata_raw)
entries = []
payloads = {}
for kind, prefix, root in [('C', 'controls/', BASE), ('R', 'independent-review/', REVIEW)]:
    for path in sorted(root.rglob('*')):
        if path.is_file():
            assert not path.is_symlink(), 'Archive originals must be regular bytes.'
            raw = path.read_bytes()
            relative = path.relative_to(root).as_posix()
            name = prefix + relative
            entries.append([name, kind, relative, len(raw), sha(raw)])
            payloads[name] = raw
physical = Path('//wsl.localhost/Ubuntu' + metadata['root'])
for row in metadata['files']:
    if row[7] is None:
        raw = (physical / row[0]).read_bytes()
        assert len(raw) == row[1] and sha(raw) == row[2], 'Generated original bytes changed.'
        name = 'physical-metadata/' + row[0]
        entries.append([name, 'P', row[0], len(raw), sha(raw)])
        payloads[name] = raw
lock = '.publication-atomic-staging-v1/.lock'
assert (REPO / lock).read_bytes() == b''
entries.append(['workspace-controls/' + lock, 'W', lock, 0, sha(b'')])
payloads['workspace-controls/' + lock] = b''
assert len(entries) == len(payloads)

stream = io.BytesIO()
with zipfile.ZipFile(stream, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, raw in sorted(payloads.items()):
        info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.create_system = 3
        info.external_attr = (stat.S_IFREG | 0o644) << 16
        archive.writestr(info, raw, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
archive_raw = stream.getvalue()
with zipfile.ZipFile(io.BytesIO(archive_raw)) as archive:
    assert len(archive.infolist()) == len(entries)
    for name, raw in payloads.items():
        assert archive.read(name) == raw

inode_groups = {}
for row in metadata['files']:
    if row[7] is None:
        inode_groups.setdefault((row[4], row[5]), []).append(row)
links = [
    {'device': key[0], 'inode': key[1], 'members': [row[0] for row in rows],
     'recordedLinkCounts': [row[6] for row in rows], 'sha256': [row[2] for row in rows]}
    for key, rows in inode_groups.items() if len(rows) > 1 or any(row[6] > 1 for row in rows)
]
catalog = {
    'kind': 'package-reader-lossless-raw-subject-catalog.v1',
    'sourceRoots': {'C': str(BASE), 'R': str(REVIEW), 'P': metadata['root'], 'W': str(REPO)},
    'entryColumns': ['zipPath', 'sourceKind', 'relativePath', 'rawBytes', 'rawSHA256'],
    'entries': sorted(entries),
    'archive': {'path': 'raw-subjects.original.v1.zip', 'bytes': len(archive_raw),
                'sha256': sha(archive_raw), 'format': 'ZIP_DEFLATED level9',
                'entryTimestamp': '1980-01-01T00:00:00', 'entryMode': 'regular0644',
                'rawEntryReadbackExact': True, 'rawEntryBytes': sum(row[3] for row in entries)},
    'physicalNamespaceOriginal': {
        'catalog': 'controls/physical-metadata.generated.catalog.original.v1.json',
        'catalogSHA256': sha(metadata_raw), 'root': metadata['root'],
        'columns': metadata['columns'], 'relationships': metadata['files'],
        'symlinks': [row for row in metadata['files'] if row[7] is not None],
        'hardlinkGroups': links, 'factsAreOriginalCatalogObservations': True,
        'zipDoesNotPreserveOrReconstructCustodyOrFilesystemTopology': True,
        'symlinkBytesNotFollowedOrInventedInZIP': True,
        'hardlinkedNamesAreSeparateRegularByteSnapshots': True,
    },
    'nativeSourceTreesRemainHeld': native,
    'nativeSourceCatalog': 'controls/native-stage-source-and-metadata.catalog.readonly.v1.json',
    'originalGitBindings': 'controls/source-catalog.git-bindings.original.v1.json',
    'generatedPlanningMetadataRetainedSeparately': [
        'retention-plan.original.v1.json', 'raw-subjects.catalog.v1.json', 'README.md'],
    'recovery_acceptance': False,
}
catalog_raw = encode(catalog)
readme = '''# D8 package receipt-reader evidence

This lossless ZIP and plain per-entry catalog retain every original D8 bounded
control, raw result, stock/source snapshot, external reviewer control and named
regular physical-metadata subject at the pinned planning snapshot. The catalog
binds uncompressed bytes, archive bytes, source paths and original physical
relationships. Nothing is extracted, replayed or adopted as campaign authority.

Historical resource conformance is FAILED/BLOCK: failed01 package4,407,612 B plus
correct02 sources8,269,987 B =12,677,599 B, over original8 MiB before GREEN, and
two retained roots rather than one. GREEN later charged active02/view against
8 MiB; that narrower interpretation did not satisfy the original limit. All
old plans, failures and native roots remain unchanged; no limit was enlarged.

Original RED04 reaches the actual missing builder sibling through unchanged
packaged DEFAULT_DEPENDENCIES;01-03 are setup failures. Original GREEN4a1f91
has four tests,57fresh children and24stock/leaf pairs. Its behavior/provenance
evidence is valid while historical resource approval remains blocked. The
independent combined review and later corrective review remain separate.

Prospective test43cdfd8d enforces cumulative retained-source admission before
copy/view writes, requires a root pin for reuse, and adds tiny real-counter and
pre-write refusal tests. It was independently reviewed and applied, not run
locally. Current fresh-source forecast is8,273,081 B, not executed acceptance.
Required fresh exact-commit hosted CI and deliberate task1.7 approval remain.

Metadata fixtures and12empty wheel-path files are artificial path-existence
inputs. No actual wheel/model/image data were copied or installed. The ZIP
retains regular bytes only. Symlink targets, device/inode/link relationships
and mutation subjects are recorded in the catalog; hardlinked names become
separate regular archive entries. This does not recreate or attest physical
custody. Original native namespaces stay held. Native baseline sources are
identified by original catalogs/Git bindings rather than copied again.

The faithful leaf/refreeze/COPY change is source evidence only. Full2.8/default
public endpoint, actual-image4.2, renewal/parity/pins, capacity1.5, controlled
recovery, genuine physical cohorts, archive and final approval stay open. No
image offload/deletion or storage authority follows. Adjacent36/36checks had
1,541,016 B static fake-context payload, not measured peak or receipt-only
execution. Their original reports and known zero-byte workspace lock survive.
'''.encode()
controls = tree_bytes(BASE)
reviews = tree_bytes(REVIEW)
assert reviews <= 819200
before = sum(row[1] for row in native) + controls + reviews + test.stat().st_size
result_reserve = 32768
plan = {
    'kind': 'package-reader-lossless-retention-plan.v1',
    'phase': 'REVIEW_REQUIRED_BEFORE_ANY_TARGET_OR_DISK_ARCHIVE_WRITE',
    'target': str(TARGET), 'test': [str(test), test.stat().st_size, sha(test.read_bytes())],
    'catalogSource': str(CATALOG), 'catalogTarget': 'raw-subjects.catalog.v1.json',
    'catalogBytes': len(catalog_raw), 'catalogSHA256': sha(catalog_raw),
    'planSource': str(PLAN), 'planTarget': 'retention-plan.original.v1.json',
    'archive': catalog['archive'], 'sourceEntries': len(entries),
    'generatedREADME': {'path': 'README.md', 'bytes': len(readme), 'sha256': sha(readme),
                        'utf8Text': readme.decode()},
    'generatedResult': {'sourceName': 'same-pr-retention.lossless.result.original.v1.json',
                        'targetName': 'retention-result.v1.json', 'maxBytesEach': result_reserve},
    'rules': [
        'Recheck every source/hash and exact root scope before target write; drift requires a new reviewed plan.',
        'Write the ZIP once directly to the target; no ignored disk archive or native source allocation.',
        'Preserve all originals; no extraction/replay, cleanup, topology reconstruction or source/test execution.',
        'Verify every ZIP entry and all plain target bytes after write; retain bounded result without retry.',
        'Verify active/archive text-unset attributes and fresh C40 before target writes.',
        'Plan/catalog and generated README/result are plain separately retained metadata, not omitted raw originals.',
    ],
    'historicalSourceConformance': 'FAILED_BLOCK_UNCHANGED',
    'correctiveReview': 'independent-review/cumulative-source-correction-review.v1.md',
    'correctiveReviewSHA256': '121e1e5aa1016e046e58c8b692d6616dc3347ddf6248a86adec6a90c8ec310ee',
    'productionLeafBuilderRefreezeUnchangedByRetention': True,
    'resourceForecast': {
        'nativeRetained': native, 'controlsBeforePlan': controls, 'externalReview': reviews,
        'liveTest': test.stat().st_size, 'currentBeforePlan': before,
        'catalogBytesEachCopy': len(catalog_raw), 'planBytesEachCopy': 0,
        'archiveBytesOneTargetCopy': len(archive_raw), 'READMEBytesOneTargetCopy': len(readme),
        'resultReserveEachOfTwoCopies': result_reserve, 'forecastGlobalRetained': 0,
        'remainingGlobalBytes': 0, 'globalLimit': 16777216, 'sourceLimit': 8388608,
        'reportsLimit': 4194304, 'caseLimit': 1048576,
        'historicalOverSourceLimitStillFailed': True, 'forecastReportControls': 0,
        'adjacentStaticContextPayloadDisclosedSeparately': 1541016,
        'adjacentPeakNotMeasuredOrConcurrentWithRetention': True,
    },
    'noStagingCommitPushTaskClosureOrAcceptance': True, 'recovery_acceptance': False,
}
for _ in range(12):
    raw = encode(plan)
    forecast = before + 2 * len(catalog_raw) + 2 * len(raw) + len(archive_raw) + len(readme) + 2 * result_reserve
    report_forecast = controls + reviews + 2 * len(catalog_raw) + 2 * len(raw) + len(archive_raw) + len(readme) + 2 * result_reserve
    old = dict(plan['resourceForecast'])
    plan['resourceForecast'].update({
        'planBytesEachCopy': len(raw), 'forecastGlobalRetained': forecast,
        'remainingGlobalBytes': 16777216 - forecast, 'forecastReportControls': report_forecast})
    if old == plan['resourceForecast']:
        break
plan_raw = encode(plan)
assert len(plan_raw) == plan['resourceForecast']['planBytesEachCopy']
assert plan['resourceForecast']['forecastGlobalRetained'] <= 16777216
assert plan['resourceForecast']['forecastReportControls'] <= 4194304
CATALOG.write_bytes(catalog_raw)
PLAN.write_bytes(plan_raw)
print(json.dumps({
    'plan': [str(PLAN), len(plan_raw), sha(plan_raw)],
    'catalog': [str(CATALOG), len(catalog_raw), sha(catalog_raw)],
    'archiveForecast': catalog['archive'], 'sourceEntries': len(entries),
    'physicalSymlinks': len(catalog['physicalNamespaceOriginal']['symlinks']),
    'physicalHardlinkGroups': len(links), 'forecast': plan['resourceForecast'],
    'targetCreated': False, 'diskArchiveCreated': False, 'testsRun': False,
}))
