from pathlib import Path
import json,hashlib,collections,datetime
BASE=Path('E:/STUDY/VAST/tmp/completion-implementation-20261015/package-reader-bounded-01')
TEST=Path('C:/Users/s-a-balashov/.codex/worktrees/fix-accepted-policy-preprocessing/VAST/tests/test_publication_image_freeze_receipt_validation_v1.py')
REVIEW=BASE.parent/'dependency-inventory-integrated-01/d8-working-review-01'
def sha(b):return hashlib.sha256(b).hexdigest()
def sub(p):
 b=p.read_bytes();return [str(p),len(b),sha(b)]
r=json.loads((BASE/'leaf-green-01.execution.original.v1.json').read_bytes());case=BASE/'leaf-green-01'
assert r['Verdict']=='GREEN' and r['original_returncode']==0 and r['test_sha256']==sha(TEST.read_bytes())
children={p.name:json.loads(p.read_bytes()) for p in case.glob('*.execution.original.v1.json')}
assert len(children)==57 and collections.Counter(v['original_returncode'] for v in children.values())=={0:54,2:3}
matrix=[]
for p in sorted(case.glob('*-stock.stdout.original')):
 name=p.name.removesuffix('-stock.stdout.original');stock=json.loads(p.read_bytes());leaf=json.loads((case/(name+'-leaf.stdout.original')).read_bytes());assert stock==leaf
 matrix.append([name,stock['outcome'],sha(p.read_bytes()),sha((case/(name+'-leaf.stdout.original')).read_bytes())])
assert len(matrix)==24
provenance=json.loads((case/'green-code-view.source-provenance.original.v1.json').read_bytes());assert len(provenance['files'])==87
assert collections.Counter(v['source_kind'] for v in provenance['files'])=={'unchanged-owned-native-baseline':85,'new-pinned-overlay-source':2}
valid=json.loads((case/'default-chain.stdout.original').read_bytes());stock=json.loads((case/'prepare-default-chain.stdout.original').read_bytes());assert stock['reader_verified'] and stock['stock_read_verified'] and stock['authority_kind']=='preserved-stock' and valid['value']==stock['patch']
host=json.loads((case/'host-shared-identity.stdout.original').read_bytes());assert host['public_reader_shared'] and host['fixed_file_loader_alias_shared'] and host['default_dependencies_shared']
report={
 'kind':'package-receipt-reader-bounded-green-author-evidence.v1','author':'audit_capacity','Verdict':'GREEN_SOURCE_ONLY',
 'recordedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewedPlanningCommit':'8840e2230c9dda560870774867b2ce38dc4fd2d8','PR9ApprovalComment':6180731892,
 'workingSourceNotHostedCommitAcceptance':True,'test':sub(TEST),'executedSourceSnapshot':sub(BASE/'test-receipt-reader.green-reviewed.original.v8.py'),
 'execution':sub(BASE/'leaf-green-01.execution.original.v1.json'),'unittestStderr':sub(BASE/'leaf-green-01.unittest.original.stderr'),
 'outcomes':{'unittestMethods':4,'failures':0,'errors':0,'skips':0,'freshChildProcesses':57,'originalChildReturncodes':{'0':54,'2_expected_refusals':3},'elapsedSeconds':r['elapsed_seconds']},
 'stockLeafMatrixColumns':['case','outcome','stockRawSHA256','leafRawSHA256'],'stockLeafMatrix':matrix,
 'stockLeafScope':'Exact original1416-byte closure; complete values or type/message/cause/context/suppression plus canonical/self-hash bytes.6valid/18refusal pairs.',
 'defaultCallback':{'entry':'publication_policy_qualification_fragment_validation_v2.DEFAULT_DEPENDENCIES.load_identity_patch','unchanged':True,'valueEqualsOriginalStockPhysicalPatch':True,'stockGenerationAuthority':'preserved-stock','loadedProjectModules':valid['loaded_project_modules']},
 'hostAlias':host,'outerRefusals':['descriptor mutation','native receipt symlink','native receipt hardlink'],
 'sourceProvenance':sub(case/'green-code-view.source-provenance.original.v1.json'),'sourceBefore':sub(case/'staged-sources.original.v1.json'),'sourceAfter':sub(case/'staged-sources.after.v1.json'),
 'baselineSourcesAndNewViewVerifiedBeforeAfter':True,'oneEffectiveProjectCodeRoot':True,'noHostRescueLoaderFileDefaultOrCacheOverride':True,
 'preservedOriginalRED':sub(BASE/'package-receipt-reader-red.author-manifest.v1.json'),'preparedFailureCases01Through03RemainNonRED':True,
 'physicalGeneratedMetadataCatalog':sub(BASE/'physical-metadata.generated.catalog.original.v1.json'),
 'resources':{'CFreeBefore':r['C_free_before'],'CFreeAfter':r['C_free_after'],'CFloor':40*1024**3,'nativeRetainedAfter':r['native_after'],'boundedControlsNow':sum(p.stat().st_size for p in BASE.rglob('*') if p.is_file()),'externalReviewBytes':sum(p.stat().st_size for p in REVIEW.rglob('*') if p.is_file()),'externalReviewLimit':819200,'caps':r['budget_bytes'],'adjacentStaticContextPayloadBytes':1541016,'adjacentTransientScope':'Original36/36existing tests; native/worker context data, no wheel/model copies or real Docker/build. Static aggregate, sequential and not measured peak; not receipt-only.','wholeChainCapacityAcceptance':False},
 'knownWorkspaceControl':{'path':'C:/Users/s-a-balashov/.codex/worktrees/fix-accepted-policy-preprocessing/VAST/.publication-atomic-staging-v1/.lock','bytes':0,'sha256':sha(b''),'origin':'First observed after root adjacent unit run; retained unchanged, not staged by this author.'},
 'authorship':'This author wrote the assigned test/ignored controls and ran the single originalRED plus one GREEN; production extraction/COPY changes belong to root. This is author evidence, not independent review.',
 'recovery_acceptance':False,'dependency_wheel_source_build_image_acceptance':False,
 'excludedAcceptance':['Full public fragment endpoint/task2.8','Actual runtime image/package4.2','Genuine complete consumers/5.3','Native/worker/parity renewal','Whole-chain capacity/backing or live cold recovery','Image deletion/offload','Mandatory hosted checks for an implemented commit','Whole-diff/final/archive acceptance']}
p=BASE/'package-receipt-reader-green.author-manifest.v1.json';assert not p.exists();b=json.dumps(report,separators=(',',':')).encode()+b'\n';p.write_bytes(b)
print(json.dumps({'path':str(p),'bytes':len(b),'sha256':sha(b),'boundedControlBytesAfter':sum(p.stat().st_size for p in BASE.rglob('*') if p.is_file())}))
