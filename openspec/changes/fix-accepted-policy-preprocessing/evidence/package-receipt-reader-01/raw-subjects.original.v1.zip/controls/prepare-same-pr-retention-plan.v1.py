from pathlib import Path
import json,hashlib
BASE=Path('E:/STUDY/VAST/tmp/completion-implementation-20261015/package-reader-bounded-01')
REVIEW=BASE.parent/'dependency-inventory-integrated-01/d8-working-review-01'
REPO=Path('C:/Users/s-a-balashov/.codex/worktrees/fix-accepted-policy-preprocessing/VAST')
TARGET=REPO/'openspec/changes/fix-accepted-policy-preprocessing/evidence/package-receipt-reader-01'
def sha(b):return hashlib.sha256(b).hexdigest()
assert not TARGET.exists(),'Plan only: evidence directory must not be written yet.'
planp=BASE/'same-pr-retention.plan.proposed.v1.json';assert not planp.exists()
entries=[]
for code,root in [('C',BASE),('R',REVIEW)]:
 for p in sorted(root.rglob('*')):
  if p.is_file():
   raw=p.read_bytes();entries.append([code,p.relative_to(root).as_posix(),len(raw),sha(raw)])
metadata=json.loads((BASE/'physical-metadata.generated.catalog.original.v1.json').read_bytes())
for row in metadata['files']:
 if row[7] is None:entries.append(['P',row[0],row[1],row[2]])
entries.append(['W','.publication-atomic-staging-v1/.lock',0,sha(b'')])
native_bytes=4407612+8503893
ignored_before=sum(p.stat().st_size for p in BASE.rglob('*') if p.is_file())
review_before=sum(p.stat().st_size for p in REVIEW.rglob('*') if p.is_file())
assert review_before<=819200
test_bytes=(REPO/'tests/test_publication_image_freeze_receipt_validation_v1.py').stat().st_size
before=native_bytes+ignored_before+review_before+test_bytes
readme='''# Bounded package receipt reader evidence

This directory retains original D8/task2.7 author controls and independent
reviews in PR9. The planning authority is8840/comment6180731892. Working code
has source-only bounded GREEN; this is not hosted final-commit or actual-image
acceptance. Exact source and raw identities are in the retained manifests.

Original RED04 accepts a valid patch through the preserved stock authority,
then the actual packaged fragment-validation DEFAULT_DEPENDENCIES callback
fails at the absent builder sibling. RED01-03 are retained preparation failures,
not meaningful regression proof. Executed RED source70c85e remains separate
from GREEN source4a1f91. Both raw stderr/stdout and controller records survive.

GREEN: four tests, zero failures/errors/skips,24stock-leaf case pairs and57fresh
children. It exercises only the lower default receipt callback, faithful
original1416-byte reader behavior, three outer physical refusals and shared
canonical/fixed-file host aliases. Each package import uses one explicit
effective code root;85unchanged sources are natural links to a held native
baseline and two changed sources are physical pinned copies. Source paths,
resolved provenance and before/after hash guards are retained.

Physical metadata is entirely artificial. Empty wheel-path files supply only
path existence; invented image/inspection values are not observations or
dependency/wheel/build/image acceptance. Reader outputs remain non-authorizing.
Full public fragment endpoint2.8, actual images4.2, genuine consumers5.3,
renewal, physical/hardware, capacity/recovery and whole-diff/final gates remain
open. No image upload/deletion/offload or human confirmation is supplied.

Controls and raw bytes are copied unchanged. Physical-metadata copies retain
original regular-file bytes; their archive paths are ordinary inspection
copies, not a recreated physical fixture. Original symlink/hardlink/inode
states are recorded in physical-metadata.generated.catalog.original.v1.json.
Symlinks are catalogued rather than recreated. Hardlinked names are copied as
separate regular byte snapshots; the actual native namespace remains held.
For a mutation case, pre-mutation native receipt bytes survive in the valid
case with the same SHA256; the changed original and untouched patch survive.

Native baseline trees are held in place. The complete original source catalog,
source manifests and123Git-blob bindings at8840 identify their exact bytes;
another13MB source copy is excluded. Original stock builder/refreeze/I/O and
raw1416-byte spans are retained directly under controls. New leaf/refreeze
working-source snapshots are separately pinned. Nothing is replayed or adopted
as campaign authority by this retention.

Resource reports distinguish raw retained byte caps from allocation/backing
space. Adjacent36/36tests had1541016B static aggregate sequential fake-context
payload, not measured peak or receipt-only execution. Their original controls
and zero-byte workspace lock are retained. C40 was observed for bounded work;
whole-chain capacity1.5 stays unqualified. The same-PR retention plan lists each
copy hash, exact scope and conservative global16MiB forecast. Raw attributes
cover this active evidence directory and its eventual archive location.
'''.encode()
copybytes=sum(row[2] for row in entries)
manifest={'kind':'same-pr-package-reader-byte-retention-plan.v1','phase':'PROPOSED_BEFORE_ANY_EVIDENCE_DIRECTORY_WRITE',
 'target':str(TARGET),'sourceRoots':{'C':str(BASE),'R':str(REVIEW),'P':metadata['root'],'W':str(REPO)},
 'destinationPrefixes':{'C':'controls/','R':'independent-review/','P':'physical-metadata/','W':'workspace-controls/'},
 'entryColumns':['sourceKind','relativePath','bytes','sha256'],'entries':entries,
 'generatedReadme':{'path':'README.md','bytes':len(readme),'sha256':sha(readme),'utf8Text':readme.decode()},
 'retainedPlanCopy':'same-pr-retention.plan.v1.json','planSelfHash':'Recorded externally; no recursive self-hash is invented.',
 'originalNativeSourcesRemainHeld':True,'nativeSourcesAreNotCopiedAgain':True,
 'nativeSourceCatalog':'controls/native-stage-source-and-metadata.catalog.readonly.v1.json',
 'originalGitBindings':'controls/source-catalog.git-bindings.original.v1.json',
 'physicalNamespaceCatalog':'controls/physical-metadata.generated.catalog.original.v1.json',
 'symlinkPolicy':'Do not follow/copy symlinks as regular originals. Preserve their physical facts in catalog and originals in held native tree.',
 'hardlinkPolicy':'Copy raw bytes for each named regular subject, retain original link-count/inode facts in catalog and held namespace.',
 'attributeDisposition':'Exact active/archive evidence patterns already set text=unset; raw byte preservation required.',
 'scope':'All current bounded controls/raws/stock/reference/source snapshots, all external D8 reviewer controls,73generated physical regular subjects and known workspace zero-byte control.',
 'approvalBoundary':'Root reviews this concrete plan before creating the same-PR evidence directory. Recompute if any source/control changes after this snapshot; do not drop originals to fit.',
 'resourceForecast':{'nativeRetained':native_bytes,'boundedControlsBeforePlan':ignored_before,'reviewControlsBeforePlan':review_before,'worktreeTestBytes':test_bytes,
  'currentBeforePlan':before,'entryCopyBytes':copybytes,'generatedReadmeBytes':len(readme),'planBytes':0,'projectedGlobalAfterCopies':0,'remainingGlobalBytes':0,
  'globalLimit':16*1024**2,'reportsLimit':4*1024**2,'externalReviewAllocation':819200,'adjacentStaticTransientPayload':1541016,
  'adjacentTransientNotConcurrentWithRetention':'Original adjacent run completed before GREEN/retention; payload is disclosed separately, not treated as retained bytes or measured peak.'},
 'recovery_acceptance':False,'full_endpoint_image_genuine_capacity_acceptance':False}
for _ in range(10):
 raw=json.dumps(manifest,separators=(',',':')).encode()+b'\n';n=len(raw)
 forecast=before+n+copybytes+n+len(readme)
 fields=manifest['resourceForecast']
 if fields['planBytes']==n and fields['projectedGlobalAfterCopies']==forecast:break
 fields.update({'planBytes':n,'projectedGlobalAfterCopies':forecast,'remainingGlobalBytes':16*1024**2-forecast})
raw=json.dumps(manifest,separators=(',',':')).encode()+b'\n'
assert len(raw)==manifest['resourceForecast']['planBytes']
assert manifest['resourceForecast']['projectedGlobalAfterCopies']<=16*1024**2
assert ignored_before+review_before+len(raw)<=4*1024**2
planp.write_bytes(raw)
print(json.dumps({'path':str(planp),'bytes':len(raw),'sha256':sha(raw),'copyEntries':len(entries),'artifactBytes':copybytes+len(raw)+len(readme),'forecast':manifest['resourceForecast']}))
