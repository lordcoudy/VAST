abi <abi/4.0>,
profile vast-ci-userns-e293fed7462e4ac391c4547e5358c577 /opt/hostedtoolcache/Python/3.12.3/x64/bin/python3.12 flags=(unconfined) {
  userns,
}
