abi <abi/4.0>,
profile vast-ci-userns-e43dc7c7e6f64bc491907401da55d433 /opt/hostedtoolcache/Python/3.12.3/x64/bin/python3.12 flags=(unconfined) {
  userns,
}
