abi <abi/4.0>,
profile vast-ci-userns-b0df42628fb1416a93e3bcd48fa1e319 /opt/hostedtoolcache/Python/3.12.3/x64/bin/python3.12 flags=(unconfined) {
  userns,
}
