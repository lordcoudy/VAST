abi <abi/4.0>,
profile vast-ci-userns-dba7e1e905e64c5c87f4a220f53ff2d0 /opt/hostedtoolcache/Python/3.12.3/x64/bin/python3.12 flags=(unconfined) {
  userns,
}
