abi <abi/4.0>,
profile vast-ci-userns-22aa1245cf0741c3afa11aec42f88af1 /opt/hostedtoolcache/Python/3.12.3/x64/bin/python3.12 flags=(unconfined) {
  userns,
}
