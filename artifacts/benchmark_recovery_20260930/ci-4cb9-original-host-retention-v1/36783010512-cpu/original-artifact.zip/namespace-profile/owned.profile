abi <abi/4.0>,
profile vast-ci-userns-bb698292a08a4cc197faae0cfd7f5d90 /opt/hostedtoolcache/Python/3.12.3/x64/bin/python3.12 flags=(unconfined) {
  userns,
}
