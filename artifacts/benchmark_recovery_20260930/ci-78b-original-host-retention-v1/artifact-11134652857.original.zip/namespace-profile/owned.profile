abi <abi/4.0>,
profile vast-ci-userns-b051fa6eeaa548afae9143bf04d3f6c6 /opt/hostedtoolcache/Python/3.12.3/x64/bin/python3.12 flags=(unconfined) {
  userns,
}
