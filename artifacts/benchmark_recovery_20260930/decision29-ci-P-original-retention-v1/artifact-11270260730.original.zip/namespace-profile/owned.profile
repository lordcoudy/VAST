abi <abi/4.0>,
profile vast-ci-userns-ff57e432a8704d77b1ee1b547d6a725c /opt/hostedtoolcache/Python/3.12.3/x64/bin/python3.12 flags=(unconfined) {
  userns,
}
