abi <abi/4.0>,
profile vast-ci-userns-954a78d0b250407996d4cd023c6d7e30 /opt/hostedtoolcache/Python/3.12.3/x64/bin/python3.12 flags=(unconfined) {
  userns,
}
