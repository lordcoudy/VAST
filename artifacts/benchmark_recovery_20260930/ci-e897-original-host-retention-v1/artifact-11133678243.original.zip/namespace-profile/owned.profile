abi <abi/4.0>,
profile vast-ci-userns-95aa1b69ccfc4ad09aaeb24f27a77fc8 /opt/hostedtoolcache/Python/3.12.3/x64/bin/python3.12 flags=(unconfined) {
  userns,
}
