abi <abi/4.0>,
profile vast-ci-userns-8fc796bd35be4d3da45f88bc692c19b4 /opt/hostedtoolcache/Python/3.12.3/x64/bin/python3.12 flags=(unconfined) {
  userns,
}
