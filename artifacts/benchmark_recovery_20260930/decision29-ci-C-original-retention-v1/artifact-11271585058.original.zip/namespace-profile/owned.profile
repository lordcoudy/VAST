abi <abi/4.0>,
profile vast-ci-userns-246af23ac98a4f99bdf80e062d190fa6 /opt/hostedtoolcache/Python/3.12.3/x64/bin/python3.12 flags=(unconfined) {
  userns,
}
